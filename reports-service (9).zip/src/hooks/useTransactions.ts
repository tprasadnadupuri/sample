import { useState, useEffect, useMemo, useCallback } from "react";
import { 
  Transaction, 
  TransactionFilters, 
  TransactionSummary,
  TransactionStatus,
  IngestionSource,
  TransactionAction,
  HeatmapCell,
  SLATrendPoint
} from "@/types/transaction";

const CLIENT_NAMES = [
  "CBC/Fidelity Bank", "Mission Loans LLC", "JP Morgan Chase", 
  "Navy Federal", "Social Mortgage", "Swift Home Loans",
  "Barrett Financial", "Datamyx LLC", "Golden Gate Prequal"
];

const STATUSES: TransactionStatus[] = ["success", "failed"];

function generateMockTransactions(count: number, batchReprocessedCount: number): Transaction[] {
  const transactions: Transaction[] = [];
  
  // Generate only API transactions (no pure BATCH in API mode transaction view)
  const apiOnlyCount = count - batchReprocessedCount;
  for (let i = 0; i < apiOnlyCount; i++) {
    const status = Math.random() > 0.15 ? "success" : "failed";
    
    transactions.push({
      id: `TXN-${Date.now()}-${i}`,
      timestamp: new Date(Date.now() - Math.random() * 3600000).toISOString(),
      source: "API",
      action: Math.random() > 0.3 ? "add" : "delete",
      status,
      clientName: CLIENT_NAMES[Math.floor(Math.random() * CLIENT_NAMES.length)],
      portfolioId: `P${Math.floor(Math.random() * 100)}`,
      population: Math.floor(Math.random() * 10000),
      latency: Math.floor(Math.random() * 1500) + 100,
      errorMessage: status === "failed" ? "Validation error: Missing required field" : undefined,
    });
  }
  
  // Generate batch reprocessed transactions
  for (let i = 0; i < batchReprocessedCount; i++) {
    const status: TransactionStatus = Math.random() > 0.1 ? "success" : "failed";
    transactions.push({
      id: `TXN-REPROC-${Date.now()}-${i}`,
      timestamp: new Date(Date.now() - Math.random() * 1800000).toISOString(),
      source: "BATCH_REPROCESSED",
      action: Math.random() > 0.4 ? "add" : "delete",
      status,
      clientName: CLIENT_NAMES[Math.floor(Math.random() * CLIENT_NAMES.length)],
      portfolioId: `P${Math.floor(Math.random() * 100)}`,
      population: Math.floor(Math.random() * 5000),
      latency: Math.floor(Math.random() * 800) + 200,
      originalBatchId: `BATCH-ERR-${Math.floor(Math.random() * 1000)}`,
    });
  }
  
  return transactions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

function generateHeatmapData(): HeatmapCell[] {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const sources = ["API", "BATCH", "Validator", "Downstream"];
  const cells: HeatmapCell[] = [];
  
  days.forEach(day => {
    for (let hour = 0; hour < 24; hour++) {
      // More errors during business hours
      const baseErrors = hour >= 9 && hour <= 17 ? 15 : 5;
      cells.push({
        day,
        hour,
        errorCount: Math.floor(Math.random() * baseErrors),
        source: sources[Math.floor(Math.random() * sources.length)],
      });
    }
  });
  
  return cells;
}

function generateSLATrend(): SLATrendPoint[] {
  const points: SLATrendPoint[] = [];
  const now = Date.now();
  
  for (let i = 24; i >= 0; i--) {
    const timestamp = new Date(now - i * 3600000).toISOString();
    const baseLatency = 400 + Math.sin(i / 4) * 200;
    
    points.push({
      timestamp,
      p50: Math.floor(baseLatency * 0.6 + Math.random() * 100),
      p95: Math.floor(baseLatency + Math.random() * 200),
      p99: Math.floor(baseLatency * 1.5 + Math.random() * 300),
      threshold: 1000,
    });
  }
  
  return points;
}

export function useTransactions(batchReprocessedCount: number = 49) {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filters, setFilters] = useState<TransactionFilters>({
    source: "all",
    action: "all",
    status: "all",
    timeRange: "1h",
  });
  const [heatmapData, setHeatmapData] = useState<HeatmapCell[]>([]);
  const [slaTrend, setSlaTrend] = useState<SLATrendPoint[]>([]);

  useEffect(() => {
    // Generate initial data
    const totalTransactions = 100 + batchReprocessedCount;
    setTransactions(generateMockTransactions(totalTransactions, batchReprocessedCount));
    setHeatmapData(generateHeatmapData());
    setSlaTrend(generateSLATrend());
  }, [batchReprocessedCount]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter(txn => {
      if (filters.source !== "all" && txn.source !== filters.source) return false;
      if (filters.action !== "all" && txn.action !== filters.action) return false;
      if (filters.status !== "all" && txn.status !== filters.status) return false;
      return true;
    });
  }, [transactions, filters]);

  const summary = useMemo((): TransactionSummary => {
    const byStatus: Record<TransactionStatus, number> = {
      success: 0,
      failed: 0,
    };

    let api = 0, batch = 0, batchReprocessed = 0;
    let add = 0, del = 0;

    transactions.forEach(txn => {
      byStatus[txn.status]++;
      if (txn.source === "API") api++;
      else if (txn.source === "BATCH") batch++;
      else batchReprocessed++;
      
      if (txn.action === "add") add++;
      else del++;
    });

    return {
      total: transactions.length,
      bySource: { api, batch, batchReprocessed },
      byAction: { add, delete: del },
      byStatus,
    };
  }, [transactions]);

  const updateFilter = useCallback(<K extends keyof TransactionFilters>(
    key: K,
    value: TransactionFilters[K]
  ) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  }, []);

  return {
    transactions: filteredTransactions,
    allTransactions: transactions,
    filters,
    updateFilter,
    summary,
    heatmapData,
    slaTrend,
  };
}
