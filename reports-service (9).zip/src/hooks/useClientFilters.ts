import { useMemo, useState } from "react";
import { ClientData, FilterState, KPIData } from "@/types/client";
import { clientData } from "@/data/clientData";

const initialFilters: FilterState = {
  search: "",
  active: "all",
  type: "all",
  clientType: "all",
  ingestion: "all",
  period: "Month",
};

export function useClientFilters() {
  const [filters, setFilters] = useState<FilterState>(initialFilters);

  const filteredData = useMemo(() => {
    return clientData.filter((row) => {
      const searchMatch =
        filters.search === "" ||
        (row.COMPANY + row["PORTFOLIO NAME"])
          .toLowerCase()
          .includes(filters.search.toLowerCase());

      const activeMatch =
        filters.active === "all" || row.ACTIVE === filters.active;

      const typeMatch = filters.type === "all" || row.TYPE === filters.type;

      const clientTypeMatch =
        filters.clientType === "all" || row["CLIENT TYPE"] === filters.clientType;

      const ingestionMatch =
        filters.ingestion === "all" || row["INGESTION MODE"] === filters.ingestion;

      return searchMatch && activeMatch && typeMatch && clientTypeMatch && ingestionMatch;
    });
  }, [filters]);

  const kpis = useMemo((): KPIData => {
    const activeSet = new Set<string>();
    let totalPop = 0;
    let lastFullFile = "";
    let lastFullDate = 0;
    let lastAddDelFile = "";
    let lastAddDelDate = 0;
    let addDelCount = 0;

    const isApiMode = filters.ingestion === "API";
    const isComboMode = filters.ingestion === "COMBO";

    filteredData.forEach((row) => {
      if (row.ACTIVE === "YES") {
        activeSet.add(`${row.COMPANY}|${row.PORT}`);
      }
      totalPop += row.POPULATION;

      // Track add/del counts for API mode
      if (row["LAST ADD/DEL FILE NAME"] || row["LAST ADD/DEL FILE PROCESSED DATE"]) {
        addDelCount++;
      }

      const fullDateStr = row["LAST FULL FILE PROCESSED DATE"];
      if (fullDateStr) {
        const d = Date.parse(fullDateStr);
        if (!isNaN(d) && d > lastFullDate) {
          lastFullDate = d;
          lastFullFile = row["LAST FULL FILE NAME"] || fullDateStr;
        }
      }

      const addDelDateStr = row["LAST ADD/DEL FILE PROCESSED DATE"];
      if (addDelDateStr) {
        const d = Date.parse(addDelDateStr);
        if (!isNaN(d) && d > lastAddDelDate) {
          lastAddDelDate = d;
          lastAddDelFile = row["LAST ADD/DEL FILE NAME"] || addDelDateStr;
        }
      }
    });

    // Simulate reprocessed batch errors via API (consistent value based on data)
    const reprocessedViaApi = isApiMode || isComboMode
      ? 49 // Consistent value for demo
      : 0;

    // Direct API transactions (simulated based on active clients)
    const directApiTransactions = isApiMode || isComboMode
      ? activeSet.size * 12 // ~12 transactions per active client
      : 0;

    // Total API Transactions = Batch→API Reprocessed + Direct API
    const totalTransactions = reprocessedViaApi + directApiTransactions;

    return {
      activeClients: activeSet.size,
      totalPopulation: totalPop,
      lastFullFile: isApiMode ? "N/A" : (lastFullFile || "—"),
      lastAddDelFile: lastAddDelFile || "—",
      totalTransactions,
      addDelCount,
      isApiMode,
      reprocessedViaApi,
    };
  }, [filteredData, filters.ingestion]);

  const topPopulations = useMemo(() => {
    return [...filteredData]
      .filter((r) => r.POPULATION > 0)
      .sort((a, b) => b.POPULATION - a.POPULATION)
      .slice(0, 10)
      .map((r) => ({
        name: `${r.COMPANY.trim().slice(0, 20)}${r.PORT ? ` (P${r.PORT})` : ""}`,
        population: r.POPULATION,
      }));
  }, [filteredData]);

  const updateFilter = <K extends keyof FilterState>(
    key: K,
    value: FilterState[K]
  ) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  return {
    filters,
    updateFilter,
    filteredData,
    kpis,
    topPopulations,
  };
}
