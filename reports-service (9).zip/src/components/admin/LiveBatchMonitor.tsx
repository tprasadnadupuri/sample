import { useState, useMemo, useEffect } from "react";
import { ClientData } from "@/types/client";
import { Search, RefreshCw, Server, Clock, FileText, HardDrive, Hash, TrendingUp, ChevronLeft, ChevronRight } from "lucide-react";

interface BatchFile {
  clientCompany: string;
  portfolioName: string;
  port: string;
  fileName: string;
  fileSize: string;
  recordCount: number;
  progress: number;
  status: "running" | "complete" | "failed";
  startTime: string;
  eta: string;
  processedDate: string;
}

function generateBatchFiles(clients: ClientData[]): BatchFile[] {
  const batchClients = clients.filter(
    c => c.ACTIVE === "YES" && (c["INGESTION MODE"] === "BATCH" || c["INGESTION MODE"] === "COMBO") && c["LAST FULL FILE NAME"]
  );

  const now = new Date();
  const today = now.toLocaleDateString("en-US", { month: "2-digit", day: "2-digit", year: "numeric" });

  return batchClients.map((c) => {
    const isRunning = Math.random() > 0.35;
    const progress = isRunning ? Math.floor(Math.random() * 85) + 10 : (Math.random() > 0.1 ? 100 : -1);
    const status: BatchFile["status"] = progress === -1 ? "failed" : progress === 100 ? "complete" : "running";
    const pop = c.POPULATION || Math.floor(Math.random() * 100000);
    const sizeMB = Math.max(1, Math.floor(pop / 5000));
    const startHour = Math.floor(Math.random() * 6) + 1;
    const startMin = Math.floor(Math.random() * 60);
    const elapsedMin = status === "running" ? Math.floor(Math.random() * 120) + 5 : Math.floor(Math.random() * 180) + 10;
    const remainingMin = status === "running" ? Math.max(1, Math.floor(elapsedMin * (100 - progress) / Math.max(progress, 1))) : 0;

    return {
      clientCompany: c.COMPANY,
      portfolioName: c["PORTFOLIO NAME"],
      port: c.PORT,
      fileName: c["LAST FULL FILE NAME"],
      fileSize: `${sizeMB} MB`,
      recordCount: pop,
      progress: Math.max(0, progress),
      status,
      startTime: `${String(startHour).padStart(2, "0")}:${String(startMin).padStart(2, "0")} AM`,
      eta: status === "running" ? `~${remainingMin} min` : status === "complete" ? "Done" : "N/A",
      processedDate: c["LAST FULL FILE PROCESSED DATE"] || today,
    };
  });
}

export function LiveBatchMonitor({ clients }: { clients: ClientData[] }) {
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "running" | "complete" | "failed">("all");
  const [batchFiles, setBatchFiles] = useState<BatchFile[]>([]);
  const [lastRefresh, setLastRefresh] = useState(new Date());
  const [page, setPage] = useState(1);
  const perPage = 5;

  useEffect(() => {
    setBatchFiles(generateBatchFiles(clients));
  }, [clients]);

  const refresh = () => {
    setBatchFiles(generateBatchFiles(clients));
    setLastRefresh(new Date());
  };

  // Auto-refresh every 30s
  useEffect(() => {
    const interval = setInterval(refresh, 30000);
    return () => clearInterval(interval);
  }, [clients]);

  const filtered = useMemo(() => {
    let data = [...batchFiles];
    if (search) {
      const s = search.toLowerCase();
      data = data.filter(f =>
        f.portfolioName.toLowerCase().includes(s) ||
        f.clientCompany.toLowerCase().includes(s) ||
        f.fileName.toLowerCase().includes(s)
      );
    }
    if (filterStatus !== "all") data = data.filter(f => f.status === filterStatus);
    // Sort: running first, then complete, then failed
    const order = { running: 0, complete: 1, failed: 2 };
    data.sort((a, b) => order[a.status] - order[b.status]);

    // Limit: 2 running, 2 completed, 1 failed
    const limits: Record<string, number> = { running: 2, complete: 2, failed: 1 };
    const counts: Record<string, number> = { running: 0, complete: 0, failed: 0 };
    data = data.filter(f => {
      counts[f.status] = (counts[f.status] || 0) + 1;
      return counts[f.status] <= (limits[f.status] ?? 2);
    });

    return data;
  }, [batchFiles, search, filterStatus]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const pagedData = filtered.slice((page - 1) * perPage, page * perPage);

  const counts = useMemo(() => ({
    running: batchFiles.filter(f => f.status === "running").length,
    complete: batchFiles.filter(f => f.status === "complete").length,
    failed: batchFiles.filter(f => f.status === "failed").length,
  }), [batchFiles]);

  const statusColor = (s: BatchFile["status"]) => {
    switch (s) {
      case "running": return "text-chart-2 bg-chart-2/15";
      case "complete": return "text-status-ok bg-status-ok/15";
      case "failed": return "text-status-bad bg-status-bad/15";
    }
  };

  return (
    <div>
      {/* Summary cards */}
      <div className="grid grid-cols-3 gap-3 mb-4">
        <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-chart-2/15 flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-chart-2" />
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase">Running</p>
            <p className="text-lg font-bold text-chart-2">{counts.running}</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-status-ok/15 flex items-center justify-center">
            <FileText className="w-4 h-4 text-status-ok" />
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase">Complete</p>
            <p className="text-lg font-bold text-status-ok">{counts.complete}</p>
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-status-bad/15 flex items-center justify-center">
            <Server className="w-4 h-4 text-status-bad" />
          </div>
          <div>
            <p className="text-[10px] text-muted-foreground uppercase">Failed</p>
            <p className="text-lg font-bold text-status-bad">{counts.failed}</p>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search batch files..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>
        <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value as any)} className="px-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground">
          <option value="all">All Status</option>
          <option value="running">Running</option>
          <option value="complete">Complete</option>
          <option value="failed">Failed</option>
        </select>
        <button onClick={refresh} className="flex items-center gap-1.5 px-3 py-2 bg-secondary rounded-lg text-xs text-foreground hover:bg-muted transition-colors">
          <RefreshCw className="w-3.5 h-3.5" />
          Refresh
        </button>
        <span className="text-[10px] text-muted-foreground ml-auto">
          Last refreshed: {lastRefresh.toLocaleTimeString()} • Auto-refresh 30s
        </span>
      </div>

      {/* Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {["Client", "Portfolio", "File Name", "Status", "Progress", "File Size", "Records", "Start Time", "ETA", "Processed Date"].map(h => (
                  <th key={h} className="px-3 py-2.5 text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pagedData.map((f, i) => (
                <tr key={`${f.clientCompany}-${f.port}-${i}`} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-3 py-2.5 font-medium text-foreground">{f.clientCompany}</td>
                  <td className="px-3 py-2.5 text-foreground max-w-[180px] truncate">{f.portfolioName}</td>
                  <td className="px-3 py-2.5 text-muted-foreground font-mono text-[10px] max-w-[220px] truncate" title={f.fileName}>{f.fileName}</td>
                  <td className="px-3 py-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${statusColor(f.status)}`}>
                      {f.status === "running" && <Clock className="w-3 h-3 inline mr-0.5 animate-spin" style={{ animationDuration: "3s" }} />}
                      {f.status.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 rounded-full bg-muted overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all ${f.status === "failed" ? "bg-status-bad" : f.status === "complete" ? "bg-status-ok" : "bg-chart-2"}`}
                          style={{ width: `${f.progress}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-muted-foreground w-8">{f.progress}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground flex items-center gap-1">
                    <HardDrive className="w-3 h-3" />{f.fileSize}
                  </td>
                  <td className="px-3 py-2.5 text-foreground font-mono flex items-center gap-1">
                    <Hash className="w-3 h-3 text-muted-foreground" />{f.recordCount.toLocaleString()}
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground">{f.startTime}</td>
                  <td className="px-3 py-2.5 text-foreground font-medium">{f.eta}</td>
                  <td className="px-3 py-2.5 text-muted-foreground">{f.processedDate}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={10} className="px-3 py-8 text-center text-muted-foreground">No batch files match your filters.</td></tr>
              )}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-[10px] text-muted-foreground">Page {page} of {totalPages} · {filtered.length} records</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 transition-colors">
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                <button key={p} onClick={() => setPage(p)} className={`px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors ${p === page ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}>
                  {p}
                </button>
              ))}
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 transition-colors">
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
