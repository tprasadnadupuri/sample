import { Shield, TrendingDown, Clock, DollarSign, AlertTriangle, CheckCircle, BarChart3 } from "lucide-react";

const weeklySummary = {
  period: "Feb 7 – Feb 13, 2026",
  totalTransactions: 48_230,
  successRate: 94.2,
  avgLatency: 872,
  errorsTotal: 2_796,
  errorsResolved: 2_310,
  highlights: [
    "Batch processing throughput improved 12% after queue scaling on Feb 10.",
    "API error spike on Feb 11 (4-6 PM) traced to upstream timeout — resolved with retry policy.",
    "3 new portfolios onboarded: AMEX P42, DISCOVER P19, CITI P88.",
    "DLQ backlog cleared from 142 → 3 after hotfix deployment Feb 12.",
  ],
};

const riskExposure = [
  { risk: "SQS batch-file-intake backlog > 800", severity: "high" as const, mitigation: "Auto-scaling rule triggered; monitoring closely" },
  { risk: "PII validation false-positive rate at 2.3%", severity: "medium" as const, mitigation: "ML model retrain scheduled for Feb 15" },
  { risk: "Single point of failure on DB writer service", severity: "high" as const, mitigation: "HA replica deployment planned for Feb 17" },
  { risk: "API rate limit approaching for NAVY portfolio", severity: "low" as const, mitigation: "Quota increase request submitted" },
];

const slaCompliance = [
  { metric: "P50 Latency", target: "< 500ms", actual: "412ms", status: "pass" as const },
  { metric: "P95 Latency", target: "< 1000ms", actual: "872ms", status: "pass" as const },
  { metric: "P99 Latency", target: "< 2000ms", actual: "1,842ms", status: "pass" as const },
  { metric: "Uptime", target: "99.9%", actual: "99.94%", status: "pass" as const },
  { metric: "Error Rate", target: "< 5%", actual: "5.8%", status: "fail" as const },
  { metric: "Batch Turnaround", target: "< 15 min", actual: "12 min", status: "pass" as const },
];

const financialImpact = {
  estimatedLoss: "$42,800",
  lostTransactions: 2_796,
  reprocessingCost: "$8,150",
  slaBreachPenalty: "$18,500",
  totalExposure: "$69,450",
  trend: "down" as const,
  trendPct: 14,
};

const severityStyles = {
  high: "bg-destructive/15 text-destructive",
  medium: "bg-chart-5/15 text-chart-5",
  low: "bg-primary/15 text-primary",
};

export function ExecutiveSummary() {
  return (
    <div className="space-y-5">
      {/* Weekly Summary */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Weekly Summary</h3>
          <span className="ml-auto text-[10px] text-muted-foreground">{weeklySummary.period}</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          {[
            { label: "Total Transactions", value: weeklySummary.totalTransactions.toLocaleString() },
            { label: "Success Rate", value: `${weeklySummary.successRate}%` },
            { label: "Avg Latency", value: `${weeklySummary.avgLatency}ms` },
            { label: "Errors Resolved", value: `${weeklySummary.errorsResolved}/${weeklySummary.errorsTotal}` },
          ].map((s) => (
            <div key={s.label} className="bg-muted/30 rounded-lg p-3 text-center">
              <p className="text-lg font-bold text-foreground">{s.value}</p>
              <p className="text-[10px] text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="space-y-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1">Key Highlights</p>
          {weeklySummary.highlights.map((h, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-foreground">
              <CheckCircle className="w-3.5 h-3.5 text-status-ok mt-0.5 shrink-0" />
              <span>{h}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Risk Exposure */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-chart-5" />
            <h3 className="text-sm font-semibold text-foreground">Risk Exposure</h3>
          </div>
          <div className="space-y-2">
            {riskExposure.map((r, i) => (
              <div key={i} className="bg-muted/30 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium text-foreground">{r.risk}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${severityStyles[r.severity]}`}>{r.severity}</span>
                </div>
                <p className="text-[11px] text-muted-foreground">↳ {r.mitigation}</p>
              </div>
            ))}
          </div>
        </div>

        {/* SLA Compliance */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-4 h-4 text-primary" />
            <h3 className="text-sm font-semibold text-foreground">SLA Compliance</h3>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="px-2 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Metric</th>
                <th className="px-2 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Target</th>
                <th className="px-2 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Actual</th>
                <th className="px-2 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Status</th>
              </tr>
            </thead>
            <tbody>
              {slaCompliance.map((s) => (
                <tr key={s.metric} className="border-b border-border/50">
                  <td className="px-2 py-2 font-medium text-foreground">{s.metric}</td>
                  <td className="px-2 py-2 text-muted-foreground font-mono">{s.target}</td>
                  <td className="px-2 py-2 text-foreground font-mono">{s.actual}</td>
                  <td className="px-2 py-2">
                    {s.status === "pass" ? (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-status-ok/15 text-status-ok">PASS</span>
                    ) : (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-destructive/15 text-destructive">FAIL</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Financial Impact */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <DollarSign className="w-4 h-4 text-chart-5" />
          <h3 className="text-sm font-semibold text-foreground">Financial Impact Estimate</h3>
          <div className="ml-auto flex items-center gap-1 text-status-ok">
            <TrendingDown className="w-3.5 h-3.5" />
            <span className="text-[10px] font-semibold">{financialImpact.trendPct}% ↓ vs last week</span>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {[
            { label: "Est. Revenue Loss", value: financialImpact.estimatedLoss, warn: true },
            { label: "Failed Transactions", value: financialImpact.lostTransactions.toLocaleString(), warn: false },
            { label: "Reprocessing Cost", value: financialImpact.reprocessingCost, warn: false },
            { label: "SLA Breach Penalty", value: financialImpact.slaBreachPenalty, warn: true },
            { label: "Total Exposure", value: financialImpact.totalExposure, warn: true },
          ].map((f) => (
            <div key={f.label} className={`rounded-lg p-3 text-center ${f.warn ? "bg-destructive/5 border border-destructive/20" : "bg-muted/30"}`}>
              <p className={`text-lg font-bold ${f.warn ? "text-destructive" : "text-foreground"}`}>{f.value}</p>
              <p className="text-[10px] text-muted-foreground">{f.label}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
