import { useState } from "react";
import { AlertTriangle, FileText, Inbox, TicketCheck, RefreshCw, ChevronDown, ChevronUp } from "lucide-react";

interface LogEntry {
  id: string;
  timestamp: string;
  level: "error" | "warn" | "info";
  source: string;
  message: string;
}

interface SQSQueue {
  name: string;
  backlog: number;
  inFlight: number;
  dlq: number;
  status: "healthy" | "warning" | "critical";
}

interface JiraTicket {
  id: string;
  summary: string;
  status: "open" | "in-progress" | "resolved";
  priority: "critical" | "high" | "medium";
  assignee: string;
  created: string;
}

const mockLogs: LogEntry[] = [
  { id: "L1", timestamp: "2026-02-13 19:42:01", level: "error", source: "API Gateway", message: "Timeout on /enroll endpoint — upstream 504 after 30s" },
  { id: "L2", timestamp: "2026-02-13 19:41:55", level: "error", source: "Batch Processor", message: "File CHASE_FULL_20260213.csv — 14 rows failed PII validation" },
  { id: "L3", timestamp: "2026-02-13 19:41:30", level: "warn", source: "SQS Consumer", message: "Queue depth exceeded 500 for enrollment-dlq" },
  { id: "L4", timestamp: "2026-02-13 19:40:12", level: "error", source: "DB Writer", message: "Deadlock detected on consumer_records — retrying" },
  { id: "L5", timestamp: "2026-02-13 19:39:50", level: "info", source: "Health Check", message: "All downstream services responding within SLA" },
  { id: "L6", timestamp: "2026-02-13 19:38:22", level: "warn", source: "API Gateway", message: "Rate limit approaching: 850/1000 req/min for client NAVY" },
  { id: "L7", timestamp: "2026-02-13 19:37:10", level: "error", source: "Batch Processor", message: "USAA_ADDDEL_20260213.csv — malformed header row" },
  { id: "L8", timestamp: "2026-02-13 19:36:45", level: "info", source: "Scheduler", message: "Nightly reconciliation job completed — 12,340 records matched" },
];

const mockQueues: SQSQueue[] = [
  { name: "enrollment-inbound", backlog: 142, inFlight: 38, dlq: 3, status: "healthy" },
  { name: "enrollment-processing", backlog: 567, inFlight: 120, dlq: 18, status: "warning" },
  { name: "enrollment-outbound", backlog: 23, inFlight: 12, dlq: 0, status: "healthy" },
  { name: "batch-file-intake", backlog: 890, inFlight: 45, dlq: 42, status: "critical" },
  { name: "notification-dispatch", backlog: 56, inFlight: 8, dlq: 1, status: "healthy" },
];

const mockErrorSpikes = [
  { hour: "12:00", errors: 3 }, { hour: "13:00", errors: 5 }, { hour: "14:00", errors: 2 },
  { hour: "15:00", errors: 12 }, { hour: "16:00", errors: 28 }, { hour: "17:00", errors: 45 },
  { hour: "18:00", errors: 38 }, { hour: "19:00", errors: 22 },
];

const mockTickets: JiraTicket[] = [
  { id: "MCM-1042", summary: "Batch processor timeout on large FULL files (>50k rows)", status: "open", priority: "critical", assignee: "J. Martinez", created: "2026-02-13" },
  { id: "MCM-1039", summary: "API 504s spike during peak hours 4-6 PM EST", status: "in-progress", priority: "high", assignee: "R. Chen", created: "2026-02-12" },
  { id: "MCM-1035", summary: "DLQ accumulation on batch-file-intake queue", status: "open", priority: "high", assignee: "Unassigned", created: "2026-02-12" },
  { id: "MCM-1031", summary: "PII validation false positives on Canadian addresses", status: "in-progress", priority: "medium", assignee: "A. Patel", created: "2026-02-11" },
];

const levelStyles = {
  error: "bg-destructive/10 text-destructive border-destructive/20",
  warn: "bg-chart-5/10 text-chart-5 border-chart-5/20",
  info: "bg-primary/10 text-primary border-primary/20",
};

const queueStatusStyles = {
  healthy: "bg-status-ok/10 text-status-ok",
  warning: "bg-chart-5/10 text-chart-5",
  critical: "bg-destructive/10 text-destructive",
};

const priorityStyles = {
  critical: "bg-destructive/15 text-destructive",
  high: "bg-chart-5/15 text-chart-5",
  medium: "bg-primary/15 text-primary",
};

const ticketStatusStyles = {
  open: "bg-destructive/10 text-destructive",
  "in-progress": "bg-chart-5/10 text-chart-5",
  resolved: "bg-status-ok/10 text-status-ok",
};

export function MonitoringPanel() {
  const [expandedLog, setExpandedLog] = useState<string | null>(null);
  const [ticketForm, setTicketForm] = useState(false);
  const [newTicket, setNewTicket] = useState({ summary: "", priority: "high" });

  const maxErrors = Math.max(...mockErrorSpikes.map(e => e.errors));

  const handleCreateTicket = () => {
    alert(`🎫 Jira ticket created: MCM-${1043 + Math.floor(Math.random() * 100)}\n"${newTicket.summary}"\nPriority: ${newTicket.priority}`);
    setTicketForm(false);
    setNewTicket({ summary: "", priority: "high" });
  };

  return (
    <div className="space-y-5">
      {/* Error Spike Visualization */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            <h3 className="text-sm font-semibold text-foreground">Error Spike Monitor</h3>
          </div>
          <span className="text-[10px] text-muted-foreground">Last 8 hours</span>
        </div>
        <div className="flex items-end gap-2 h-32">
          {mockErrorSpikes.map((bar) => (
            <div key={bar.hour} className="flex-1 flex flex-col items-center gap-1">
              <span className="text-[9px] font-mono text-muted-foreground">{bar.errors}</span>
              <div
                className={`w-full rounded-t transition-all ${bar.errors > 30 ? "bg-destructive" : bar.errors > 15 ? "bg-chart-5" : "bg-primary/40"}`}
                style={{ height: `${(bar.errors / maxErrors) * 100}%`, minHeight: 4 }}
              />
              <span className="text-[9px] text-muted-foreground">{bar.hour}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Logs Panel */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <FileText className="w-4 h-4 text-muted-foreground" />
            <h3 className="text-sm font-semibold text-foreground">System Logs</h3>
            <button className="ml-auto p-1 rounded hover:bg-muted transition-colors">
              <RefreshCw className="w-3.5 h-3.5 text-muted-foreground" />
            </button>
          </div>
          <div className="space-y-1.5 max-h-[320px] overflow-y-auto">
            {mockLogs.map((log) => (
              <div
                key={log.id}
                onClick={() => setExpandedLog(expandedLog === log.id ? null : log.id)}
                className={`border rounded-lg px-3 py-2 cursor-pointer transition-colors ${levelStyles[log.level]}`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-mono opacity-70">{log.timestamp.split(" ")[1]}</span>
                  <span className="text-[10px] font-semibold uppercase">{log.level}</span>
                  <span className="text-[10px] opacity-70">— {log.source}</span>
                  {expandedLog === log.id ? <ChevronUp className="w-3 h-3 ml-auto" /> : <ChevronDown className="w-3 h-3 ml-auto" />}
                </div>
                {expandedLog === log.id && (
                  <p className="mt-1.5 text-[11px] leading-relaxed">{log.message}</p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* SQS Backlog */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Inbox className="w-4 h-4 text-muted-foreground" />
            <h3 className="text-sm font-semibold text-foreground">SQS Queue Backlog</h3>
          </div>
          <div className="space-y-2">
            {mockQueues.map((q) => (
              <div key={q.name} className="bg-muted/30 rounded-lg p-3">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-xs font-medium text-foreground">{q.name}</span>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${queueStatusStyles[q.status]}`}>
                    {q.status}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-sm font-bold text-foreground">{q.backlog}</p>
                    <p className="text-[9px] text-muted-foreground">Backlog</p>
                  </div>
                  <div>
                    <p className="text-sm font-bold text-foreground">{q.inFlight}</p>
                    <p className="text-[9px] text-muted-foreground">In-Flight</p>
                  </div>
                  <div>
                    <p className={`text-sm font-bold ${q.dlq > 10 ? "text-destructive" : "text-foreground"}`}>{q.dlq}</p>
                    <p className="text-[9px] text-muted-foreground">DLQ</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Jira Tickets */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <TicketCheck className="w-4 h-4 text-muted-foreground" />
            <h3 className="text-sm font-semibold text-foreground">Jira Tickets</h3>
          </div>
          <button
            onClick={() => setTicketForm(!ticketForm)}
            className="px-3 py-1.5 rounded-lg text-[10px] font-medium bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            + Create Ticket
          </button>
        </div>

        {ticketForm && (
          <div className="mb-4 p-3 bg-muted/30 rounded-lg border border-border space-y-2">
            <input
              value={newTicket.summary}
              onChange={(e) => setNewTicket(p => ({ ...p, summary: e.target.value }))}
              placeholder="Ticket summary..."
              className="w-full px-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
            <div className="flex items-center gap-2">
              <select
                value={newTicket.priority}
                onChange={(e) => setNewTicket(p => ({ ...p, priority: e.target.value }))}
                className="px-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground"
              >
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
              </select>
              <button onClick={handleCreateTicket} className="px-4 py-2 rounded-lg text-xs font-medium bg-primary text-primary-foreground hover:bg-primary/90">
                Submit
              </button>
              <button onClick={() => setTicketForm(false)} className="px-4 py-2 rounded-lg text-xs font-medium bg-secondary text-muted-foreground hover:text-foreground">
                Cancel
              </button>
            </div>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border">
                <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">ID</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Summary</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Priority</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Status</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Assignee</th>
                <th className="px-3 py-2 text-left text-[10px] font-semibold text-muted-foreground uppercase">Created</th>
              </tr>
            </thead>
            <tbody>
              {mockTickets.map((t) => (
                <tr key={t.id} className="border-b border-border/50 hover:bg-muted/20">
                  <td className="px-3 py-2 font-mono font-medium text-primary">{t.id}</td>
                  <td className="px-3 py-2 text-foreground max-w-[300px] truncate">{t.summary}</td>
                  <td className="px-3 py-2">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${priorityStyles[t.priority]}`}>{t.priority}</span>
                  </td>
                  <td className="px-3 py-2">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${ticketStatusStyles[t.status]}`}>{t.status}</span>
                  </td>
                  <td className="px-3 py-2 text-muted-foreground">{t.assignee}</td>
                  <td className="px-3 py-2 text-muted-foreground">{t.created}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
