import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend, PieChart, Pie, Cell } from "recharts";
import { AlertTriangle, TrendingUp } from "lucide-react";

const portfolioErrors = [
  { portfolio: "CHASE P12", api: 42, batch: 18, total: 60 },
  { portfolio: "NAVY P08", api: 35, batch: 28, total: 63 },
  { portfolio: "USAA P15", api: 12, batch: 45, total: 57 },
  { portfolio: "AMEX P42", api: 28, batch: 8, total: 36 },
  { portfolio: "CITI P88", api: 22, batch: 14, total: 36 },
  { portfolio: "DISCOVER P19", api: 15, batch: 20, total: 35 },
  { portfolio: "BOA P03", api: 8, batch: 12, total: 20 },
  { portfolio: "WELLS P27", api: 10, batch: 5, total: 15 },
];

const dailyTrend = [
  { day: "Feb 7", errors: 320, resolved: 298 },
  { day: "Feb 8", errors: 280, resolved: 265 },
  { day: "Feb 9", errors: 190, resolved: 185 },
  { day: "Feb 10", errors: 410, resolved: 380 },
  { day: "Feb 11", errors: 520, resolved: 445 },
  { day: "Feb 12", errors: 380, resolved: 360 },
  { day: "Feb 13", errors: 290, resolved: 210 },
];

const errorCategories = [
  { name: "PII Validation", value: 38, color: "hsl(var(--destructive))" },
  { name: "Timeout/504", value: 22, color: "hsl(var(--chart-5))" },
  { name: "Duplicate Record", value: 18, color: "hsl(var(--chart-2))" },
  { name: "Malformed Payload", value: 12, color: "hsl(var(--chart-4))" },
  { name: "Auth Failure", value: 6, color: "hsl(var(--primary))" },
  { name: "Other", value: 4, color: "hsl(var(--muted-foreground))" },
];

export function ErrorTrendsDashboard() {
  const topErrors = useMemo(() =>
    [...portfolioErrors].sort((a, b) => b.total - a.total).slice(0, 8),
    []
  );

  return (
    <div className="space-y-5">
      {/* Summary KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Total Errors (7d)", value: "2,390", delta: "-14%", positive: true },
          { label: "Unresolved", value: "247", delta: "+3%", positive: false },
          { label: "MTTR", value: "18 min", delta: "-22%", positive: true },
          { label: "Top Offender", value: "NAVY P08", delta: "63 errors", positive: false },
        ].map((kpi) => (
          <div key={kpi.label} className="bg-card border border-border rounded-xl p-4">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">{kpi.label}</p>
            <p className="text-xl font-bold text-foreground">{kpi.value}</p>
            <p className={`text-[10px] font-medium ${kpi.positive ? "text-status-ok" : "text-destructive"}`}>{kpi.delta}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Errors by Portfolio (Bar Chart) */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            <h3 className="text-sm font-semibold text-foreground">Errors by Portfolio</h3>
          </div>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={topErrors} layout="vertical" margin={{ left: 10, right: 10 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis type="number" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
              <YAxis type="category" dataKey="portfolio" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} width={90} />
              <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
              <Bar dataKey="api" stackId="a" fill="hsl(var(--chart-2))" name="API Errors" radius={[0, 0, 0, 0]} />
              <Bar dataKey="batch" stackId="a" fill="hsl(var(--chart-4))" name="Batch Errors" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Error Category Breakdown (Pie) */}
        <div className="bg-card border border-border rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4 text-chart-5" />
            <h3 className="text-sm font-semibold text-foreground">Error Categories</h3>
          </div>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width="50%" height={240}>
              <PieChart>
                <Pie data={errorCategories} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={2}>
                  {errorCategories.map((entry, i) => (
                    <Cell key={i} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 flex-1">
              {errorCategories.map((c) => (
                <div key={c.name} className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: c.color }} />
                  <span className="text-[11px] text-foreground">{c.name}</span>
                  <span className="text-[10px] text-muted-foreground ml-auto">{c.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Daily Error Trend (Line Chart) */}
      <div className="bg-card border border-border rounded-xl p-5">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Daily Error Trend</h3>
          <span className="ml-auto text-[10px] text-muted-foreground">Feb 7 – Feb 13, 2026</span>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <LineChart data={dailyTrend}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="day" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
            <YAxis tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} />
            <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
            <Legend wrapperStyle={{ fontSize: 10 }} />
            <Line type="monotone" dataKey="errors" stroke="hsl(var(--destructive))" strokeWidth={2} dot={{ r: 3 }} name="Errors" />
            <Line type="monotone" dataKey="resolved" stroke="hsl(var(--status-ok))" strokeWidth={2} dot={{ r: 3 }} name="Resolved" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
