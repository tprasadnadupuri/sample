import { useState, useEffect, useMemo } from "react";
import { ClientData } from "@/types/client";
import { Wifi, TrendingUp, CheckCircle, XCircle, Clock, RefreshCw, Activity, Search, Download, Calendar, ChevronLeft, ChevronRight } from "lucide-react";
import { format } from "date-fns";

interface APIClientMetrics {
  client: ClientData;
  totalTransactions: number;
  successCount: number;
  failedCount: number;
  successRate: number;
  avgLatencyMs: number;
  lastActivityTime: string;
  status: "active" | "idle" | "degraded";
  tps: number;
  date: string;
}

function generateMetrics(client: ClientData, dateStr: string): APIClientMetrics {
  const seed = client.PORT.charCodeAt(0) + client.COMPANY.charCodeAt(0) + dateStr.charCodeAt(dateStr.length - 1);
  const rand = (min: number, max: number) => min + ((seed * 9301 + 49297) % 233280) / 233280 * (max - min);

  const totalTransactions = Math.floor(rand(500, 25000));
  const successRate = rand(88, 99.8);
  const successCount = Math.floor(totalTransactions * successRate / 100);
  const failedCount = totalTransactions - successCount;
  const avgLatencyMs = Math.floor(rand(45, 850));
  const tps = parseFloat(rand(2, 120).toFixed(1));

  const hours = Math.floor(rand(0, 4));
  const mins = Math.floor(rand(0, 59));
  const lastActivityTime = hours === 0 ? `${mins}m ago` : `${hours}h ${mins}m ago`;

  let status: "active" | "idle" | "degraded" = "active";
  if (hours >= 2) status = "idle";
  else if (successRate < 92) status = "degraded";

  return {
    client,
    totalTransactions,
    successCount,
    failedCount,
    successRate,
    avgLatencyMs,
    lastActivityTime,
    status,
    tps,
    date: dateStr,
  };
}

function downloadCSV(data: APIClientMetrics[], dateLabel: string) {
  const headers = ["Portfolio Name", "Company", "Port", "Ingestion Mode", "Status", "Total Tx", "Success", "Failed", "Success %", "Avg Latency (ms)", "TPS", "Last Activity", "Date"];
  const rows = data.map(m => [
    m.client["PORTFOLIO NAME"],
    m.client.COMPANY,
    m.client.PORT,
    m.client["INGESTION MODE"],
    m.status,
    m.totalTransactions,
    m.successCount,
    m.failedCount,
    m.successRate.toFixed(1),
    m.avgLatencyMs,
    m.tps,
    m.lastActivityTime,
    m.date,
  ]);

  const csv = [headers.join(","), ...rows.map(r => r.map(v => `"${v}"`).join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `api-progress-report-${dateLabel}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

interface APIProgressMonitorProps {
  clients: ClientData[];
}

export function APIProgressMonitor({ clients }: APIProgressMonitorProps) {
  const [refreshKey, setRefreshKey] = useState(0);
  const [filterStatus, setFilterStatus] = useState<"all" | "active" | "idle" | "degraded">("all");
  const [search, setSearch] = useState("");
  const [selectedDate, setSelectedDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [page, setPage] = useState(1);
  const perPage = 5;

  const apiClients = useMemo(() =>
    clients.filter(c => c["INGESTION MODE"] === "API" || c["INGESTION MODE"] === "COMBO"),
    [clients]
  );

  const metrics = useMemo(() =>
    apiClients.map(c => generateMetrics(c, selectedDate)),
    [apiClients, refreshKey, selectedDate]
  );

  const filtered = useMemo(() => {
    let result = metrics;
    if (filterStatus !== "all") {
      result = result.filter(m => m.status === filterStatus);
    }
    if (search.trim()) {
      const s = search.toLowerCase();
      result = result.filter(m =>
        m.client["PORTFOLIO NAME"].toLowerCase().includes(s) ||
        m.client.COMPANY.toLowerCase().includes(s) ||
        m.client.PORT.toLowerCase().includes(s)
      );
    }
    // Limit to 5-12 rows
    return result.slice(0, 12);
  }, [metrics, filterStatus, search]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const pagedData = filtered.slice((page - 1) * perPage, page * perPage);

  const summary = useMemo(() => {
    const totalTx = metrics.reduce((s, m) => s + m.totalTransactions, 0);
    const totalSuccess = metrics.reduce((s, m) => s + m.successCount, 0);
    const totalFailed = metrics.reduce((s, m) => s + m.failedCount, 0);
    const avgLatency = metrics.length ? Math.round(metrics.reduce((s, m) => s + m.avgLatencyMs, 0) / metrics.length) : 0;
    const activeCount = metrics.filter(m => m.status === "active").length;
    const degradedCount = metrics.filter(m => m.status === "degraded").length;
    return { totalTx, totalSuccess, totalFailed, avgLatency, activeCount, degradedCount, totalClients: metrics.length };
  }, [metrics]);

  useEffect(() => {
    const interval = setInterval(() => setRefreshKey(k => k + 1), 30000);
    return () => clearInterval(interval);
  }, []);

  const statusBadge = (status: string) => {
    switch (status) {
      case "active": return "bg-status-ok/20 text-status-ok";
      case "idle": return "bg-muted text-muted-foreground";
      case "degraded": return "bg-status-error/20 text-status-error";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <div className="space-y-4">
      {/* Summary KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { label: "API/Combo Clients", value: summary.totalClients, icon: Wifi, color: "text-chart-2" },
          { label: "Active Now", value: summary.activeCount, icon: Activity, color: "text-status-ok" },
          { label: "Degraded", value: summary.degradedCount, icon: XCircle, color: "text-status-error" },
          { label: "Total Transactions", value: summary.totalTx.toLocaleString(), icon: TrendingUp, color: "text-primary" },
          { label: "Successful", value: summary.totalSuccess.toLocaleString(), icon: CheckCircle, color: "text-status-ok" },
          { label: "Failed", value: summary.totalFailed.toLocaleString(), icon: XCircle, color: "text-status-error" },
          { label: "Avg Latency", value: `${summary.avgLatency}ms`, icon: Clock, color: "text-chart-4" },
        ].map((kpi) => (
          <div key={kpi.label} className="bg-card border border-border rounded-xl p-3">
            <div className="flex items-center gap-1.5 mb-1">
              <kpi.icon className={`w-3 h-3 ${kpi.color}`} />
              <span className="text-[9px] text-muted-foreground uppercase tracking-wider">{kpi.label}</span>
            </div>
            <p className={`text-lg font-bold ${kpi.color}`}>{kpi.value}</p>
          </div>
        ))}
      </div>

      {/* Search, Date, Filters & Actions */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search client or portfolio..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>

        {/* Date Picker */}
        <div className="flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-muted-foreground" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="px-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1.5">
          {(["all", "active", "idle", "degraded"] as const).map(s => (
            <button
              key={s}
              onClick={() => setFilterStatus(s)}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-medium transition-colors ${filterStatus === s ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 ml-auto">
          <span className="text-xs text-muted-foreground">{filtered.length} results</span>
          <button
            onClick={() => downloadCSV(filtered, selectedDate)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:bg-primary/90 transition-colors"
          >
            <Download className="w-3 h-3" />
            Export CSV
          </button>
          <button
            onClick={() => setRefreshKey(k => k + 1)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary text-muted-foreground hover:text-foreground rounded-lg text-xs transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            Refresh
          </button>
        </div>
      </div>

      {/* Client API Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border bg-muted/30">
                {["Client / Portfolio", "Ingestion", "Status", "Total Tx", "Success", "Failed", "Success %", "Avg Latency", "TPS", "Last Activity"].map(h => (
                  <th key={h} className="px-3 py-2.5 text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pagedData.map((m, i) => (
                <tr key={`${m.client.COMPANY}-${m.client.PORT}-${i}`} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                  <td className="px-3 py-2.5">
                    <div className="font-medium text-foreground">{m.client["PORTFOLIO NAME"]}</div>
                    <div className="text-[10px] text-muted-foreground">{m.client.COMPANY} · Port {m.client.PORT}</div>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${m.client["INGESTION MODE"] === "API" ? "bg-chart-2/20 text-chart-2" : "bg-accent/20 text-accent-foreground"}`}>
                      {m.client["INGESTION MODE"]}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${statusBadge(m.status)}`}>
                      {m.status}
                    </span>
                  </td>
                  <td className="px-3 py-2.5 font-mono text-foreground">{m.totalTransactions.toLocaleString()}</td>
                  <td className="px-3 py-2.5 font-mono text-status-ok">{m.successCount.toLocaleString()}</td>
                  <td className="px-3 py-2.5 font-mono text-status-error">{m.failedCount.toLocaleString()}</td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${m.successRate >= 95 ? "bg-status-ok" : m.successRate >= 90 ? "bg-chart-4" : "bg-status-error"}`}
                          style={{ width: `${m.successRate}%` }}
                        />
                      </div>
                      <span className="font-mono text-foreground">{m.successRate.toFixed(1)}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5 font-mono text-muted-foreground">{m.avgLatencyMs}ms</td>
                  <td className="px-3 py-2.5 font-mono text-foreground">{m.tps}</td>
                  <td className="px-3 py-2.5 text-muted-foreground">{m.lastActivityTime}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={10} className="px-3 py-8 text-center text-muted-foreground">No API clients matching filter</td></tr>
              )}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border">
            <span className="text-[10px] text-muted-foreground">Page {page} of {totalPages} · {filtered.length} records</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 transition-colors">
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                <button key={p} onClick={() => setPage(p)} className={`px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors ${p === page ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}>
                  {p}
                </button>
              ))}
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 transition-colors">
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}