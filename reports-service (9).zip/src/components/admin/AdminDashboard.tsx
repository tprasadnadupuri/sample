import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { ThemeProvider } from "@/hooks/useTheme";
import { ThemeToggle } from "@/components/dashboard/ThemeToggle";
import { PopulationChart } from "@/components/dashboard/PopulationChart";
import { clientData } from "@/data/clientData";
import { ClientData } from "@/types/client";
import { LogOut, Search, Filter, Activity, Users, Database, Wifi, Server, Clock, FileText, ArrowUpDown, TrendingUp, ExternalLink, ChevronLeft, ChevronRight, AlertTriangle, BarChart3, Shield } from "lucide-react";
import { LiveBatchMonitor } from "./LiveBatchMonitor";
import { APIProgressMonitor } from "./APIProgressMonitor";
import { MonitoringPanel } from "./MonitoringPanel";
import { ExecutiveSummary } from "./ExecutiveSummary";
import { ErrorTrendsDashboard } from "./ErrorTrendsDashboard";

type ViewMode = "overview" | "batch-monitor" | "api-progress" | "monitoring" | "executive" | "error-trends";

function AdminContent() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [view, setView] = useState<ViewMode>("overview");
  const [search, setSearch] = useState("");
  const [filterIngestion, setFilterIngestion] = useState<"all" | "BATCH" | "API" | "COMBO">("all");
  const [filterActive, setFilterActive] = useState<"all" | "YES" | "NO">("all");
  const [sortField, setSortField] = useState<string>("PORTFOLIO NAME");
  const [sortAsc, setSortAsc] = useState(true);

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const [overviewPage, setOverviewPage] = useState(1);
  const overviewPerPage = 10;

  const activeClients = useMemo(() => clientData.filter(c => c.ACTIVE === "YES"), []);

  // Top populations for the chart
  const topPopulations = useMemo(() => {
    return [...clientData]
      .filter((r) => r.POPULATION > 0)
      .sort((a, b) => b.POPULATION - a.POPULATION)
      .slice(0, 10)
      .map((r) => ({
        name: `${r.COMPANY.trim().slice(0, 20)}${r.PORT ? ` (P${r.PORT})` : ""}`,
        population: r.POPULATION,
      }));
  }, []);

  // Limit to 2 records per client type
  const filteredData = useMemo(() => {
    let data = [...clientData];

    if (search) {
      const s = search.toLowerCase();
      data = data.filter(c =>
        c["PORTFOLIO NAME"].toLowerCase().includes(s) ||
        c.COMPANY.toLowerCase().includes(s) ||
        c.PORT.toLowerCase().includes(s)
      );
    }
    if (filterIngestion !== "all") {
      data = data.filter(c => c["INGESTION MODE"] === filterIngestion);
    }
    if (filterActive !== "all") {
      data = data.filter(c => c.ACTIVE === filterActive);
    }

    data.sort((a, b) => {
      const aVal = String(a[sortField as keyof ClientData] ?? "");
      const bVal = String(b[sortField as keyof ClientData] ?? "");
      return sortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    });

    // Limit to 2 per client type
    const typeCounts: Record<string, number> = {};
    data = data.filter(c => {
      const ct = c["CLIENT TYPE"] || "Other";
      typeCounts[ct] = (typeCounts[ct] || 0) + 1;
      return typeCounts[ct] <= 2;
    });

    return data;
  }, [search, filterIngestion, filterActive, sortField, sortAsc]);

  const overviewTotalPages = Math.ceil(filteredData.length / overviewPerPage);
  const pagedOverviewData = filteredData.slice((overviewPage - 1) * overviewPerPage, overviewPage * overviewPerPage);

  const stats = useMemo(() => {
    const active = clientData.filter(c => c.ACTIVE === "YES");
    const batchCount = clientData.filter(c => c["INGESTION MODE"] === "BATCH").length;
    const apiCount = clientData.filter(c => c["INGESTION MODE"] === "API").length;
    const comboCount = clientData.filter(c => c["INGESTION MODE"] === "COMBO").length;
    const totalPop = active.reduce((sum, c) => sum + (c.POPULATION || 0), 0);
    return { total: clientData.length, active: active.length, batchCount, apiCount, comboCount, totalPop };
  }, []);

  const toggleSort = (field: string) => {
    if (sortField === field) setSortAsc(!sortAsc);
    else { setSortField(field); setSortAsc(true); }
  };

  const ingestionBadge = (mode: string) => {
    switch (mode) {
      case "API": return "bg-chart-2/20 text-chart-2";
      case "BATCH": return "bg-chart-4/20 text-chart-4";
      case "COMBO": return "bg-accent/20 text-accent-foreground";
      default: return "bg-muted text-muted-foreground";
    }
  };

  const ingestionLabel = (mode: string) => mode;

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card/95 backdrop-blur border-b border-border">
        <div className="max-w-[1600px] mx-auto px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-foreground tracking-tight">Consumer Monitor Dashboard</h1>
              <p className="text-[10px] text-muted-foreground">Admin Control Panel</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {user && (
              <span className="text-xs text-muted-foreground hidden sm:block">
                {user.username} • {user.role} • {user.company}
              </span>
            )}
            <ThemeToggle />
            <button onClick={handleLogout} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-5 py-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
          {[
            { label: "Total Clients", value: stats.total, icon: Users, color: "text-foreground" },
            { label: "Active", value: stats.active, icon: Activity, color: "text-status-ok" },
            { label: "Batch Ingestion", value: stats.batchCount, icon: Server, color: "text-chart-4" },
            { label: "API Ingestion", value: stats.apiCount, icon: Wifi, color: "text-chart-2" },
            { label: "Combo", value: stats.comboCount, icon: Database, color: "text-accent-foreground" },
            { label: "Total Population", value: stats.totalPop.toLocaleString(), icon: FileText, color: "text-primary" },
          ].map((kpi) => (
            <div key={kpi.label} className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1">
                <kpi.icon className={`w-3.5 h-3.5 ${kpi.color}`} />
                <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{kpi.label}</span>
              </div>
              <p className={`text-xl font-bold ${kpi.color}`}>{kpi.value}</p>
            </div>
          ))}
        </div>

        {/* View Tabs */}
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          {([
            { key: "overview", label: "Client-Portfolio Overview", icon: Users },
            { key: "batch-monitor", label: "Live Batch Monitor", icon: Clock },
            { key: "api-progress", label: "API Progress", icon: TrendingUp },
            { key: "monitoring", label: "Monitoring", icon: AlertTriangle },
            { key: "executive", label: "Executive Summary", icon: Shield },
            { key: "error-trends", label: "Error Trends", icon: BarChart3 },
          ] as { key: ViewMode; label: string; icon: typeof Users }[]).map((tab) => (
            <button
              key={tab.key}
              onClick={() => setView(tab.key)}
              className={`px-4 py-2 rounded-lg text-xs font-medium transition-colors ${view === tab.key ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              <tab.icon className="w-3.5 h-3.5 inline mr-1.5" />
              {tab.label}
            </button>
          ))}
        </div>

        {view === "overview" ? (
          <>
            {/* Filters */}
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <div className="relative flex-1 min-w-[200px] max-w-sm">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search client or portfolio..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
              <div className="flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-muted-foreground" />
                <select value={filterIngestion} onChange={(e) => setFilterIngestion(e.target.value as any)} className="px-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground">
                  <option value="all">All Ingestion</option>
                  <option value="BATCH">Batch</option>
                  <option value="API">API</option>
                  <option value="COMBO">Combo</option>
                </select>
                <select value={filterActive} onChange={(e) => setFilterActive(e.target.value as any)} className="px-3 py-2 bg-input border border-border rounded-lg text-xs text-foreground">
                  <option value="all">All Status</option>
                  <option value="YES">Active</option>
                  <option value="NO">Inactive</option>
                </select>
              </div>
              <span className="text-xs text-muted-foreground ml-auto">{filteredData.length} results</span>
            </div>

            {/* Table */}
            <div className="bg-card border border-border rounded-xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border bg-muted/30">
                      {[
                        { key: "COMPANY", label: "Company" },
                        { key: "PORT", label: "Port" },
                        { key: "PORTFOLIO NAME", label: "Portfolio Name" },
                        { key: "INGESTION MODE", label: "Ingestion" },
                        { key: "ACTIVE", label: "Status" },
                        { key: "CLIENT TYPE", label: "Client Type" },
                        { key: "POPULATION", label: "Population" },
                        { key: "TYPE", label: "Type" },
                        { key: "LAST FULL FILE PROCESSED DATE", label: "Last Full File" },
                        { key: "RUN TYPE", label: "Run Type" },
                        { key: "ACTIONS", label: "Actions", noSort: true },
                      ].map(col => (
                        <th
                          key={col.key}
                          onClick={"noSort" in col ? undefined : () => toggleSort(col.key)}
                          className={`px-3 py-2.5 text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider select-none ${"noSort" in col ? "" : "cursor-pointer hover:text-foreground"}`}
                        >
                          <span className="flex items-center gap-1">
                            {col.label}
                            {!("noSort" in col) && <ArrowUpDown className="w-3 h-3 opacity-40" />}
                          </span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {pagedOverviewData.map((row, i) => (
                      <tr key={`${row.COMPANY}-${row.PORT}-${i}`} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                        <td className="px-3 py-2.5 font-medium text-foreground">{row.COMPANY}</td>
                        <td className="px-3 py-2.5 text-muted-foreground">{row.PORT}</td>
                        <td className="px-3 py-2.5 text-foreground max-w-[200px] truncate">{row["PORTFOLIO NAME"]}</td>
                        <td className="px-3 py-2.5">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${ingestionBadge(row["INGESTION MODE"])}`}>
                            {ingestionLabel(row["INGESTION MODE"])}
                          </span>
                        </td>
                        <td className="px-3 py-2.5">
                          <span className={`w-2 h-2 rounded-full inline-block mr-1.5 ${row.ACTIVE === "YES" ? "bg-status-ok" : "bg-muted-foreground/30"}`} />
                          <span className={row.ACTIVE === "YES" ? "text-status-ok" : "text-muted-foreground"}>{row.ACTIVE || "—"}</span>
                        </td>
                        <td className="px-3 py-2.5 text-muted-foreground">{row["CLIENT TYPE"] || "—"}</td>
                        <td className="px-3 py-2.5 text-foreground font-mono">{(row.POPULATION || 0).toLocaleString()}</td>
                        <td className="px-3 py-2.5 text-muted-foreground">{row.TYPE}</td>
                        <td className="px-3 py-2.5 text-muted-foreground">{row["LAST FULL FILE PROCESSED DATE"] || "—"}</td>
                        <td className="px-3 py-2.5 text-muted-foreground">{row["RUN TYPE"] || "—"}</td>
                        <td className="px-3 py-2.5">
                          <button
                            onClick={() => navigate("/sandbox")}
                            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[10px] font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            View Dashboard
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {/* Pagination */}
              {overviewTotalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                  <span className="text-[10px] text-muted-foreground">
                    Page {overviewPage} of {overviewTotalPages} · {filteredData.length} records
                  </span>
                  <div className="flex items-center gap-1">
                    <button onClick={() => setOverviewPage(p => Math.max(1, p - 1))} disabled={overviewPage === 1} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 transition-colors">
                      <ChevronLeft className="w-3.5 h-3.5" />
                    </button>
                    {Array.from({ length: overviewTotalPages }, (_, i) => i + 1).map(p => (
                      <button key={p} onClick={() => setOverviewPage(p)} className={`px-2.5 py-1 rounded-md text-[10px] font-medium transition-colors ${p === overviewPage ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`}>
                        {p}
                      </button>
                    ))}
                    <button onClick={() => setOverviewPage(p => Math.min(overviewTotalPages, p + 1))} disabled={overviewPage === overviewTotalPages} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted disabled:opacity-30 transition-colors">
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Top Populations Chart */}
            <div className="mt-4">
              <PopulationChart data={topPopulations} />
            </div>
          </>
        ) : view === "batch-monitor" ? (
          <LiveBatchMonitor clients={activeClients} />
        ) : view === "api-progress" ? (
          <APIProgressMonitor clients={activeClients} />
        ) : view === "monitoring" ? (
          <MonitoringPanel />
        ) : view === "executive" ? (
          <ExecutiveSummary />
        ) : (
          <ErrorTrendsDashboard />
        )}

        <footer className="mt-8 text-center text-xs text-muted-foreground py-4">
          © 2025 MCM Consumer Monitor — Admin Dashboard
        </footer>
      </main>
    </div>
  );
}

export function AdminDashboard() {
  return (
    <ThemeProvider>
      <AdminContent />
    </ThemeProvider>
  );
}
