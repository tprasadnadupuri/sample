import { Users, Database, FileCheck, FilePlus, Activity, RefreshCw } from "lucide-react";
import { KPIData } from "@/types/client";

interface KPICardsProps {
  data: KPIData;
  onTransactionClick?: () => void;
}

function formatNumber(n: number): string {
  return n.toLocaleString();
}

function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + "...";
}

export function KPICards({ data, onTransactionClick }: KPICardsProps) {
  const isApiMode = data.isApiMode;

  const cards = [
    {
      label: "Active Clients",
      value: data.activeClients.toString(),
      icon: Users,
      color: "text-status-ok",
      bgColor: "bg-status-ok/10",
      clickable: false,
    },
    {
      label: "Total Monitored Population",
      value: formatNumber(data.totalPopulation),
      icon: Database,
      color: "text-primary",
      bgColor: "bg-primary/10",
      clickable: false,
    },
    ...(isApiMode && data.totalTransactions !== undefined
      ? [
          {
            label: "Total API Transactions",
            value: formatNumber(data.totalTransactions),
            subtitle: data.totalTransactions > 0 ? "Click to view details" : undefined,
            icon: Activity,
            color: "text-chart-2",
            bgColor: "bg-chart-2/10",
            clickable: data.totalTransactions > 0,
            onClick: data.totalTransactions > 0 ? onTransactionClick : undefined,
          },
        ]
      : [
          {
            label: "Latest Full File Processed",
            value: truncateText(data.lastFullFile, 32),
            icon: FileCheck,
            color: "text-chart-4",
            bgColor: "bg-chart-4/10",
            isFile: true,
            clickable: false,
          },
        ]),
    {
      label: isApiMode ? "Add/Del via API" : "Latest Add/Del File Processed",
      value: isApiMode && data.addDelCount !== undefined 
        ? `${data.addDelCount} records` 
        : truncateText(data.lastAddDelFile, 32),
      icon: FilePlus,
      color: "text-status-warn",
      bgColor: "bg-status-warn/10",
      isFile: !isApiMode,
      clickable: false,
    },
    ...(data.reprocessedViaApi && data.reprocessedViaApi > 0
      ? [
          {
            label: "Batch Errors → API Reprocessed",
            value: data.reprocessedViaApi.toString(),
            subtitle: "Click to view breakdown",
            icon: RefreshCw,
            color: "text-accent",
            bgColor: "bg-accent/10",
            clickable: true,
            onClick: onTransactionClick,
          },
        ]
      : []),
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
      {cards.map((card, i) => (
        <div
          key={i}
          onClick={card.clickable && card.onClick ? card.onClick : undefined}
          className={`bg-card border border-border rounded-xl p-4 animate-fade-in ${
            card.clickable ? "cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all" : ""
          }`}
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
              <p
                className={`font-bold ${card.isFile ? "text-sm" : "text-2xl"} truncate`}
                title={card.isFile ? card.value : undefined}
              >
                {card.value}
              </p>
              {"subtitle" in card && card.subtitle && (
                <p className="text-[10px] text-muted-foreground mt-1">{card.subtitle}</p>
              )}
            </div>
            <div className={`${card.bgColor} p-2 rounded-lg`}>
              <card.icon className={`w-4 h-4 ${card.color}`} />
            </div>
          </div>
          {card.clickable && (
            <p className="text-[10px] text-primary mt-2">Click to view details →</p>
          )}
        </div>
      ))}
    </div>
  );
}
