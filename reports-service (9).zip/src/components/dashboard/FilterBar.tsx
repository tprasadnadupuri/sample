import { Search } from "lucide-react";
import { FilterState } from "@/types/client";

interface FilterBarProps {
  filters: FilterState;
  onFilterChange: <K extends keyof FilterState>(key: K, value: FilterState[K]) => void;
}

export function FilterBar({ filters, onFilterChange }: FilterBarProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 mb-4">
      {/* Search Input */}
      <div className="relative lg:col-span-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search company / portfolio..."
          value={filters.search}
          onChange={(e) => onFilterChange("search", e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-input border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
        />
      </div>

      {/* Active Filter */}
      <select
        value={filters.active}
        onChange={(e) => onFilterChange("active", e.target.value as FilterState["active"])}
        className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all cursor-pointer"
      >
        <option value="all">Active: All</option>
        <option value="YES">Active: YES</option>
        <option value="NO">Active: NO</option>
      </select>

      {/* Type Filter */}
      <select
        value={filters.type}
        onChange={(e) => onFilterChange("type", e.target.value as FilterState["type"])}
        className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all cursor-pointer"
      >
        <option value="all">Type: All</option>
        <option value="D">Type: D</option>
        <option value="R">Type: R</option>
        <option value="B">Type: B</option>
      </select>

      {/* Client Type Filter */}
      <select
        value={filters.clientType}
        onChange={(e) => onFilterChange("clientType", e.target.value as FilterState["clientType"])}
        className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all cursor-pointer"
      >
        <option value="all">Client Type: All</option>
        <option value="STS">STS</option>
        <option value="I&D">I&D</option>
        <option value="ECS">ECS</option>
      </select>

      {/* Ingestion Filter */}
      <select
        value={filters.ingestion}
        onChange={(e) => onFilterChange("ingestion", e.target.value as FilterState["ingestion"])}
        className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all cursor-pointer"
      >
        <option value="all">Ingestion: All</option>
        <option value="BATCH">Ingestion: BATCH</option>
        <option value="API">Ingestion: API</option>
        <option value="COMBO">Ingestion: COMBO</option>
      </select>

      {/* Period Filter */}
      <select
        value={filters.period}
        onChange={(e) => onFilterChange("period", e.target.value as FilterState["period"])}
        className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all cursor-pointer"
      >
        <option value="Day">Period: Day</option>
        <option value="Week">Period: Week</option>
        <option value="Month">Period: Month</option>
      </select>
    </div>
  );
}
