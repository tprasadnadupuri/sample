import { useState, useEffect } from "react";
import { ArrowLeft, CheckCircle, Clock, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { ThemeProvider } from "@/hooks/useTheme";
import { SandboxHeader } from "./SandboxHeader";
import { SuccessRecord } from "@/types/sandbox";

function generateMockSuccesses(): SuccessRecord[] {
  const types = ["Full File", "Add/Del", "Real-time API", "Batch Update", "Delta Sync"];
  const sources = ["CBC/Fidelity Bank", "Mission Loans LLC", "JP Morgan Chase", "Navy Federal", "Social Mortgage"];
  
  return Array.from({ length: 50 }, (_, i) => ({
    id: `SUC-${Date.now()}-${i}`,
    timestamp: new Date(Date.now() - Math.random() * 3600000).toISOString(),
    type: types[Math.floor(Math.random() * types.length)],
    source: sources[Math.floor(Math.random() * sources.length)],
    latency: Math.floor(Math.random() * 800 + 100),
  }));
}

function SuccessDashboardContent() {
  const navigate = useNavigate();
  const [records, setRecords] = useState<SuccessRecord[]>([]);

  useEffect(() => {
    setRecords(generateMockSuccesses());
  }, []);

  const avgLatency = records.length > 0 
    ? Math.round(records.reduce((acc, r) => acc + r.latency, 0) / records.length)
    : 0;

  const byType = records.reduce((acc, r) => {
    acc[r.type] = (acc[r.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      <SandboxHeader />
      
      <main className="max-w-[1400px] mx-auto px-5 py-6">
        {/* Back Button */}
        <button
          onClick={() => navigate("/sandbox")}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm">Back to Sandbox</span>
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-status-ok/10 flex items-center justify-center">
            <CheckCircle className="w-5 h-5 text-status-ok" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">Success Dashboard</h1>
            <p className="text-sm text-muted-foreground">
              {records.length} successful operations • Avg latency: {avgLatency}ms
            </p>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
          {Object.entries(byType).map(([type, count]) => (
            <div key={type} className="bg-card border border-border rounded-xl p-4">
              <p className="text-xs text-muted-foreground mb-1">{type}</p>
              <p className="text-xl font-bold text-status-ok">{count}</p>
            </div>
          ))}
        </div>

        {/* Success Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-auto max-h-[60vh]">
            <table className="w-full border-collapse text-sm">
              <thead className="sticky top-0 z-10">
                <tr className="bg-input">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Source</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Latency</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {records.map((record) => (
                  <tr 
                    key={record.id}
                    className="border-b border-border/50 hover:bg-input/50 transition-colors"
                  >
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{record.id.slice(0, 16)}...</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 bg-status-ok/10 text-status-ok text-[11px] rounded">
                        {record.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-foreground">{record.source}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1.5">
                        <TrendingUp className={`w-3 h-3 ${record.latency < 300 ? "text-status-ok" : record.latency < 600 ? "text-status-warn" : "text-status-bad"}`} />
                        <span className="text-foreground">{record.latency}ms</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(record.timestamp).toLocaleTimeString()}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}

export function SuccessDashboard() {
  return (
    <ThemeProvider>
      <SuccessDashboardContent />
    </ThemeProvider>
  );
}
