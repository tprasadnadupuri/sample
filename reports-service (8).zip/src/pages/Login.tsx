import { LoginPage } from "@/components/auth/LoginPage";
import { ThemeProvider } from "@/hooks/useTheme";

const Login = () => {
  return (
    <ThemeProvider>
      <LoginPage />
    </ThemeProvider>
  );
};

export default Login;
