import { ThemeProvider } from "@/hooks/useTheme";
import { Header } from "./Header";
import { FilterBar } from "./FilterBar";
import { KPICards } from "./KPICards";
import { PopulationChart } from "./PopulationChart";
import { OperationsChart } from "./OperationsChart";
import { ClientTable } from "./ClientTable";
import { useClientFilters } from "@/hooks/useClientFilters";

function DashboardContent() {
  const { filters, updateFilter, filteredData, kpis, topPopulations } =
    useClientFilters();

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      <Header />
      
      <main className="max-w-[1400px] mx-auto px-5 py-6">
        <FilterBar filters={filters} onFilterChange={updateFilter} />
        
        <KPICards data={kpis} />
        
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          <div className="lg:col-span-3">
            <PopulationChart data={topPopulations} />
          </div>
          <div className="lg:col-span-2">
            <OperationsChart period={filters.period} />
          </div>
        </div>
        
        <ClientTable data={filteredData} />
        
        <footer className="mt-8 text-center text-xs text-muted-foreground py-4">
          © 2025 MCM Client Monitoring — Production Dashboard
        </footer>
      </main>
    </div>
  );
}

export function Dashboard() {
  return (
    <ThemeProvider>
      <DashboardContent />
    </ThemeProvider>
  );
}
