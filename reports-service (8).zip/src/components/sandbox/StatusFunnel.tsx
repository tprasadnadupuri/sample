import { useState, useCallback } from "react";
import { FileText, Clock, CheckCircle, AlertTriangle, ShieldCheck, Truck, UserCheck, ChevronRight, Zap, Search, XCircle, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { IngestionMode } from "./IngestionModeTabs";

// ─── Batch File Pipeline Types ───
type FileStage = "received" | "validated" | "approval_needed" | "awaiting_approval" | "approved" | "processed" | "delivered";

interface FileEntry {
  id: string;
  fileName: string;
  arrivalTime: string;
  stage: FileStage;
  totalRecords: number;
  pinMatchRate: number;
  pinThreshold: number;
}

// ─── API Transaction Pipeline Types ───
type TxnStage = "received" | "validated" | "pinned" | "processed";
type HttpMethod = "GET" | "POST" | "PUT" | "DELETE";

interface StageDetail {
  stage: TxnStage;
  status: "completed" | "active" | "pending" | "failed";
  startTime: string;
  endTime?: string;
  duration: number; // ms
}

interface TxnLookupEntry {
  transactionId: string;
  httpMethod: HttpMethod;
  clientName: string;
  payload: string;
  totalLatency: number;
  timestamp: string;
  overallStatus: "success" | "in_progress" | "failed";
  stages: StageDetail[];
}

// ─── Batch Constants ───
const BATCH_STAGES = [
  { key: "received" as FileStage, label: "Received", icon: FileText },
  { key: "validated" as FileStage, label: "Validated", icon: CheckCircle },
  { key: "approval_needed" as FileStage, label: "BA / Client\nConfirmation", icon: AlertTriangle },
  { key: "processed" as FileStage, label: "Processed", icon: ShieldCheck },
  { key: "delivered" as FileStage, label: "Delivered", icon: Truck },
];

function getBatchStageIndex(stage: FileStage): number {
  const map: Record<FileStage, number> = {
    received: 0, validated: 1, approval_needed: 2, awaiting_approval: 2, approved: 2, processed: 3, delivered: 4,
  };
  return map[stage];
}

const STATIC_FILES: FileEntry[] = [
  { id: "1", fileName: "CHASE_FULL_20250210_001.csv", arrivalTime: "08:12 AM", totalRecords: 12400, pinMatchRate: 78, pinThreshold: 50, stage: "delivered" },
  { id: "2", fileName: "NAVY_ADDDEL_20250210_002.csv", arrivalTime: "08:34 AM", totalRecords: 3200, pinMatchRate: 42, pinThreshold: 50, stage: "approval_needed" },
];

// ─── API Constants ───
const STAGE_LABELS: Record<TxnStage, string> = { received: "Payload Received", validated: "Validated", pinned: "Pinned", processed: "Processed" };

const LOOKUP_DB: Record<string, TxnLookupEntry> = {
  "TXN-20250210-4A7F": {
    transactionId: "TXN-20250210-4A7F",
    httpMethod: "POST",
    clientName: "JP Morgan Chase",
    payload: "ADD — SSN: ***-**-1234, DOB: 1985-03-12, Name: John M. Smith",
    totalLatency: 687,
    timestamp: "2025-02-10 09:12:34",
    overallStatus: "success",
    stages: [
      { stage: "received", status: "completed", startTime: "09:12:34.000", endTime: "09:12:34.120", duration: 120 },
      { stage: "validated", status: "completed", startTime: "09:12:34.120", endTime: "09:12:34.340", duration: 220 },
      { stage: "pinned", status: "completed", startTime: "09:12:34.340", endTime: "09:12:34.535", duration: 195 },
      { stage: "processed", status: "completed", startTime: "09:12:34.535", endTime: "09:12:34.687", duration: 152 },
    ],
  },
  "TXN-20250210-8B3C": {
    transactionId: "TXN-20250210-8B3C",
    httpMethod: "DELETE",
    clientName: "Navy Federal",
    payload: "DELETE — SSN: ***-**-5678, AcctNo: ****9012",
    totalLatency: 423,
    timestamp: "2025-02-10 10:05:17",
    overallStatus: "success",
    stages: [
      { stage: "received", status: "completed", startTime: "10:05:17.000", endTime: "10:05:17.089", duration: 89 },
      { stage: "validated", status: "completed", startTime: "10:05:17.089", endTime: "10:05:17.245", duration: 156 },
      { stage: "pinned", status: "completed", startTime: "10:05:17.245", endTime: "10:05:17.340", duration: 95 },
      { stage: "processed", status: "completed", startTime: "10:05:17.340", endTime: "10:05:17.423", duration: 83 },
    ],
  },
  "TXN-20250210-C91E": {
    transactionId: "TXN-20250210-C91E",
    httpMethod: "PUT",
    clientName: "Barrett Financial",
    payload: "ADD — SSN: ***-**-3456, DOB: 1990-07-22, Addr: 742 Evergreen Terrace",
    totalLatency: 1245,
    timestamp: "2025-02-10 11:22:08",
    overallStatus: "failed",
    stages: [
      { stage: "received", status: "completed", startTime: "11:22:08.000", endTime: "11:22:08.134", duration: 134 },
      { stage: "validated", status: "completed", startTime: "11:22:08.134", endTime: "11:22:08.512", duration: 378 },
      { stage: "pinned", status: "failed", startTime: "11:22:08.512", endTime: "11:22:09.245", duration: 733 },
      { stage: "processed", status: "pending", startTime: "-", duration: 0 },
    ],
  },
  "TXN-20250210-D52A": {
    transactionId: "TXN-20250210-D52A",
    httpMethod: "GET",
    clientName: "Mission Loans LLC",
    payload: "QUERY — SSN: ***-**-7890, DOB: 1978-11-05",
    totalLatency: 312,
    timestamp: "2025-02-10 11:45:52",
    overallStatus: "success",
    stages: [
      { stage: "received", status: "completed", startTime: "11:45:52.000", endTime: "11:45:52.055", duration: 55 },
      { stage: "validated", status: "completed", startTime: "11:45:52.055", endTime: "11:45:52.178", duration: 123 },
      { stage: "pinned", status: "completed", startTime: "11:45:52.178", endTime: "11:45:52.250", duration: 72 },
      { stage: "processed", status: "completed", startTime: "11:45:52.250", endTime: "11:45:52.312", duration: 62 },
    ],
  },
};

interface StatusFunnelProps {
  funnel: any;
  onReset: () => void;
  ingestionMode?: IngestionMode;
}

export function StatusFunnel({ onReset, ingestionMode = "BATCH" }: StatusFunnelProps) {
  if (ingestionMode === "API") {
    return <APIPipeline />;
  }
  return <BatchPipeline />;
}

// ═══════════════════════════════════════════════
// API Processing Pipeline — Tabular
// ═══════════════════════════════════════════════

const METHOD_STYLES: Record<HttpMethod, string> = {
  GET: "bg-chart-2/15 text-chart-2 border-chart-2/30",
  POST: "bg-status-ok/15 text-status-ok border-status-ok/30",
  PUT: "bg-status-warn/15 text-status-warn border-status-warn/30",
  DELETE: "bg-status-bad/15 text-status-bad border-status-bad/30",
};

const STAGE_DOT: Record<TxnStage, string> = {
  received: "bg-muted-foreground",
  validated: "bg-primary",
  pinned: "bg-chart-4",
  processed: "bg-status-ok",
};

function APIPipeline() {
  const [searchId, setSearchId] = useState("");
  const [result, setResult] = useState<TxnLookupEntry | null>(null);
  const [notFound, setNotFound] = useState(false);

  const handleSearch = () => {
    const trimmed = searchId.trim().toUpperCase();
    if (!trimmed) return;
    const found = LOOKUP_DB[trimmed];
    if (found) {
      setResult(found);
      setNotFound(false);
    } else {
      setResult(null);
      setNotFound(true);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") handleSearch();
  };

  const handleClear = () => {
    setSearchId("");
    setResult(null);
    setNotFound(false);
  };

  const STAGE_ICONS: Record<TxnStage, typeof FileText> = {
    received: FileText,
    validated: CheckCircle,
    pinned: Search,
    processed: ShieldCheck,
  };

  return (
    <div className="bg-card border border-border rounded-xl p-5 h-full">
      {/* Header */}
      <div className="mb-4">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2 mb-3">
          <Zap className="w-4 h-4 text-primary" />
          API Processing Pipeline
        </h3>

        {/* Search Bar */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              value={searchId}
              onChange={(e) => setSearchId(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Enter Transaction ID (e.g. TXN-20250210-4A7F)"
              className="w-full bg-muted/50 border border-border rounded-lg pl-9 pr-9 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/50"
            />
            {searchId && (
              <button onClick={handleClear} className="absolute right-3 top-1/2 -translate-y-1/2">
                <XCircle className="w-4 h-4 text-muted-foreground hover:text-foreground transition-colors" />
              </button>
            )}
          </div>
          <button
            onClick={handleSearch}
            className="px-4 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            Lookup
          </button>
        </div>

        {/* Quick IDs */}
        <div className="flex items-center gap-2 mt-2 text-[10px] text-muted-foreground">
          <span>Try:</span>
          {Object.keys(LOOKUP_DB).map(id => (
            <button
              key={id}
              onClick={() => { setSearchId(id); setResult(LOOKUP_DB[id]); setNotFound(false); }}
              className="px-2 py-0.5 bg-muted/50 border border-border rounded-md font-mono hover:bg-muted transition-colors"
            >
              {id}
            </button>
          ))}
        </div>
      </div>

      {/* Not Found */}
      {notFound && (
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <XCircle className="w-10 h-10 text-status-bad/50 mb-3" />
          <p className="text-sm font-medium text-foreground mb-1">Transaction Not Found</p>
          <p className="text-xs text-muted-foreground">No transaction matches "<span className="font-mono">{searchId}</span>"</p>
        </div>
      )}

      {/* Empty State */}
      {!result && !notFound && (
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <Search className="w-10 h-10 text-muted-foreground/30 mb-3" />
          <p className="text-sm font-medium text-muted-foreground mb-1">Search for a Transaction</p>
          <p className="text-xs text-muted-foreground">Enter a Transaction ID from the error dashboard or transaction details to trace its pipeline stages.</p>
        </div>
      )}

      {/* Result */}
      {result && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
          {/* Overview Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-muted/30 rounded-lg p-3 border border-border/50">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Transaction ID</p>
              <p className="text-xs font-mono font-bold text-foreground">{result.transactionId}</p>
            </div>
            <div className="bg-muted/30 rounded-lg p-3 border border-border/50">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">HTTP Method</p>
              <span className={cn("px-2.5 py-1 rounded-md text-[11px] font-bold border", METHOD_STYLES[result.httpMethod])}>
                {result.httpMethod}
              </span>
            </div>
            <div className="bg-muted/30 rounded-lg p-3 border border-border/50">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Client</p>
              <p className="text-xs font-semibold text-foreground">{result.clientName}</p>
            </div>
            <div className="bg-muted/30 rounded-lg p-3 border border-border/50">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Overall Status</p>
              <span className={cn(
                "px-2.5 py-1 rounded-md text-[11px] font-bold",
                result.overallStatus === "success" ? "bg-status-ok/15 text-status-ok" :
                result.overallStatus === "failed" ? "bg-status-bad/15 text-status-bad" :
                "bg-status-warn/15 text-status-warn"
              )}>
                {result.overallStatus === "success" ? "✓ Completed" : result.overallStatus === "failed" ? "✗ Failed" : "⟳ In Progress"}
              </span>
            </div>
          </div>

          {/* Payload */}
          <div className="bg-muted/20 rounded-lg p-3 border border-border/50">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1">Payload</p>
            <p className="text-xs font-mono text-foreground">{result.payload}</p>
          </div>

          {/* Stage Pipeline Diagram */}
          <div>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-3">Pipeline Stages</p>
            <div className="flex items-start justify-between relative">
              {result.stages.map((s, i) => {
                const Icon = STAGE_ICONS[s.stage];
                return (
                  <div key={s.stage} className="flex items-start flex-1">
                    <div className="flex flex-col items-center gap-1.5 w-full relative z-10">
                      <div className={cn(
                        "w-11 h-11 rounded-xl flex items-center justify-center border-2 transition-all shadow-sm",
                        s.status === "completed" && "border-status-ok bg-status-ok/15 shadow-status-ok/20",
                        s.status === "active" && "border-primary bg-primary/15 shadow-primary/20 animate-pulse",
                        s.status === "failed" && "border-status-bad bg-status-bad/15 shadow-status-bad/20",
                        s.status === "pending" && "border-border bg-muted/30",
                      )}>
                        <Icon className={cn(
                          "w-5 h-5",
                          s.status === "completed" && "text-status-ok",
                          s.status === "active" && "text-primary",
                          s.status === "failed" && "text-status-bad",
                          s.status === "pending" && "text-muted-foreground/40",
                        )} />
                      </div>
                      <span className="text-[10px] font-semibold text-foreground text-center">
                        {STAGE_LABELS[s.stage]}
                      </span>
                      <span className={cn(
                        "text-[10px] font-mono",
                        s.status === "completed" ? "text-status-ok" :
                        s.status === "failed" ? "text-status-bad" :
                        "text-muted-foreground/50"
                      )}>
                        {s.status === "pending" ? "—" : `${s.duration}ms`}
                      </span>
                      {s.startTime !== "-" && (
                        <span className="text-[9px] text-muted-foreground flex items-center gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {s.startTime}
                        </span>
                      )}
                      {s.status === "failed" && (
                        <span className="text-[9px] text-status-bad font-medium mt-0.5">PIN match failed</span>
                      )}
                    </div>
                    {i < result.stages.length - 1 && (
                      <div className="flex-1 flex items-center justify-center mx-1 mt-4">
                        <div className={cn(
                          "w-full h-[2px] relative",
                          s.status === "completed" ? "bg-status-ok/50" : "bg-border"
                        )}>
                          <ArrowRight className={cn(
                            "w-3.5 h-3.5 absolute -right-1 top-1/2 -translate-y-1/2",
                            s.status === "completed" ? "text-status-ok/50" : "text-muted-foreground/30"
                          )} />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Total Latency */}
          <div className="flex items-center justify-between bg-muted/20 rounded-lg p-3 border border-border/50">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">Total Latency</span>
            </div>
            <span className={cn(
              "text-sm font-bold font-mono",
              result.totalLatency < 500 ? "text-status-ok" :
              result.totalLatency < 1000 ? "text-status-warn" : "text-status-bad"
            )}>
              {result.totalLatency}ms
            </span>
          </div>

          {/* Timestamp */}
          <div className="text-[10px] text-muted-foreground text-right">
            Submitted at {result.timestamp}
          </div>
        </div>
      )}
    </div>
  );
}
// ═══════════════════════════════════════════════
// Batch File Processing Pipeline (existing)
// ═══════════════════════════════════════════════
function BatchPipeline() {
  const [files, setFiles] = useState<FileEntry[]>(STATIC_FILES);

  const needsApproval = (file: FileEntry) =>
    file.stage === "approval_needed" || file.stage === "awaiting_approval";

  const handleApprove = useCallback((fileId: string) => {
    setFiles(prev => prev.map(f => f.id === fileId ? { ...f, stage: "approved" as FileStage } : f));
    setTimeout(() => {
      setFiles(prev => prev.map(f => f.id === fileId && f.stage === "approved" ? { ...f, stage: "processed" } : f));
    }, 1500);
    setTimeout(() => {
      setFiles(prev => prev.map(f => f.id === fileId && f.stage === "processed" ? { ...f, stage: "delivered" } : f));
    }, 3500);
  }, []);

  return (
    <div className="bg-card border border-border rounded-xl p-5 h-full">
      <div className="flex items-center justify-between mb-5">
        <h3 className="text-sm font-semibold text-foreground flex items-center gap-2">
          <FileText className="w-4 h-4 text-primary" />
          File Processing Pipeline
        </h3>
      </div>

      {/* Stage Diagram Header */}
      <div className="relative flex items-center justify-between mb-6 px-2">
        {BATCH_STAGES.map((stage, i) => {
          const Icon = stage.icon;
          const filesHere = files.filter(f => getBatchStageIndex(f.stage) === i).length;
          const filesCompleted = files.filter(f => getBatchStageIndex(f.stage) > i).length;
          return (
            <div key={stage.key} className="flex items-center flex-1">
              <div className="flex flex-col items-center gap-1.5 w-full relative z-10">
                <div className={cn(
                  "w-10 h-10 rounded-xl flex items-center justify-center border-2 transition-all shadow-sm",
                  filesHere > 0
                    ? stage.key === "approval_needed"
                      ? "border-status-warn bg-status-warn/15 shadow-status-warn/20"
                      : "border-primary bg-primary/15 shadow-primary/20"
                    : filesCompleted > 0
                      ? "border-status-ok/60 bg-status-ok/10"
                      : "border-border bg-muted/40"
                )}>
                  <Icon className={cn(
                    "w-4.5 h-4.5",
                    filesHere > 0
                      ? stage.key === "approval_needed" ? "text-status-warn" : "text-primary"
                      : filesCompleted > 0 ? "text-status-ok" : "text-muted-foreground/60"
                  )} />
                </div>
                <span className="text-[9px] font-semibold text-muted-foreground uppercase tracking-wider text-center whitespace-pre-line leading-tight">
                  {stage.label}
                </span>
                {filesHere > 0 && (
                  <span className={cn(
                    "absolute -top-1.5 -right-1 min-w-[18px] h-[18px] flex items-center justify-center rounded-full text-[9px] font-bold text-white",
                    stage.key === "approval_needed" ? "bg-status-warn" : "bg-primary"
                  )}>
                    {filesHere}
                  </span>
                )}
              </div>
              {i < BATCH_STAGES.length - 1 && (
                <div className="flex-1 flex items-center justify-center mx-1 -mt-5">
                  <div className="w-full h-[2px] bg-border relative">
                    <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/50 absolute -right-1 top-1/2 -translate-y-1/2" />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* File Cards */}
      <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
        {files.map(file => {
          const fileIdx = getBatchStageIndex(file.stage);
          const halted = needsApproval(file);
          const pinOk = file.pinMatchRate >= file.pinThreshold;

          return (
            <div key={file.id} className={cn(
              "rounded-lg border transition-all",
              halted
                ? "bg-status-warn/5 border-status-warn/30"
                : file.stage === "delivered"
                  ? "bg-status-ok/5 border-status-ok/30"
                  : "bg-muted/20 border-border/60"
            )}>
              <div className="flex items-center justify-between px-3 py-2 border-b border-border/30">
                <div className="flex items-center gap-2 min-w-0">
                  <FileText className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                  <span className="text-[11px] font-semibold text-foreground truncate">{file.fileName}</span>
                </div>
                <div className="flex items-center gap-3 shrink-0 text-[10px] text-muted-foreground">
                  <span>{file.totalRecords.toLocaleString()} records</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{file.arrivalTime}</span>
                </div>
              </div>

              <div className="px-3 py-3">
                <div className="flex items-center">
                  {BATCH_STAGES.map((stage, i) => {
                    const completed = fileIdx > i;
                    const active = fileIdx === i;
                    const isApprovalStage = stage.key === "approval_needed";
                    const fileAtApproval = isApprovalStage && halted;
                    const fileApproved = isApprovalStage && file.stage === "approved";
                    const skipApproval = isApprovalStage && pinOk && !completed;

                    return (
                      <div key={stage.key} className="flex items-center flex-1">
                        <div className="flex flex-col items-center gap-0.5 w-full">
                          <div className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all relative",
                            completed && "border-status-ok bg-status-ok/15",
                            fileAtApproval && "border-status-warn bg-status-warn/15 animate-pulse",
                            fileApproved && "border-chart-4 bg-chart-4/15",
                            active && !fileAtApproval && !fileApproved && "border-primary bg-primary/15",
                            skipApproval && "border-dashed border-border bg-transparent",
                            !completed && !active && !fileAtApproval && !fileApproved && !skipApproval && "border-border bg-muted/30"
                          )}>
                            {completed ? (
                              <CheckCircle className="w-4 h-4 text-status-ok" />
                            ) : fileAtApproval ? (
                              <AlertTriangle className="w-4 h-4 text-status-warn" />
                            ) : fileApproved ? (
                              <UserCheck className="w-4 h-4 text-chart-4" />
                            ) : active ? (
                              <div className="w-3 h-3 rounded-full bg-primary" />
                            ) : skipApproval ? (
                              <ChevronRight className="w-3 h-3 text-muted-foreground/40" />
                            ) : (
                              <div className="w-2 h-2 rounded-full bg-border" />
                            )}
                          </div>
                          {fileAtApproval && (
                            <span className="text-[8px] font-semibold text-status-warn mt-0.5">PIN {file.pinMatchRate}%</span>
                          )}
                          {skipApproval && (
                            <span className="text-[7px] text-muted-foreground/50 mt-0.5">skip</span>
                          )}
                        </div>
                        {i < BATCH_STAGES.length - 1 && (
                          <div className="flex-1 flex items-center mx-0.5 -mt-2">
                            <div className={cn(
                              "w-full h-[2px] rounded-full transition-colors",
                              completed ? "bg-status-ok" : active ? "bg-primary/50" : "bg-border"
                            )} />
                            <ChevronRight className={cn(
                              "w-3 h-3 shrink-0 -ml-1",
                              completed ? "text-status-ok" : active ? "text-primary/50" : "text-border"
                            )} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {halted && (
                <div className="mx-3 mb-3 flex items-center justify-between bg-status-warn/10 border border-status-warn/25 rounded-lg px-3 py-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <AlertTriangle className="w-4 h-4 text-status-warn shrink-0" />
                    <div className="min-w-0">
                      <p className="text-[10px] font-semibold text-foreground">PIN match {file.pinMatchRate}% is below {file.pinThreshold}% threshold</p>
                      <p className="text-[9px] text-muted-foreground">BA / Client approval required to continue</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleApprove(file.id)}
                    disabled={file.stage === "awaiting_approval"}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all shrink-0 ml-3",
                      file.stage === "awaiting_approval"
                        ? "bg-muted text-muted-foreground cursor-wait"
                        : "bg-status-ok text-white hover:bg-status-ok/90 shadow-sm hover:shadow-md"
                    )}
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    Approve
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
        {[
          { label: "Total Files", value: files.length, color: "text-foreground" },
          { label: "Delivered", value: files.filter(f => f.stage === "delivered").length, color: "text-status-ok" },
          { label: "In Progress", value: files.filter(f => !["delivered", "approval_needed", "awaiting_approval"].includes(f.stage)).length, color: "text-primary" },
          { label: "Halted", value: files.filter(f => needsApproval(f)).length, color: "text-status-warn" },
        ].map(s => (
          <div key={s.label} className="text-center">
            <p className={cn("text-lg font-bold", s.color)}>{s.value}</p>
            <p className="text-[9px] text-muted-foreground font-medium">{s.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
