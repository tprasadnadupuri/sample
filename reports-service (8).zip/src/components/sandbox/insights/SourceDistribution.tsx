import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { TransactionSummary } from "@/types/transaction";

interface SourceDistributionProps {
  summary: TransactionSummary;
  mode?: "API" | "BATCH";
}

const COLORS = {
  api: "hsl(206, 58%, 53%)",
  batch: "hsl(228, 56%, 27%)",
  reprocessed: "hsl(270, 60%, 50%)",
};

export function SourceDistribution({ summary, mode = "API" }: SourceDistributionProps) {
  // Filter data based on mode
  const data = mode === "API" 
    ? [
        { name: "API Direct", value: summary.bySource.api, color: COLORS.api },
        { name: "Batch→API", value: summary.bySource.batchReprocessed, color: COLORS.reprocessed },
      ]
    : [
        { name: "Batch Files", value: summary.bySource.batch + 50, color: COLORS.batch }, // Adding base batch count
        { name: "Failed → Reprocess", value: summary.bySource.batchReprocessed, color: COLORS.reprocessed },
      ];

  const total = data.reduce((acc, d) => acc + d.value, 0);

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Source Distribution
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          ({total} total)
        </span>
      </h3>
      
      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={70}
              paddingAngle={3}
              dataKey="value"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                padding: "8px 12px",
              }}
              formatter={(value: number, name: string) => [
                `${value} (${((value / total) * 100).toFixed(1)}%)`,
                name,
              ]}
            />
            <Legend
              verticalAlign="bottom"
              height={36}
              formatter={(value) => (
                <span className="text-xs text-foreground">{value}</span>
              )}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      {/* Source breakdown */}
      <div className={`grid ${data.length === 2 ? 'grid-cols-2' : 'grid-cols-3'} gap-2 mt-2`}>
        {data.map((item) => (
          <div 
            key={item.name}
            className="text-center p-2 rounded-lg"
            style={{ backgroundColor: `${item.color}20` }}
          >
            <p className="text-lg font-bold" style={{ color: item.color }}>
              {item.value}
            </p>
            <p className="text-[10px] text-muted-foreground">{item.name}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
