import { useEffect, useMemo, useState } from "react";
import { getJson } from "@/api/http";

export type ApiListState<T> = {
  data: T[];
  loading: boolean;
  error: string | null;
  refresh: () => void;
};

/**
 * Minimal list-fetching hook (no react-query/provider required).
 * Works nicely with json-server resources.
 */
export function useApiList<T>(path: string): ApiListState<T> {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);

  const refresh = useMemo(() => () => setNonce((n) => n + 1), []);

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);

    getJson<T[]>(path, controller.signal)
      .then((rows) => setData(Array.isArray(rows) ? rows : []))
      .catch((e: unknown) => {
        const msg = e instanceof Error ? e.message : String(e);
        // If the request was aborted, don't surface an error.
        if (msg.toLowerCase().includes("aborted")) return;
        setError(msg);
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [path, nonce]);

  return { data, loading, error, refresh };
}
