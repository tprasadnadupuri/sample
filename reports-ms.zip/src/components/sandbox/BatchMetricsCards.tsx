import { FileText, FileCheck, FilePlus, TrendingUp, AlertTriangle, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface BatchMetrics {
  totalFilesProcessed: number;
  fullFiles: number;
  addDelFiles: number;
  successRate: number;
  errorRate: number;
  avgProcessingTime: number;
  lastFullFileName: string;
  lastAddDelFileName: string;
}

interface BatchMetricsCardsProps {
  metrics: BatchMetrics;
}

function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + "...";
}

export function BatchMetricsCards({ metrics }: BatchMetricsCardsProps) {
  const navigate = useNavigate();

  const cards = [
    {
      label: "Total Files Processed",
      value: metrics.totalFilesProcessed.toLocaleString(),
      subtitle: `${metrics.fullFiles} full + ${metrics.addDelFiles} add/del`,
      icon: FileText,
      color: "text-chart-1",
      bgColor: "bg-chart-1/10",
      clickable: false,
    },
    {
      label: "Latest Full File",
      value: truncateText(metrics.lastFullFileName, 24),
      subtitle: "Most recent full file ingestion",
      icon: FileCheck,
      color: "text-chart-4",
      bgColor: "bg-chart-4/10",
      isFile: true,
      clickable: false,
    },
    {
      label: "Latest Add/Del File",
      value: truncateText(metrics.lastAddDelFileName, 24),
      subtitle: "Most recent incremental update",
      icon: FilePlus,
      color: "text-status-warn",
      bgColor: "bg-status-warn/10",
      isFile: true,
      clickable: false,
    },
    {
      label: "Batch Success Rate",
      value: `${metrics.successRate.toFixed(1)}%`,
      subtitle: "Files processed without errors",
      icon: TrendingUp,
      color: "text-status-ok",
      bgColor: "bg-status-ok/10",
      clickable: true,
      onClick: () => navigate("/sandbox/success"),
    },
    {
      label: "Batch Error Rate",
      value: `${metrics.errorRate.toFixed(1)}%`,
      subtitle: "Records requiring reprocessing",
      icon: AlertTriangle,
      color: "text-status-bad",
      bgColor: "bg-status-bad/10",
      clickable: true,
      onClick: () => navigate("/sandbox/errors"),
    },
    {
      label: "Avg Processing Time",
      value: `${metrics.avgProcessingTime} min`,
      subtitle: "Per file batch processing",
      icon: Clock,
      color: "text-muted-foreground",
      bgColor: "bg-muted/30",
      clickable: false,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
      {cards.map((card, i) => (
        <div
          key={i}
          onClick={"onClick" in card && card.onClick ? card.onClick : undefined}
          className={`bg-card border border-border rounded-xl p-4 animate-fade-in ${
            card.clickable ? "cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all" : ""
          }`}
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
              <p
                className={`font-bold ${"isFile" in card && card.isFile ? "text-sm" : "text-2xl"} ${card.color} truncate`}
                title={"isFile" in card && card.isFile ? card.value : undefined}
              >
                {card.value}
              </p>
              <p className="text-[11px] text-muted-foreground mt-1">{card.subtitle}</p>
            </div>
            <div className={`${card.bgColor} p-2 rounded-lg`}>
              <card.icon className={`w-4 h-4 ${card.color}`} />
            </div>
          </div>
          {card.clickable && (
            <p className="text-[10px] text-primary mt-2">Click to view details →</p>
          )}
        </div>
      ))}
    </div>
  );
}
