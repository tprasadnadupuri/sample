import { useState, useEffect } from "react";
import { RefreshCw, AlertTriangle, Clock, XCircle, CheckCircle, Edit3, FileText, Sparkles } from "lucide-react";
import { ErrorRecord, APIPayload } from "@/types/sandbox";
import { useApiList } from "@/hooks/useApiList";
import { PayloadEditorModal } from "./PayloadEditorModal";
import { AICorrectionsModal } from "./AICorrectionsModal";
import { IngestionMode } from "./IngestionModeTabs";

interface ErrorDashboardProps {
  ingestionMode: IngestionMode;
}
// Generate a default API payload
function generateDefaultPayload(): APIPayload {
  return {
    consumer_pii: {
      ssn: "666175449",
      dob: "",
      name: {
        second_surname: null,
        surname: "CARTWRIGHTBELLIS",
        first_name: "PHAN",
        middle_name: "G",
        generation_code: null
      },
      address: {
        line1: "740 BELLIS",
        line2: "",
        city: "SAN JOSE",
        state: "CA",
        zip: "951234602"
      }
    },
    portfolios: {
      portfolio_number: [3],
      subcode: "123455"
    },
    ecs_customer_supplied_information: {
      ecs_subscription_Id: "123455",
      customer_id: "2149264",
      credit_limit_filter: "Y",
      credit_limit_value: "100",
      credit_utilization_filter: "Y",
      credit_utilization_value: "22",
      credit_balance_filter: "Y",
      credit_balance_value: "1000",
      external_client_id: "H",
      external_client_info: "123456"
    },
    experian_internal_id: {
      ecs_subscription_id: "122334",
      customer_id: "2149263674",
      borrower_flag: "P",
      experian_consumer_id: "123456"
    },
    permissible_purpose: "P"
  };
}

// Batch file names for mock data
const batchFileNames = [
  "ENROLLMENT_20240215_001.txt",
  "BATCH_DAILY_20240215.dat",
  "CLIENT_UPDATES_FEB2024.txt",
  "PORTFOLIO_SYNC_0215.dat",
  "CONSUMER_ADD_20240215.txt"
];

// Field names for batch validation errors
const batchFieldMapping: Record<string, string> = {
  "Invalid Comp/PortID": "COMP_PORT_ID",
  "Invalid Update flags": "UPDATE_FLAG",
  "Invalid Account number": "ACCOUNT_NUM",
  "Invalid Record Length": "RECORD",
  "Blank Name": "CONSUMER_NAME",
  "Blank Address": "ADDRESS_LINE1",
  "Blank SIN": "SIN",
  "Invalid SIN (Non-Numeric SIN)": "SIN",
  "Blank Data Lines": "DATA_LINE",
  "Invalid SIN": "SIN",
  "Invalid SSN": "SSN"
};

// Original values for batch validation errors
const batchOriginalValues: Record<string, string[]> = {
  "Invalid Comp/PortID": ["ABC12", "12-34", "PORT@1"],
  "Invalid Update flags": ["X", "AB", "99"],
  "Invalid Account number": ["ACC-123-456", "12345-ABC", ""],
  "Invalid Record Length": ["Short record data", "This record is way too long and exceeds the maximum allowed character limit for the fixed-width format specification"],
  "Blank Name": ["", " ", "   "],
  "Blank Address": ["", " ", "N/A"],
  "Blank SIN": ["", " "],
  "Invalid SIN (Non-Numeric SIN)": ["12345678A", "ABC123456", "123-456-789"],
  "Blank Data Lines": ["", "   "],
  "Invalid SIN": ["12345", "1234567890", "ABCDEFGHI"],
  "Invalid SSN": ["123-45-678", "12345678", "SSN123456"]
};

function generateMockErrors(): ErrorRecord[] {
  // API-specific sources
  const apiSources = ["API Gateway", "Validator Service", "Processor", "Downstream Client", "Auth Service"];
  
  // Batch-specific validation error messages
  const batchValidationMessages = [
    "Invalid Comp/PortID",
    "Invalid Update flags",
    "Invalid Account number",
    "Invalid Record Length",
    "Blank Name",
    "Blank Address",
    "Blank SIN",
    "Invalid SIN (Non-Numeric SIN)",
    "Blank Data Lines",
    "Invalid SIN",
    "Invalid SSN",
  ];
  
  // API-specific error messages
  const apiMessages = [
    "Connection timeout after 30s",
    "Rate limit exceeded",
    "Token expired",
    "Invalid API key",
    "Payload size exceeded",
    "Malformed JSON request",
    "Service unavailable",
  ];
  
  const apiErrorTypes = ["Downstream Timeout", "Rate Limit", "Auth Failed", "Schema Mismatch"];
  
  return Array.from({ length: 35 }, (_, i) => {
    const isBatchOriginated = Math.random() > 0.4;
    const isResolved = Math.random() > 0.7;
    const isRetrying = !isResolved && Math.random() > 0.5;
    
    // Batch errors are always Validation Errors with batch-specific messages
    // API errors use other error types with API-specific messages
    const errorType = isBatchOriginated 
      ? "Validation Error" 
      : apiErrorTypes[Math.floor(Math.random() * apiErrorTypes.length)];
    
    const messageKey = isBatchOriginated
      ? batchValidationMessages[Math.floor(Math.random() * batchValidationMessages.length)]
      : apiMessages[Math.floor(Math.random() * apiMessages.length)];
    
    // Batch errors use "Input file validation" as source, API uses various sources
    const source = isBatchOriginated
      ? "Input file validation"
      : apiSources[Math.floor(Math.random() * apiSources.length)];
    
    // Generate unique transaction ID for API errors
    const transactionId = !isBatchOriginated 
      ? `TXN-${Date.now()}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`
      : undefined;
    
    // Generate file info for batch errors
    const fileName = isBatchOriginated
      ? batchFileNames[Math.floor(Math.random() * batchFileNames.length)]
      : undefined;
    const rowNumber = isBatchOriginated
      ? Math.floor(Math.random() * 5000) + 1
      : undefined;
    const fieldName = isBatchOriginated
      ? batchFieldMapping[messageKey]
      : undefined;
    const originalValues = batchOriginalValues[messageKey];
    const originalValue = isBatchOriginated && originalValues
      ? originalValues[Math.floor(Math.random() * originalValues.length)]
      : undefined;
    
    return {
      id: `ERR-${Date.now()}-${i}`,
      timestamp: new Date(Date.now() - Math.random() * 3600000).toISOString(),
      type: errorType,
      message: `Failed to process record: ${messageKey}`,
      source: source,
      status: isResolved ? "resolved" : isRetrying ? "retrying" : "pending",
      originalIngestion: isBatchOriginated ? "BATCH" : "API",
      reprocessedViaApi: isBatchOriginated && (isResolved || isRetrying) ? Math.random() > 0.5 : false,
      // API-specific
      transactionId,
      payload: !isBatchOriginated ? generateDefaultPayload() : undefined,
      // Batch-specific
      fileName,
      rowNumber,
      fieldName,
      originalValue
    };
  });
}

// Sub-filter options based on ingestion mode
type APISubFilter = "all" | "api-only" | "batch-via-api";
type BatchSubFilter = "batch-only";

export function ErrorDashboard({ ingestionMode }: ErrorDashboardProps) {
  const [errors, setErrors] = useState<ErrorRecord[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [isRetrying, setIsRetrying] = useState(false);
  const [apiSubFilter, setApiSubFilter] = useState<APISubFilter>("all");
  
  // Modal states
  const [payloadEditorError, setPayloadEditorError] = useState<ErrorRecord | null>(null);
  const [aiCorrectionError, setAiCorrectionError] = useState<ErrorRecord | null>(null);

  // json-server endpoint: GET /errors
  const { data: apiErrors, error: apiError } = useApiList<ErrorRecord>("/errors");

  // Load from json-server. If it's not running, fall back to the in-app generator.
  useEffect(() => {
    if (apiErrors.length > 0) {
      setErrors(apiErrors);
      return;
    }
    if (apiError) {
      setErrors(generateMockErrors());
    }
  }, [apiErrors, apiError]);

  // Reset sub-filter when switching modes
  useEffect(() => {
    setApiSubFilter("all");
  }, [ingestionMode]);

  // Filter based on ingestion mode tab and sub-filter:
  // API tab: Show API originated + Batch via API (reprocessed), with sub-filter options
  // BATCH tab: Show Batch originated only (not reprocessed) - no sub-filter needed
  const filteredErrors = errors.filter(e => {
    if (ingestionMode === "API") {
      const isApiOrReprocessed = e.originalIngestion === "API" || e.reprocessedViaApi;
      if (!isApiOrReprocessed) return false;
      
      // Apply sub-filter
      if (apiSubFilter === "api-only") {
        return e.originalIngestion === "API";
      }
      if (apiSubFilter === "batch-via-api") {
        return e.reprocessedViaApi === true;
      }
      return true; // "all" - show both
    }
    // BATCH tab: Only show BATCH originated that are NOT reprocessed
    return e.originalIngestion === "BATCH" && !e.reprocessedViaApi;
  });

  const handleSelectAll = () => {
    if (selectedIds.size === errors.filter(e => e.status === "pending").length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(errors.filter(e => e.status === "pending").map(e => e.id)));
    }
  };

  const handleSelect = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  const handleRetrigger = () => {
    if (selectedIds.size === 0) return;
    
    setIsRetrying(true);
    setTimeout(() => {
      setErrors(prev => prev.map(e => 
        selectedIds.has(e.id) ? { ...e, status: "retrying" as const, reprocessedViaApi: e.originalIngestion === "BATCH" } : e
      ));
      setSelectedIds(new Set());
      setIsRetrying(false);
      
      // Simulate some becoming resolved (reprocessed via API)
      setTimeout(() => {
        setErrors(prev => prev.map(e => 
          e.status === "retrying" && Math.random() > 0.3 
            ? { ...e, status: "resolved" as const, reprocessedViaApi: e.originalIngestion === "BATCH" } 
            : e
        ));
      }, 2000);
    }, 1000);
  };

  const handlePayloadRetrigger = (error: ErrorRecord, updatedPayload: APIPayload) => {
    setErrors(prev => prev.map(e => 
      e.id === error.id ? { ...e, payload: updatedPayload, status: "retrying" as const } : e
    ));
    setPayloadEditorError(null);
    
    // Simulate resolution
    setTimeout(() => {
      setErrors(prev => prev.map(e => 
        e.id === error.id ? { ...e, status: "resolved" as const } : e
      ));
    }, 2000);
  };

  const handleAICorrection = (error: ErrorRecord, correctedValue: string, correctedPayload?: APIPayload) => {
    setErrors(prev => prev.map(e => {
      if (e.id !== error.id) return e;
      return {
        ...e,
        originalValue: correctedValue,
        payload: correctedPayload || e.payload,
        status: "retrying" as const,
        reprocessedViaApi: e.originalIngestion === "BATCH"
      };
    }));
    setAiCorrectionError(null);
    
    // Simulate resolution
    setTimeout(() => {
      setErrors(prev => prev.map(e => 
        e.id === error.id ? { ...e, status: "resolved" as const } : e
      ));
    }, 2000);
  };

  const handleRowClick = (error: ErrorRecord) => {
    if (error.status !== "pending") return;
    
    // Check if it's a PII validation error
    const isPIIError = error.message.includes("SIN") || 
                       error.message.includes("SSN") || 
                       error.message.includes("Name") || 
                       error.message.includes("Address");
    
    if (isPIIError) {
      setAiCorrectionError(error);
    } else if (error.originalIngestion === "API") {
      setPayloadEditorError(error);
    } else {
      // Batch non-PII errors also get AI assistance
      setAiCorrectionError(error);
    }
  };

  // Calculate counts based on filtered view
  const pendingCount = filteredErrors.filter(e => e.status === "pending").length;
  const retryingCount = filteredErrors.filter(e => e.status === "retrying").length;
  const resolvedCount = filteredErrors.filter(e => e.status === "resolved").length;
  
  // Summary counts for the current mode
  const apiOriginated = filteredErrors.filter(e => e.originalIngestion === "API").length;
  const batchReprocessedViaApi = filteredErrors.filter(e => e.originalIngestion === "BATCH" && e.reprocessedViaApi).length;
  const batchOriginated = filteredErrors.filter(e => e.originalIngestion === "BATCH" && !e.reprocessedViaApi).length;

  const statusIcons = {
    pending: <XCircle className="w-4 h-4 text-status-bad" />,
    retrying: <RefreshCw className="w-4 h-4 text-status-warn animate-spin" />,
    resolved: <CheckCircle className="w-4 h-4 text-status-ok" />,
  };

  return (
    <>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-status-bad/10 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5 text-status-bad" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">
              {ingestionMode === "API" ? "API Ingestion" : "Batch Ingestion"} Errors
            </h1>
            <p className="text-sm text-muted-foreground">
              {filteredErrors.length} errors • {pendingCount} pending • {retryingCount} retrying • {resolvedCount} resolved
            </p>
          </div>
        </div>
        
        <button
          onClick={handleRetrigger}
          disabled={selectedIds.size === 0 || isRetrying}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <RefreshCw className={`w-4 h-4 ${isRetrying ? "animate-spin" : ""}`} />
          Retrigger via API ({selectedIds.size})
        </button>
      </div>

      {/* Sub-Filter Dropdown - Only for API mode */}
      {ingestionMode === "API" && (
        <div className="flex items-center gap-3 mb-4">
          <label className="text-xs text-muted-foreground">Filter:</label>
          <select
            value={apiSubFilter}
            onChange={(e) => setApiSubFilter(e.target.value as APISubFilter)}
            className="px-3 py-1.5 text-sm bg-input border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          >
            <option value="all">All API Errors (API + Batch via API)</option>
            <option value="api-only">API Only</option>
            <option value="batch-via-api">Batch via API Only</option>
          </select>
        </div>
      )}

      {/* Info banner for Batch mode */}
      {ingestionMode === "BATCH" && (
        <div className="flex items-center gap-2 mb-4 px-3 py-2 bg-muted/50 border border-border rounded-lg text-xs text-muted-foreground">
          <RefreshCw className="w-3.5 h-3.5 text-accent" />
          <span>Batch errors reprocessed via API are shown in the <strong className="text-foreground">API Ingestion</strong> tab.</span>
        </div>
      )}

      {/* Mode-Specific Summary Cards */}
      {ingestionMode === "API" ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">API Originated</p>
            <p className="text-lg font-bold text-chart-2">{apiOriginated}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">BATCH → API Reprocessed</p>
            <p className="text-lg font-bold text-accent">{batchReprocessedViaApi}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">Pending</p>
            <p className="text-lg font-bold text-status-bad">{pendingCount}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">Resolved</p>
            <p className="text-lg font-bold text-status-ok">{resolvedCount}</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">BATCH Originated</p>
            <p className="text-lg font-bold text-chart-1">{batchOriginated}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">Pending</p>
            <p className="text-lg font-bold text-status-bad">{pendingCount}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">Retrying</p>
            <p className="text-lg font-bold text-status-warn">{retryingCount}</p>
          </div>
          <div className="bg-card border border-border rounded-xl p-3">
            <p className="text-[10px] text-muted-foreground">Resolved</p>
            <p className="text-lg font-bold text-status-ok">{resolvedCount}</p>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex items-center gap-4 mb-4 text-xs text-muted-foreground">
        {ingestionMode === "API" && (
          <span className="flex items-center gap-1.5">
            <Edit3 className="w-3.5 h-3.5 text-primary" />
            Click API row to edit payload
          </span>
        )}
        <span className="flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-primary" />
          {ingestionMode === "API" ? "Click PII errors for AI assistance" : "Click row for AI assistance"}
        </span>
      </div>

        {/* Error Table */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="overflow-auto max-h-[70vh]">
            <table className="w-full border-collapse text-sm">
              <thead className="sticky top-0 z-10">
                <tr className="bg-input">
                  <th className="px-4 py-3 text-left">
                    <input
                      type="checkbox"
                      checked={selectedIds.size === pendingCount && pendingCount > 0}
                      onChange={handleSelectAll}
                      className="rounded border-border"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Ingestion</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">ID / File</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Message</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Source</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Timestamp</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredErrors.map((error) => (
                  <tr 
                    key={error.id}
                    onClick={() => handleRowClick(error)}
                    className={`border-b border-border/50 transition-colors ${
                      error.status === "pending" 
                        ? "hover:bg-primary/5 cursor-pointer" 
                        : "hover:bg-input/50"
                    }`}
                  >
                    <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={selectedIds.has(error.id)}
                        onChange={() => handleSelect(error.id)}
                        disabled={error.status !== "pending"}
                        className="rounded border-border disabled:opacity-30"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {statusIcons[error.status]}
                        <span className="text-xs capitalize">{error.status}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex flex-col gap-1">
                        <span className={`px-2 py-0.5 text-[10px] rounded font-medium ${
                          error.originalIngestion === "BATCH" 
                            ? "bg-chart-1/10 text-chart-1" 
                            : "bg-chart-2/10 text-chart-2"
                        }`}>
                          {error.originalIngestion}
                        </span>
                        {error.reprocessedViaApi && (
                          <span className="px-2 py-0.5 bg-accent/10 text-accent text-[9px] rounded flex items-center gap-1">
                            <RefreshCw className="w-2.5 h-2.5" />
                            via API
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      {error.originalIngestion === "API" ? (
                        <span className="font-mono text-xs text-primary">{error.transactionId}</span>
                      ) : (
                        <div className="flex flex-col gap-0.5">
                          <span className="flex items-center gap-1 text-xs text-foreground">
                            <FileText className="w-3 h-3 text-chart-1" />
                            {error.fileName}
                          </span>
                          <span className="text-[10px] text-muted-foreground">Row {error.rowNumber}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 bg-status-bad/10 text-status-bad text-[11px] rounded">
                        {error.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-foreground max-w-md truncate">{error.message}</td>
                    <td className="px-4 py-3 text-muted-foreground">{error.source}</td>
                    <td className="px-4 py-3 text-muted-foreground text-xs">
                      <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(error.timestamp).toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                      {error.status === "pending" && (
                        <div className="flex items-center gap-1">
                          {error.originalIngestion === "API" && (
                            <button
                              onClick={() => setPayloadEditorError(error)}
                              className="p-1.5 hover:bg-input rounded text-primary transition-colors"
                              title="Edit Payload"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => setAiCorrectionError(error)}
                            className="p-1.5 hover:bg-input rounded text-primary transition-colors"
                            title="AI Assistance"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      {/* Modals */}
      {payloadEditorError && (
        <PayloadEditorModal
          error={payloadEditorError}
          onClose={() => setPayloadEditorError(null)}
          onRetrigger={handlePayloadRetrigger}
        />
      )}

      {aiCorrectionError && (
        <AICorrectionsModal
          error={aiCorrectionError}
          onClose={() => setAiCorrectionError(null)}
          onApplyCorrection={handleAICorrection}
        />
      )}
    </>
  );
}
