import { ArrowUpRight, ArrowDownRight, CheckCircle, XCircle } from "lucide-react";
import { TransactionSummary } from "@/types/transaction";

interface EnrollmentFunnelProps {
  summary: TransactionSummary;
}

export function EnrollmentFunnel({ summary }: EnrollmentFunnelProps) {
  const totalAdd = summary.byAction.add;
  const totalDelete = summary.byAction.delete;
  const total = totalAdd + totalDelete;
  
  // Calculate success/fail rates (simulated)
  const addSuccess = Math.floor(totalAdd * 0.92);
  const addFailed = totalAdd - addSuccess;
  const deleteSuccess = Math.floor(totalDelete * 0.88);
  const deleteFailed = totalDelete - deleteSuccess;

  const funnelData = [
    {
      label: "Enroll (Add)",
      icon: ArrowUpRight,
      total: totalAdd,
      success: addSuccess,
      failed: addFailed,
      color: "text-status-ok",
      bgColor: "bg-status-ok",
    },
    {
      label: "De-enroll (Delete)",
      icon: ArrowDownRight,
      total: totalDelete,
      success: deleteSuccess,
      failed: deleteFailed,
      color: "text-status-warn",
      bgColor: "bg-status-warn",
    },
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Enrollment Funnel
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          (Add vs Delete)
        </span>
      </h3>

      <div className="space-y-4">
        {funnelData.map((item) => {
          const Icon = item.icon;
          const successRate = item.total > 0 ? ((item.success / item.total) * 100).toFixed(1) : "0";
          const maxWidth = total > 0 ? (item.total / total) * 100 : 50;
          
          return (
            <div key={item.label}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon className={`w-4 h-4 ${item.color}`} />
                  <span className="text-sm font-medium text-foreground">{item.label}</span>
                </div>
                <span className="text-sm font-bold text-foreground">{item.total}</span>
              </div>
              
              {/* Funnel bar */}
              <div className="relative h-8 bg-muted/30 rounded-lg overflow-hidden">
                <div 
                  className={`absolute left-0 top-0 h-full ${item.bgColor}/30 transition-all`}
                  style={{ width: `${maxWidth}%` }}
                />
                <div 
                  className={`absolute left-0 top-0 h-full ${item.bgColor} transition-all`}
                  style={{ width: `${(item.success / total) * 100}%` }}
                />
                
                {/* Labels inside bar */}
                <div className="absolute inset-0 flex items-center justify-between px-3">
                  <div className="flex items-center gap-1 text-[10px] text-foreground font-medium">
                    <CheckCircle className="w-3 h-3 text-status-ok" />
                    {item.success} ({successRate}%)
                  </div>
                  {item.failed > 0 && (
                    <div className="flex items-center gap-1 text-[10px] text-status-bad font-medium">
                      <XCircle className="w-3 h-3" />
                      {item.failed} failed
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-4 pt-4 border-t border-border">
        <div className="grid grid-cols-3 gap-2 text-center">
          <div>
            <p className="text-lg font-bold text-foreground">{total}</p>
            <p className="text-[10px] text-muted-foreground">Total Transactions</p>
          </div>
          <div>
            <p className="text-lg font-bold text-status-ok">{addSuccess + deleteSuccess}</p>
            <p className="text-[10px] text-muted-foreground">Successful</p>
          </div>
          <div>
            <p className="text-lg font-bold text-status-bad">{addFailed + deleteFailed}</p>
            <p className="text-[10px] text-muted-foreground">Failed</p>
          </div>
        </div>
      </div>
    </div>
  );
}
