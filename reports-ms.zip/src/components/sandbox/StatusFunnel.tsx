import { StatusFunnelData } from "@/types/sandbox";
import { RefreshCw } from "lucide-react";

interface StatusFunnelProps {
  funnel: StatusFunnelData;
  onReset: () => void;
}

const stages = [
  { key: "received" as const, label: "RECEIVED", color: "text-chart-1" },
  { key: "validated" as const, label: "VALIDATED", color: "text-chart-2" },
  { key: "processed" as const, label: "PROCESSED", color: "text-chart-4" },
  { key: "delivered" as const, label: "DELIVERED", color: "text-status-ok" },
];

export function StatusFunnel({ funnel, onReset }: StatusFunnelProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <h3 className="text-sm font-semibold text-foreground">
            Status funnel (live)
          </h3>
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] font-medium rounded">
            Tenant-scoped
          </span>
        </div>
        <button
          onClick={onReset}
          className="flex items-center gap-1.5 px-2.5 py-1 text-xs text-muted-foreground hover:text-foreground hover:bg-secondary rounded-md transition-colors"
        >
          <RefreshCw className="w-3 h-3" />
          Reset demo
        </button>
      </div>

      <div className="grid grid-cols-4 gap-2">
        {stages.map((stage) => (
          <div key={stage.key} className="text-center">
            <p className="text-[10px] text-muted-foreground mb-1">{stage.label}</p>
            <p className={`text-xl font-bold ${stage.color}`}>
              {funnel[stage.key].toLocaleString()}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
