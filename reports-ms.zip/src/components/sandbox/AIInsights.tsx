import { useEffect, useState } from "react";
import { Brain } from "lucide-react";
import { AIInsight, LiveMetrics } from "@/types/sandbox";
import { getJson } from "@/api/http";

interface AIInsightsProps {
  metrics: LiveMetrics;
}

// Local fallbacks (used if json-server is not running)
const FALLBACK_INSIGHTS: Record<string, AIInsight> = {
  default: {
    message: "SLA watch: p95 latency is trending high. No major error spike, but throughput may degrade if it persists.",
    confidence: "Medium",
    signal: "Latency rising",
    nextAction: "Throttle + check downstream",
    scope: "Tenant",
  },
  errors: {
    message: "Error rate has increased by 2.3% in the last 15 minutes. Most failures are validation errors from malformed payloads.",
    confidence: "High",
    signal: "Validation failures",
    nextAction: "Review payload schema",
    scope: "API",
  },
  latency: {
    message: "P95 latency exceeds SLA threshold. Consider scaling up workers or optimizing database queries.",
    confidence: "High",
    signal: "SLA breach risk",
    nextAction: "Scale infrastructure",
    scope: "System",
  },
  success: {
    message: "Success rate is healthy at 93%. Delivered count is within expected range for this time period.",
    confidence: "High",
    signal: "Normal operations",
    nextAction: "Continue monitoring",
    scope: "Tenant",
  },
};

function getInsightForQuery(
  query: string,
  metrics: LiveMetrics,
  insights: Record<string, AIInsight>
): AIInsight {
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes("error") || lowerQuery.includes("fail")) {
    return insights.errors;
  }
  if (lowerQuery.includes("latency") || lowerQuery.includes("slow") || lowerQuery.includes("sla")) {
    return insights.latency;
  }
  if (lowerQuery.includes("success") || lowerQuery.includes("deliver")) {
    return insights.success;
  }
  
  // Dynamic insight based on current metrics
  if (metrics.errorRate > 10) {
    return insights.errors;
  }
  if (metrics.slaLatency > 1000) {
    return insights.latency;
  }
  
  return insights.default;
}

export function AIInsights({ metrics }: AIInsightsProps) {
  const [query, setQuery] = useState("");
  const [insights, setInsights] = useState<Record<string, AIInsight>>(FALLBACK_INSIGHTS);
  const [insight, setInsight] = useState<AIInsight>(FALLBACK_INSIGHTS.default);
  const [isLoading, setIsLoading] = useState(false);

  // Load insights from json-server:
  // GET /aiInsights -> [{ key: 'default'|'errors'|'latency'|'success', message, confidence, signal, nextAction, scope }]
  useEffect(() => {
    const ac = new AbortController();
    (async () => {
      try {
        const rows = await getJson<Array<{ id: number; key: string } & AIInsight>>("/aiInsights", ac.signal);
        const next = (rows ?? []).reduce<Record<string, AIInsight>>((acc, r) => {
          if (r?.key) {
            acc[r.key] = {
              message: r.message,
              confidence: r.confidence,
              signal: r.signal,
              nextAction: r.nextAction,
              scope: r.scope,
            };
          }
          return acc;
        }, {});
        // Ensure required keys exist; otherwise keep fallback.
        if (next.default && next.errors && next.latency && next.success) {
          setInsights(next);
          setInsight(next.default);
        }
      } catch {
        // ignore; keep fallback
      }
    })();
    return () => ac.abort();
  }, []);

  const handleAsk = () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    // Simulate AI thinking
    setTimeout(() => {
      setInsight(getInsightForQuery(query, metrics, insights));
      setIsLoading(false);
      setQuery("");
    }, 800);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  const confidenceColors = {
    Low: "bg-status-bad/20 text-status-bad border-status-bad/30",
    Medium: "bg-status-warn/20 text-status-warn border-status-warn/30",
    High: "bg-status-ok/20 text-status-ok border-status-ok/30",
  };

  return (
    <div className="bg-card border border-border rounded-xl p-4 h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">
            Intelligent Insights
          </h3>
        </div>
        <span className={`px-2 py-0.5 text-[10px] font-medium rounded border ${confidenceColors[insight.confidence]}`}>
          Confidence: {insight.confidence}
        </span>
      </div>

      {/* Insight Display */}
      <div className="bg-input/50 rounded-lg p-3 mb-4">
        <p className={`text-sm text-foreground leading-relaxed ${isLoading ? "animate-pulse" : ""}`}>
          {isLoading ? "Analyzing metrics..." : insight.message}
        </p>
        
        <div className="flex flex-wrap gap-2 mt-3">
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded">
            Signal: {insight.signal}
          </span>
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded">
            Next: {insight.nextAction}
          </span>
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded">
            Scope: {insight.scope}
          </span>
        </div>
      </div>

      {/* Query Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask about metrics, errors, latency..."
          className="flex-1 px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
        />
        <button
          onClick={handleAsk}
          disabled={isLoading || !query.trim()}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? "..." : "Ask"}
        </button>
      </div>
    </div>
  );
}
