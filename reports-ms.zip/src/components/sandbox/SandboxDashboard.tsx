import { useState, useMemo } from "react";
import { ThemeProvider } from "@/hooks/useTheme";
import { SandboxHeader } from "./SandboxHeader";
import { IngestionModeTabs, IngestionMode } from "./IngestionModeTabs";
import { APIMetricsCards } from "./APIMetricsCards";
import { BatchMetricsCards } from "./BatchMetricsCards";
import { WaterfallReports } from "./WaterfallReports";
import { CustomReports } from "./CustomReports";
import { StatusFunnel } from "./StatusFunnel";
import { AIInsights } from "./AIInsights";
import { TransactionModal } from "./TransactionModal";
import { ErrorHeatmap, SourceDistribution, EnrollmentFunnel, SLATrendChart } from "./insights";
import { PopulationChart } from "../dashboard/PopulationChart";
import { OperationsChart } from "../dashboard/OperationsChart";
import { useLiveMetrics } from "@/hooks/useLiveMetrics";
import { useTransactions } from "@/hooks/useTransactions";
import { clientData } from "@/data/clientData";

function SandboxContent() {
  const [ingestionMode, setIngestionMode] = useState<IngestionMode>("API");
  const { metrics, funnel, apiMetrics, batchMetrics, resetDemo } = useLiveMetrics();
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  
  const { 
    transactions, 
    summary, 
    filters: txnFilters, 
    updateFilter: updateTxnFilter,
    heatmapData,
    slaTrend,
  } = useTransactions(apiMetrics.batchReprocessed);

  // Filter client data by ingestion mode
  const filteredClientData = useMemo(() => {
    return clientData.filter(row => {
      if (ingestionMode === "API") {
        return row["INGESTION MODE"] === "API" || row["INGESTION MODE"] === "COMBO";
      }
      return row["INGESTION MODE"] === "BATCH" || row["INGESTION MODE"] === "COMBO";
    });
  }, [ingestionMode]);

  // Top populations for the current mode
  const topPopulations = useMemo(() => {
    return [...filteredClientData]
      .filter((r) => r.POPULATION > 0)
      .sort((a, b) => b.POPULATION - a.POPULATION)
      .slice(0, 10)
      .map((r) => ({
        name: `${r.COMPANY.trim().slice(0, 20)}${r.PORT ? ` (P${r.PORT})` : ""}`,
        population: r.POPULATION,
      }));
  }, [filteredClientData]);

  const handleTransactionClick = () => {
    setIsTransactionModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background transition-colors duration-300">
      <SandboxHeader />
      
      <main className="max-w-[1400px] mx-auto px-5 py-6">
        {/* Ingestion Mode Tabs */}
        <IngestionModeTabs mode={ingestionMode} onModeChange={setIngestionMode} />

        {/* Mode-Specific Content */}
        {ingestionMode === "WATERFALL" ? (
          <WaterfallReports />
        ) : ingestionMode === "CUSTOM" ? (
          <CustomReports />
        ) : (
          <>
            {/* Mode-Specific Metrics */}
            {ingestionMode === "API" ? (
              <APIMetricsCards metrics={apiMetrics} onTransactionClick={handleTransactionClick} />
            ) : (
              <BatchMetricsCards metrics={batchMetrics} />
            )}

            {/* Status Funnel & AI Insights */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              <StatusFunnel funnel={funnel} onReset={resetDemo} />
              <AIInsights metrics={metrics} />
            </div>

            {/* Mode-Specific Insights Section */}
            <div className="mb-4">
              <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                {ingestionMode === "API" ? "API" : "Batch"} Insights
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <ErrorHeatmap data={heatmapData} />
                <SourceDistribution summary={summary} mode={ingestionMode} />
                <EnrollmentFunnel summary={summary} />
                <SLATrendChart data={slaTrend} />
              </div>
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 mb-4">
              <div className="lg:col-span-3">
                <PopulationChart data={topPopulations} />
              </div>
              <div className="lg:col-span-2">
                <OperationsChart period="Month" />
              </div>
            </div>
          </>
        )}
        
        <footer className="mt-8 text-center text-xs text-muted-foreground py-4">
          © 2025 MCM Client Monitoring — Pre-Enrollment Sandbox
        </footer>
      </main>

      {/* Transaction Modal (API mode only) */}
      <TransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        transactions={transactions}
        summary={summary}
        filters={txnFilters}
        onFilterChange={updateTxnFilter}
      />
    </div>
  );
}

export function SandboxDashboard() {
  return (
    <ThemeProvider>
      <SandboxContent />
    </ThemeProvider>
  );
}