import { SuccessDashboard } from "@/components/sandbox/SuccessDashboard";

const SandboxSuccess = () => {
  return <SuccessDashboard />;
};

export default SandboxSuccess;
