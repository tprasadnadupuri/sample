import { API_BASE_URL } from "./config";

export async function getJson<T>(path: string, signal?: AbortSignal): Promise<T> {
  const url = `${API_BASE_URL}${path.startsWith("/") ? "" : "/"}${path}`;
  const res = await fetch(url, {
    method: "GET",
    headers: {
      Accept: "application/json",
    },
    signal,
  });

  if (!res.ok) {
    let details = "";
    try {
      details = await res.text();
    } catch {
      // ignore
    }
    throw new Error(`GET ${url} failed: ${res.status} ${res.statusText}${details ? ` — ${details}` : ""}`);
  }

  return (await res.json()) as T;
}
