// Central place to control the API base URL.
//
// For local json-server:
//   VITE_API_BASE_URL=http://localhost:3001
//
// If not set, we default to json-server on 3001.
export const API_BASE_URL: string =
  (import.meta as any).env?.VITE_API_BASE_URL ?? "http://localhost:3001";
