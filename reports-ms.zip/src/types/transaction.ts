// Transaction lifecycle statuses
// NOTE: For this UI we intentionally collapse the lifecycle into two outcomes
// to keep the UX simple: success vs failed.
export type TransactionStatus = "success" | "failed";

// Transaction action type
export type TransactionAction = "add" | "delete";

// Ingestion source
export type IngestionSource = "API" | "BATCH" | "BATCH_REPROCESSED";

export interface Transaction {
  id: string;
  timestamp: string;
  source: IngestionSource;
  action: TransactionAction;
  status: TransactionStatus;
  clientName: string;
  portfolioId: string;
  population: number;
  latency: number;
  errorMessage?: string;
  originalBatchId?: string; // If reprocessed from batch
}

export interface TransactionFilters {
  source: IngestionSource | "all";
  action: TransactionAction | "all";
  status: TransactionStatus | "all";
  timeRange: "1h" | "6h" | "24h" | "7d";
}

export interface TransactionSummary {
  total: number;
  bySource: {
    api: number;
    batch: number;
    batchReprocessed: number;
  };
  byAction: {
    add: number;
    delete: number;
  };
  byStatus: Record<TransactionStatus, number>;
}

// Error heatmap data
export interface HeatmapCell {
  hour: number;
  day: string;
  errorCount: number;
  source: string;
}

// SLA trend data
export interface SLATrendPoint {
  timestamp: string;
  p50: number;
  p95: number;
  p99: number;
  threshold: number;
}
