import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

interface PopulationChartProps {
  data: { name: string; population: number }[];
}

const formatPopulation = (value: number) => {
  if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
  return value.toString();
};

// Experian brand colors for chart bars
const chartColors = [
  "hsl(228, 56%, 27%)",   // Navy
  "hsl(206, 58%, 53%)",   // Blue
  "hsl(330, 87%, 49%)",   // Magenta
  "hsl(291, 51%, 30%)",   // Purple
  "hsl(228, 56%, 37%)",   // Navy lighter
  "hsl(206, 58%, 63%)",   // Blue lighter
  "hsl(330, 87%, 59%)",   // Magenta lighter
  "hsl(291, 51%, 40%)",   // Purple lighter
  "hsl(206, 58%, 73%)",   // Blue more lighter
  "hsl(330, 87%, 69%)",   // Magenta more lighter
];

export function PopulationChart({ data }: PopulationChartProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 h-full transition-colors duration-300">
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Top Populations by Client
      </h3>
      <div className="h-[260px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            layout="vertical"
            margin={{ top: 0, right: 20, bottom: 0, left: 10 }}
          >
            <XAxis
              type="number"
              axisLine={false}
              tickLine={false}
              tickFormatter={formatPopulation}
            />
            <YAxis
              type="category"
              dataKey="name"
              width={120}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip
              cursor={{ fill: "hsl(var(--muted))" }}
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                padding: "8px 12px",
              }}
              labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600 }}
              itemStyle={{ color: "hsl(var(--primary))" }}
              formatter={(value: number) => [formatPopulation(value), "Population"]}
            />
            <Bar dataKey="population" radius={[0, 4, 4, 0]} maxBarSize={20}>
              {data.map((_, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={chartColors[index % chartColors.length]}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
