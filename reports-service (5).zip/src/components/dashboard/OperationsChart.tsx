import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { useMemo } from "react";

interface OperationsChartProps {
  period: string;
}

export function OperationsChart({ period }: OperationsChartProps) {
  // Generate synthetic data for demo purposes
  const data = useMemo(() => {
    const labels =
      period === "Day"
        ? Array.from({ length: 24 }, (_, i) => `${i}:00`)
        : period === "Week"
        ? ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        : ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    return labels.map((label, i) => ({
      name: label,
      adds: Math.max(0, Math.round((Math.sin(i + 1) + 1) * 5000000 * (Math.random() * 0.3 + 0.7))),
      deletes: Math.max(
        0,
        Math.round((Math.sin(i + 2) + 1) * 3500000 * (Math.random() * 0.3 + 0.7))
      ),
    }));
  }, [period]);

  const formatValue = (value: number) => {
    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `${(value / 1000).toFixed(0)}K`;
    return value.toString();
  };

  return (
    <div className="bg-card border border-border rounded-xl p-4 h-full transition-colors duration-300">
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Received / Added / Deleted — <span className="text-primary">{period}</span>
      </h3>
      <div className="h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <XAxis
              dataKey="name"
              axisLine={false}
              tickLine={false}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tickFormatter={formatValue}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                padding: "8px 12px",
              }}
              labelStyle={{ color: "hsl(var(--foreground))", fontWeight: 600 }}
              formatter={(value: number, name: string) => [
                formatValue(value),
                name.charAt(0).toUpperCase() + name.slice(1),
              ]}
            />
            <Legend
              wrapperStyle={{ paddingTop: 16 }}
              formatter={(value) => (
                <span className="text-foreground text-xs">
                  {value.charAt(0).toUpperCase() + value.slice(1)} (synthetic)
                </span>
              )}
            />
            <Line
              type="monotone"
              dataKey="adds"
              stroke="hsl(228, 56%, 27%)"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4 }}
            />
            <Line
              type="monotone"
              dataKey="deletes"
              stroke="hsl(330, 87%, 49%)"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="text-xs text-muted-foreground mt-2">
        No add/del counts in the dataset — this is a placeholder time series.
      </p>
    </div>
  );
}
