import { ClientData } from "@/types/client";

interface ClientTableProps {
  data: ClientData[];
}

function formatNumber(n: number): string {
  return n.toLocaleString();
}

function StatusBadge({ status }: { status: string }) {
  if (!status) return null;
  
  const isActive = status === "YES";
  return (
    <span
      className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-medium border ${
        isActive
          ? "bg-status-ok/10 text-status-ok border-status-ok/30"
          : "bg-status-bad/10 text-status-bad border-status-bad/30"
      }`}
    >
      {status}
    </span>
  );
}

const columns = [
  { key: "COMPANY", label: "COMPANY", width: "w-24" },
  { key: "PORT", label: "PORT", width: "w-16" },
  { key: "PORTFOLIO NAME", label: "PORTFOLIO NAME", width: "w-48" },
  { key: "POPULATION", label: "POPULATION", width: "w-28", align: "right" as const },
  { key: "START DATE", label: "START DATE", width: "w-24" },
  { key: "END DATE", label: "END DATE", width: "w-24" },
  { key: "TYPE", label: "TYPE", width: "w-16" },
  { key: "RT START DATE", label: "RT START DATE", width: "w-28" },
  { key: "RT END DATE", label: "RT END DATE", width: "w-28" },
  { key: "ACTIVE", label: "ACTIVE", width: "w-20" },
  { key: "CLIENT TYPE", label: "CLIENT TYPE", width: "w-24" },
  { key: "LAST FULL FILE NAME", label: "LAST FULL FILE NAME", width: "w-64" },
  { key: "LAST FULL FILE PROCESSED DATE", label: "LAST FULL FILE PROCESSED DATE", width: "w-48" },
  { key: "LAST ADD/DEL FILE NAME", label: "LAST ADD/DEL FILE NAME", width: "w-64" },
  { key: "LAST ADD/DEL FILE PROCESSED DATE", label: "LAST ADD/DEL FILE PROCESSED DATE", width: "w-48" },
  { key: "INGESTION MODE", label: "INGESTION MODE", width: "w-32" },
  { key: "RUN TYPE", label: "RUN TYPE", width: "w-24" },
];

export function ClientTable({ data }: ClientTableProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 mt-4">
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Clients
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          ({data.length} records)
        </span>
      </h3>
      <div className="table-scroll overflow-auto max-h-[55vh] rounded-lg border border-border">
        <table className="w-full border-collapse text-xs">
          <thead className="sticky top-0 z-10">
            <tr className="bg-input">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={`${col.width} px-3 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap border-b border-border ${
                    col.align === "right" ? "text-right" : ""
                  }`}
                >
                  {col.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, idx) => (
              <tr
                key={`${row.COMPANY}-${row.PORT}-${idx}`}
                className="border-b border-border/50 hover:bg-input/50 transition-colors"
              >
                <td className="px-3 py-2.5 text-foreground">{row.COMPANY}</td>
                <td className="px-3 py-2.5 text-foreground">{row.PORT}</td>
                <td className="px-3 py-2.5 text-foreground whitespace-nowrap">
                  {row["PORTFOLIO NAME"]}
                </td>
                <td className="px-3 py-2.5 text-foreground text-right font-medium">
                  {formatNumber(row.POPULATION)}
                </td>
                <td className="px-3 py-2.5 text-muted-foreground">{row["START DATE"]}</td>
                <td className="px-3 py-2.5 text-muted-foreground">{row["END DATE"]}</td>
                <td className="px-3 py-2.5 text-foreground">{row.TYPE}</td>
                <td className="px-3 py-2.5 text-muted-foreground">{row["RT START DATE"]}</td>
                <td className="px-3 py-2.5 text-muted-foreground">{row["RT END DATE"]}</td>
                <td className="px-3 py-2.5">
                  <StatusBadge status={row.ACTIVE} />
                </td>
                <td className="px-3 py-2.5 text-foreground">{row["CLIENT TYPE"]}</td>
                <td className="px-3 py-2.5 text-muted-foreground text-[11px]">
                  {row["LAST FULL FILE NAME"]}
                </td>
                <td className="px-3 py-2.5 text-muted-foreground">
                  {row["LAST FULL FILE PROCESSED DATE"]}
                </td>
                <td className="px-3 py-2.5 text-muted-foreground text-[11px]">
                  {row["LAST ADD/DEL FILE NAME"]}
                </td>
                <td className="px-3 py-2.5 text-muted-foreground">
                  {row["LAST ADD/DEL FILE PROCESSED DATE"]}
                </td>
                <td className="px-3 py-2.5 text-foreground">{row["INGESTION MODE"]}</td>
                <td className="px-3 py-2.5 text-foreground">{row["RUN TYPE"]}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
