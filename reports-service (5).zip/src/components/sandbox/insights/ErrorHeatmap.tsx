import { useMemo } from "react";
import { HeatmapCell } from "@/types/transaction";

interface ErrorHeatmapProps {
  data: HeatmapCell[];
}

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const HOURS = Array.from({ length: 24 }, (_, i) => i);

function getIntensityClass(count: number): string {
  if (count === 0) return "bg-muted/20";
  if (count <= 3) return "bg-status-ok/30";
  if (count <= 6) return "bg-status-warn/40";
  if (count <= 10) return "bg-status-warn/70";
  return "bg-status-bad/80";
}

export function ErrorHeatmap({ data }: ErrorHeatmapProps) {
  const heatmapGrid = useMemo(() => {
    const grid: Record<string, Record<number, number>> = {};
    DAYS.forEach(day => {
      grid[day] = {};
      HOURS.forEach(hour => {
        grid[day][hour] = 0;
      });
    });
    
    data.forEach(cell => {
      if (grid[cell.day]) {
        grid[cell.day][cell.hour] = (grid[cell.day][cell.hour] || 0) + cell.errorCount;
      }
    });
    
    return grid;
  }, [data]);

  const maxErrors = useMemo(() => {
    return Math.max(...data.map(d => d.errorCount), 1);
  }, [data]);

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <h3 className="text-sm font-semibold text-foreground mb-4">
        Error Heatmap
        <span className="ml-2 text-xs font-normal text-muted-foreground">
          (errors by hour/day)
        </span>
      </h3>
      
      <div className="overflow-x-auto">
        <div className="min-w-[600px]">
          {/* Hour labels */}
          <div className="flex mb-1 ml-12">
            {HOURS.filter((_, i) => i % 3 === 0).map(hour => (
              <div 
                key={hour} 
                className="text-[9px] text-muted-foreground"
                style={{ width: `${100 / 8}%` }}
              >
                {hour}:00
              </div>
            ))}
          </div>
          
          {/* Grid */}
          {DAYS.map(day => (
            <div key={day} className="flex items-center gap-1 mb-1">
              <div className="w-10 text-[10px] text-muted-foreground text-right pr-2">
                {day}
              </div>
              <div className="flex-1 flex gap-0.5">
                {HOURS.map(hour => {
                  const count = heatmapGrid[day]?.[hour] || 0;
                  return (
                    <div
                      key={hour}
                      className={`flex-1 h-5 rounded-sm ${getIntensityClass(count)} transition-all hover:ring-1 hover:ring-primary cursor-pointer`}
                      title={`${day} ${hour}:00 - ${count} errors`}
                    />
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* Legend */}
      <div className="flex items-center justify-end gap-2 mt-3 text-[9px] text-muted-foreground">
        <span>Less</span>
        <div className="flex gap-0.5">
          <div className="w-3 h-3 rounded-sm bg-muted/20" />
          <div className="w-3 h-3 rounded-sm bg-status-ok/30" />
          <div className="w-3 h-3 rounded-sm bg-status-warn/40" />
          <div className="w-3 h-3 rounded-sm bg-status-warn/70" />
          <div className="w-3 h-3 rounded-sm bg-status-bad/80" />
        </div>
        <span>More</span>
      </div>
    </div>
  );
}
