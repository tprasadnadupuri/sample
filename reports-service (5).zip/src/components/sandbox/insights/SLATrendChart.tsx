import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend,
} from "recharts";
import { SLATrendPoint } from "@/types/transaction";

interface SLATrendChartProps {
  data: SLATrendPoint[];
}

export function SLATrendChart({ data }: SLATrendChartProps) {
  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const threshold = data[0]?.threshold || 1000;
  const breachCount = data.filter(d => d.p95 > threshold).length;

  return (
    <div className="bg-card border border-border rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">
          SLA Latency Trend
          <span className="ml-2 text-xs font-normal text-muted-foreground">
            (24h)
          </span>
        </h3>
        {breachCount > 0 && (
          <span className="px-2 py-0.5 bg-status-bad/10 text-status-bad text-[10px] font-medium rounded">
            {breachCount} SLA breaches
          </span>
        )}
      </div>

      <div className="h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
            <XAxis
              dataKey="timestamp"
              tickFormatter={formatTime}
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10 }}
              interval="preserveStartEnd"
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 10 }}
              tickFormatter={(v) => `${v}ms`}
              domain={[0, 'dataMax + 200']}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
                padding: "8px 12px",
              }}
              labelFormatter={formatTime}
              formatter={(value: number, name: string) => [
                `${value}ms`,
                name.toUpperCase(),
              ]}
            />
            <ReferenceLine
              y={threshold}
              stroke="hsl(var(--status-bad))"
              strokeDasharray="5 5"
              label={{
                value: `SLA: ${threshold}ms`,
                position: "right",
                fill: "hsl(var(--status-bad))",
                fontSize: 10,
              }}
            />
            <Legend
              verticalAlign="bottom"
              height={36}
              formatter={(value) => (
                <span className="text-xs text-foreground">{value.toUpperCase()}</span>
              )}
            />
            <Line
              type="monotone"
              dataKey="p50"
              name="p50"
              stroke="hsl(206, 58%, 53%)"
              strokeWidth={1.5}
              dot={false}
              activeDot={{ r: 3 }}
            />
            <Line
              type="monotone"
              dataKey="p95"
              name="p95"
              stroke="hsl(330, 87%, 49%)"
              strokeWidth={2}
              dot={false}
              activeDot={{ r: 4 }}
            />
            <Line
              type="monotone"
              dataKey="p99"
              name="p99"
              stroke="hsl(291, 51%, 30%)"
              strokeWidth={1.5}
              strokeDasharray="3 3"
              dot={false}
              activeDot={{ r: 3 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Percentile summary */}
      <div className="grid grid-cols-3 gap-2 mt-3">
        <div className="text-center p-2 bg-chart-2/10 rounded-lg">
          <p className="text-sm font-bold text-chart-2">
            {data.length > 0 ? Math.round(data.reduce((a, d) => a + d.p50, 0) / data.length) : 0}ms
          </p>
          <p className="text-[10px] text-muted-foreground">Avg P50</p>
        </div>
        <div className="text-center p-2 bg-accent/10 rounded-lg">
          <p className="text-sm font-bold text-accent">
            {data.length > 0 ? Math.round(data.reduce((a, d) => a + d.p95, 0) / data.length) : 0}ms
          </p>
          <p className="text-[10px] text-muted-foreground">Avg P95</p>
        </div>
        <div className="text-center p-2 bg-chart-4/10 rounded-lg">
          <p className="text-sm font-bold text-chart-4">
            {data.length > 0 ? Math.round(data.reduce((a, d) => a + d.p99, 0) / data.length) : 0}ms
          </p>
          <p className="text-[10px] text-muted-foreground">Avg P99</p>
        </div>
      </div>
    </div>
  );
}
