import { useState, useMemo } from "react";
import { ClientData } from "@/types/client";
import { clientData } from "@/data/clientData";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { FileText, Download, Calendar, Filter } from "lucide-react";

function formatNumber(n: number): string {
  return n.toLocaleString();
}

function StatusBadge({ status }: { status: string }) {
  if (!status) return null;
  
  const isActive = status === "YES";
  return (
    <span
      className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-medium border ${
        isActive
          ? "bg-status-ok/10 text-status-ok border-status-ok/30"
          : "bg-status-bad/10 text-status-bad border-status-bad/30"
      }`}
    >
      {status}
    </span>
  );
}

const columns = [
  { key: "COMPANY", label: "COMPANY", width: "w-24" },
  { key: "PORT", label: "PORT", width: "w-16" },
  { key: "PORTFOLIO NAME", label: "PORTFOLIO NAME", width: "w-48" },
  { key: "POPULATION", label: "POPULATION", width: "w-28", align: "right" as const },
  { key: "START DATE", label: "START DATE", width: "w-24" },
  { key: "END DATE", label: "END DATE", width: "w-24" },
  { key: "TYPE", label: "TYPE", width: "w-16" },
  { key: "RT START DATE", label: "RT START DATE", width: "w-28" },
  { key: "RT END DATE", label: "RT END DATE", width: "w-28" },
  { key: "ACTIVE", label: "ACTIVE", width: "w-20" },
  { key: "CLIENT TYPE", label: "CLIENT TYPE", width: "w-24" },
  { key: "LAST FULL FILE NAME", label: "LAST FULL FILE NAME", width: "w-64" },
  { key: "LAST FULL FILE PROCESSED DATE", label: "LAST FULL FILE PROCESSED DATE", width: "w-48" },
  { key: "LAST ADD/DEL FILE NAME", label: "LAST ADD/DEL FILE NAME", width: "w-64" },
  { key: "LAST ADD/DEL FILE PROCESSED DATE", label: "LAST ADD/DEL FILE PROCESSED DATE", width: "w-48" },
  { key: "INGESTION MODE", label: "INGESTION MODE", width: "w-32" },
  { key: "RUN TYPE", label: "RUN TYPE", width: "w-24" },
];

export function CustomReports() {
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const filteredData = useMemo(() => {
    if (!startDate && !endDate) return clientData;
    
    return clientData.filter(row => {
      const rowStartDate = row["START DATE"];
      const rowEndDate = row["END DATE"];
      
      // Parse dates for comparison (format: MM/DD/YYYY)
      const parseDate = (dateStr: string) => {
        if (!dateStr) return null;
        const [month, day, year] = dateStr.split("/").map(Number);
        return new Date(year, month - 1, day);
      };
      
      const rowStart = parseDate(rowStartDate);
      const filterStart = startDate ? new Date(startDate) : null;
      const filterEnd = endDate ? new Date(endDate) : null;
      
      if (filterStart && rowStart && rowStart < filterStart) return false;
      if (filterEnd && rowStart && rowStart > filterEnd) return false;
      
      return true;
    });
  }, [startDate, endDate]);

  const handleDownload = () => {
    // Create CSV content
    const headers = columns.map(col => col.label).join(",");
    const rows = filteredData.map(row => 
      columns.map(col => {
        const value = row[col.key as keyof ClientData];
        // Escape commas and quotes in values
        const strValue = String(value || "");
        if (strValue.includes(",") || strValue.includes('"')) {
          return `"${strValue.replace(/"/g, '""')}"`;
        }
        return strValue;
      }).join(",")
    );
    
    const csv = [headers, ...rows].join("\n");
    
    // Create and trigger download
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `custom_reports_${new Date().toISOString().split("T")[0]}.csv`);
    link.style.visibility = "hidden";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clearFilters = () => {
    setStartDate("");
    setEndDate("");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Custom Reports</h2>
            <p className="text-xs text-muted-foreground">Client data with date filtering and export</p>
          </div>
        </div>
        <Button onClick={handleDownload} className="gap-2">
          <Download className="w-4 h-4" />
          Download CSV
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-card border-border p-4">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium text-foreground">Date Filters</span>
        </div>
        <div className="flex flex-wrap items-end gap-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="startDate" className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              Start Date
            </Label>
            <Input
              id="startDate"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-40"
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label htmlFor="endDate" className="text-xs text-muted-foreground flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              End Date
            </Label>
            <Input
              id="endDate"
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-40"
            />
          </div>
          <Button variant="outline" size="sm" onClick={clearFilters}>
            Clear Filters
          </Button>
          <div className="ml-auto text-sm text-muted-foreground">
            Showing <span className="font-semibold text-foreground">{filteredData.length}</span> of {clientData.length} records
          </div>
        </div>
      </Card>

      {/* Client Table */}
      <Card className="bg-card border-border p-4">
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Clients
          <span className="ml-2 text-xs font-normal text-muted-foreground">
            ({filteredData.length} records)
          </span>
        </h3>
        <div className="table-scroll overflow-auto max-h-[55vh] rounded-lg border border-border">
          <table className="w-full border-collapse text-xs">
            <thead className="sticky top-0 z-10">
              <tr className="bg-input">
                {columns.map((col) => (
                  <th
                    key={col.key}
                    className={`${col.width} px-3 py-3 text-left text-xs font-semibold text-muted-foreground whitespace-nowrap border-b border-border ${
                      col.align === "right" ? "text-right" : ""
                    }`}
                  >
                    {col.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredData.map((row, idx) => (
                <tr
                  key={`${row.COMPANY}-${row.PORT}-${idx}`}
                  className="border-b border-border/50 hover:bg-input/50 transition-colors"
                >
                  <td className="px-3 py-2.5 text-foreground">{row.COMPANY}</td>
                  <td className="px-3 py-2.5 text-foreground">{row.PORT}</td>
                  <td className="px-3 py-2.5 text-foreground whitespace-nowrap">
                    {row["PORTFOLIO NAME"]}
                  </td>
                  <td className="px-3 py-2.5 text-foreground text-right font-medium">
                    {formatNumber(row.POPULATION)}
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground">{row["START DATE"]}</td>
                  <td className="px-3 py-2.5 text-muted-foreground">{row["END DATE"]}</td>
                  <td className="px-3 py-2.5 text-foreground">{row.TYPE}</td>
                  <td className="px-3 py-2.5 text-muted-foreground">{row["RT START DATE"]}</td>
                  <td className="px-3 py-2.5 text-muted-foreground">{row["RT END DATE"]}</td>
                  <td className="px-3 py-2.5">
                    <StatusBadge status={row.ACTIVE} />
                  </td>
                  <td className="px-3 py-2.5 text-foreground">{row["CLIENT TYPE"]}</td>
                  <td className="px-3 py-2.5 text-muted-foreground text-[11px]">
                    {row["LAST FULL FILE NAME"]}
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground">
                    {row["LAST FULL FILE PROCESSED DATE"]}
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground text-[11px]">
                    {row["LAST ADD/DEL FILE NAME"]}
                  </td>
                  <td className="px-3 py-2.5 text-muted-foreground">
                    {row["LAST ADD/DEL FILE PROCESSED DATE"]}
                  </td>
                  <td className="px-3 py-2.5 text-foreground">{row["INGESTION MODE"]}</td>
                  <td className="px-3 py-2.5 text-foreground">{row["RUN TYPE"]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}