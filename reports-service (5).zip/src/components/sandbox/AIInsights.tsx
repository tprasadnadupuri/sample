import { useState } from "react";
import { Brain, Send, Ticket, HelpCircle, FileSearch, Settings } from "lucide-react";
import { AIInsight, LiveMetrics } from "@/types/sandbox";

interface AIInsightsProps {
  metrics: LiveMetrics;
}

interface InsightResponse {
  message: string;
  confidence: "Low" | "Medium" | "High";
  signal: string;
  nextAction: string;
  scope: string;
  actionType?: "info" | "ticket" | "investigation";
}

const DEMO_INSIGHTS: Record<string, InsightResponse> = {
  default: {
    message: "SLA watch: p95 latency is trending high. No major error spike, but throughput may degrade if it persists.",
    confidence: "Medium",
    signal: "Latency rising",
    nextAction: "Throttle + check downstream",
    scope: "Tenant",
  },
  enrollment_params: {
    message: "Enrollment parameters for your portfolio: SSN, DOB, Full Name, Current Address are required PII fields. Optional fields include Credit Limit Filter ($5K–$100K), Credit Utilization (0–100%), and Permissible Purpose code (must be pre-approved). Subcode and Portfolio Number are mandatory for routing.",
    confidence: "High",
    signal: "Enrollment config",
    nextAction: "Review portfolio setup",
    scope: "Configuration",
    actionType: "info",
  },
  help_ticket: {
    message: "Help ticket #HT-20250210-0047 has been created and assigned to the Support Queue. Priority: Medium. Your issue will be reviewed within 2 business hours. You'll receive email confirmation shortly with tracking details.",
    confidence: "High",
    signal: "Ticket created",
    nextAction: "Track via Support Portal",
    scope: "Support",
    actionType: "ticket",
  },
  file_delivery: {
    message: "Investigation complete: 2 of 4 processed files have not reached clients. NAVY_ADDDEL_20250210_002.csv is halted at BA/Client Confirmation (PIN match 42% < 50% threshold). WELLS_ADDDEL_20250210_004.csv delivery failed due to SFTP timeout at 09:42 AM — retry scheduled for next window.",
    confidence: "High",
    signal: "Delivery gap found",
    nextAction: "Approve halted file + check SFTP",
    scope: "Delivery",
    actionType: "investigation",
  },
  errors: {
    message: "Error rate has increased by 2.3% in the last 15 minutes. Most failures are validation errors from malformed payloads — specifically missing SSN and invalid DOB formats in batch files.",
    confidence: "High",
    signal: "Validation failures",
    nextAction: "Review payload schema",
    scope: "API",
  },
  latency: {
    message: "P95 latency exceeds SLA threshold at 1,240ms (target: 1,000ms). Root cause appears to be downstream credit bureau response times. Consider enabling async processing or scaling worker pool.",
    confidence: "High",
    signal: "SLA breach risk",
    nextAction: "Scale infrastructure",
    scope: "System",
  },
  success: {
    message: "Success rate is healthy at 93%. All delivered files have been confirmed by downstream consumers. No reprocessing needed at this time.",
    confidence: "High",
    signal: "Normal operations",
    nextAction: "Continue monitoring",
    scope: "Tenant",
  },
  reprocess: {
    message: "3 records from AMEX_FULL_20250210_003.csv were reprocessed via API after initial batch validation failure. All 3 now show 'Delivered' status. Original errors: missing middle_name (2), invalid zip format (1).",
    confidence: "High",
    signal: "Reprocess complete",
    nextAction: "Verify client receipt",
    scope: "Operations",
    actionType: "investigation",
  },
};

const SUGGESTED_QUERIES = [
  { label: "Enrollment params", icon: Settings, query: "What are the enrollment parameters for my portfolio?" },
  { label: "Create ticket", icon: Ticket, query: "Create a help ticket for file delivery issue" },
  { label: "File delivery status", icon: FileSearch, query: "Why haven't processed files reached the client?" },
  { label: "Reprocessed records", icon: HelpCircle, query: "Show me reprocessed records status" },
];

function getInsightForQuery(query: string, metrics: LiveMetrics): InsightResponse {
  const lowerQuery = query.toLowerCase();

  if (lowerQuery.includes("parameter") || lowerQuery.includes("enrollment param") || lowerQuery.includes("config") || lowerQuery.includes("what are the")) {
    return DEMO_INSIGHTS.enrollment_params;
  }
  if (lowerQuery.includes("ticket") || lowerQuery.includes("help") || lowerQuery.includes("create") || lowerQuery.includes("support")) {
    return DEMO_INSIGHTS.help_ticket;
  }
  if (lowerQuery.includes("deliver") || lowerQuery.includes("reach") || lowerQuery.includes("client") || lowerQuery.includes("why haven")) {
    return DEMO_INSIGHTS.file_delivery;
  }
  if (lowerQuery.includes("reprocess") || lowerQuery.includes("resubmi")) {
    return DEMO_INSIGHTS.reprocess;
  }
  if (lowerQuery.includes("error") || lowerQuery.includes("fail")) {
    return DEMO_INSIGHTS.errors;
  }
  if (lowerQuery.includes("latency") || lowerQuery.includes("slow") || lowerQuery.includes("sla")) {
    return DEMO_INSIGHTS.latency;
  }
  if (lowerQuery.includes("success")) {
    return DEMO_INSIGHTS.success;
  }

  if (metrics.errorRate > 10) return DEMO_INSIGHTS.errors;
  if (metrics.slaLatency > 1000) return DEMO_INSIGHTS.latency;

  return DEMO_INSIGHTS.default;
}

export function AIInsights({ metrics }: AIInsightsProps) {
  const [query, setQuery] = useState("");
  const [insight, setInsight] = useState<InsightResponse>(DEMO_INSIGHTS.default);
  const [isLoading, setIsLoading] = useState(false);

  const handleAsk = (overrideQuery?: string) => {
    const q = overrideQuery || query;
    if (!q.trim()) return;

    setIsLoading(true);
    setTimeout(() => {
      setInsight(getInsightForQuery(q, metrics));
      setIsLoading(false);
      setQuery("");
    }, 800);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleAsk();
    }
  };

  const confidenceColors = {
    Low: "bg-status-bad/20 text-status-bad border-status-bad/30",
    Medium: "bg-status-warn/20 text-status-warn border-status-warn/30",
    High: "bg-status-ok/20 text-status-ok border-status-ok/30",
  };

  const actionBadge = insight.actionType === "ticket"
    ? { label: "🎫 Ticket Created", cls: "bg-chart-4/20 text-chart-4 border-chart-4/30" }
    : insight.actionType === "investigation"
      ? { label: "🔍 Investigation", cls: "bg-primary/20 text-primary border-primary/30" }
      : null;

  return (
    <div className="bg-card border border-border rounded-xl p-4 h-full flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Intelligent Insights</h3>
        </div>
        <span className={`px-2 py-0.5 text-[10px] font-medium rounded border ${confidenceColors[insight.confidence]}`}>
          Confidence: {insight.confidence}
        </span>
      </div>

      {/* Suggested queries */}
      <div className="flex flex-wrap gap-1.5 mb-3">
        {SUGGESTED_QUERIES.map(sq => {
          const Icon = sq.icon;
          return (
            <button
              key={sq.label}
              onClick={() => { setQuery(sq.query); handleAsk(sq.query); }}
              disabled={isLoading}
              className="flex items-center gap-1 px-2 py-1 text-[9px] font-medium bg-secondary hover:bg-accent text-muted-foreground hover:text-foreground rounded-md transition-colors disabled:opacity-50"
            >
              <Icon className="w-3 h-3" />
              {sq.label}
            </button>
          );
        })}
      </div>

      {/* Insight Display */}
      <div className="bg-input/50 rounded-lg p-3 mb-3 flex-1">
        <p className={`text-sm text-foreground leading-relaxed ${isLoading ? "animate-pulse" : ""}`}>
          {isLoading ? "Analyzing metrics..." : insight.message}
        </p>

        <div className="flex flex-wrap gap-2 mt-3">
          {actionBadge && (
            <span className={`px-2 py-0.5 text-[10px] font-semibold rounded border ${actionBadge.cls}`}>
              {actionBadge.label}
            </span>
          )}
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded">
            Signal: {insight.signal}
          </span>
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded">
            Next: {insight.nextAction}
          </span>
          <span className="px-2 py-0.5 bg-secondary text-muted-foreground text-[10px] rounded">
            Scope: {insight.scope}
          </span>
        </div>
      </div>

      {/* Query Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask about enrollment, tickets, file delivery..."
          className="flex-1 px-3 py-2 bg-input border border-border rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
        />
        <button
          onClick={() => handleAsk()}
          disabled={isLoading || !query.trim()}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:bg-primary/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? "..." : "Ask"}
        </button>
      </div>
    </div>
  );
}
