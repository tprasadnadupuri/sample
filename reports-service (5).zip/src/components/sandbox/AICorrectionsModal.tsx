import { useState, useEffect } from "react";
import { X, Sparkles, CheckCircle, AlertCircle, Send, RefreshCw } from "lucide-react";
import { ErrorRecord, APIPayload } from "@/types/sandbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface AICorrectionsModalProps {
  error: ErrorRecord;
  onClose: () => void;
  onApplyCorrection: (error: ErrorRecord, correctedValue: string, correctedPayload?: APIPayload) => void;
}

interface AISuggestion {
  field: string;
  originalValue: string;
  suggestedValue: string;
  confidence: "high" | "medium" | "low";
  reason: string;
}

// Mock AI suggestions based on error type
function generateAISuggestions(error: ErrorRecord): AISuggestion[] {
  const suggestions: AISuggestion[] = [];
  
  if (error.originalIngestion === "API" && error.payload) {
    // API PII validation errors
    if (error.message.includes("Invalid SIN") || error.message.includes("Invalid SSN")) {
      suggestions.push({
        field: "SSN",
        originalValue: error.payload.consumer_pii.ssn,
        suggestedValue: error.payload.consumer_pii.ssn.replace(/[^0-9]/g, "").padStart(9, "0").slice(0, 9),
        confidence: "high",
        reason: "SSN must be exactly 9 numeric digits without dashes or spaces"
      });
    }
    if (error.message.includes("Blank Name") || error.message.includes("name")) {
      suggestions.push({
        field: "First Name",
        originalValue: error.payload.consumer_pii.name.first_name || "(empty)",
        suggestedValue: "JOHN",
        confidence: "medium",
        reason: "First name is required and cannot be blank"
      });
    }
    if (error.message.includes("Blank Address") || error.message.includes("address")) {
      suggestions.push({
        field: "Address Line 1",
        originalValue: error.payload.consumer_pii.address.line1 || "(empty)",
        suggestedValue: "123 MAIN ST",
        confidence: "low",
        reason: "Address line 1 is required. Please provide the correct address."
      });
    }
  } else if (error.originalIngestion === "BATCH") {
    // Batch file validation errors
    if (error.message.includes("Invalid SIN") || error.message.includes("Non-Numeric SIN")) {
      suggestions.push({
        field: error.fieldName || "SIN",
        originalValue: error.originalValue || "ABC123456",
        suggestedValue: "123456789",
        confidence: "high",
        reason: "SIN must contain only numeric characters (9 digits)"
      });
    }
    if (error.message.includes("Invalid SSN")) {
      suggestions.push({
        field: error.fieldName || "SSN",
        originalValue: error.originalValue || "12-34-5678",
        suggestedValue: "123456789",
        confidence: "high",
        reason: "SSN must be exactly 9 numeric digits without formatting"
      });
    }
    if (error.message.includes("Blank Name")) {
      suggestions.push({
        field: error.fieldName || "Name",
        originalValue: error.originalValue || "(empty)",
        suggestedValue: "DOE, JOHN",
        confidence: "medium",
        reason: "Name field cannot be empty. Format: SURNAME, FIRSTNAME"
      });
    }
    if (error.message.includes("Blank Address")) {
      suggestions.push({
        field: error.fieldName || "Address",
        originalValue: error.originalValue || "(empty)",
        suggestedValue: "123 MAIN ST",
        confidence: "low",
        reason: "Address is required. Please provide the correct value."
      });
    }
    if (error.message.includes("Invalid Record Length")) {
      suggestions.push({
        field: "Record",
        originalValue: `${error.originalValue?.length || 0} characters`,
        suggestedValue: "Pad or trim to 200 characters",
        confidence: "high",
        reason: "Each record must be exactly 200 characters in fixed-width format"
      });
    }
    if (error.message.includes("Invalid Comp/PortID")) {
      suggestions.push({
        field: error.fieldName || "Comp/PortID",
        originalValue: error.originalValue || "INVALID",
        suggestedValue: "12345",
        confidence: "medium",
        reason: "Company/Portfolio ID must be a valid 5-digit numeric code"
      });
    }
    if (error.message.includes("Invalid Account")) {
      suggestions.push({
        field: error.fieldName || "Account Number",
        originalValue: error.originalValue || "ACC-123",
        suggestedValue: "1234567890",
        confidence: "high",
        reason: "Account number must be numeric, 10 digits"
      });
    }
  }
  
  // Default suggestion if no specific match
  if (suggestions.length === 0) {
    suggestions.push({
      field: error.fieldName || "Unknown Field",
      originalValue: error.originalValue || "N/A",
      suggestedValue: "Please review and correct manually",
      confidence: "low",
      reason: "Unable to determine automatic correction. Manual review required."
    });
  }
  
  return suggestions;
}

export function AICorrectionsModal({ error, onClose, onApplyCorrection }: AICorrectionsModalProps) {
  const [suggestions, setSuggestions] = useState<AISuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editedValues, setEditedValues] = useState<Record<string, string>>({});
  const [isApplying, setIsApplying] = useState(false);

  useEffect(() => {
    // Simulate AI thinking time
    const timer = setTimeout(() => {
      setSuggestions(generateAISuggestions(error));
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [error]);

  useEffect(() => {
    // Initialize edited values from suggestions
    const initial: Record<string, string> = {};
    suggestions.forEach(s => {
      initial[s.field] = s.suggestedValue;
    });
    setEditedValues(initial);
  }, [suggestions]);

  const handleApply = () => {
    setIsApplying(true);
    setTimeout(() => {
      // Get the primary corrected value
      const primaryValue = Object.values(editedValues)[0] || "";
      
      // For API errors, update the payload
      if (error.originalIngestion === "API" && error.payload) {
        const updatedPayload = JSON.parse(JSON.stringify(error.payload));
        suggestions.forEach(s => {
          const value = editedValues[s.field];
          if (s.field === "SSN") {
            updatedPayload.consumer_pii.ssn = value;
          } else if (s.field === "First Name") {
            updatedPayload.consumer_pii.name.first_name = value;
          } else if (s.field === "Address Line 1") {
            updatedPayload.consumer_pii.address.line1 = value;
          }
        });
        onApplyCorrection(error, primaryValue, updatedPayload);
      } else {
        onApplyCorrection(error, primaryValue);
      }
      setIsApplying(false);
    }, 1000);
  };

  const confidenceColors = {
    high: "text-status-ok bg-status-ok/10",
    medium: "text-status-warn bg-status-warn/10",
    low: "text-status-bad bg-status-bad/10"
  };

  const isBatch = error.originalIngestion === "BATCH";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">AI Correction Assistant</h2>
              <p className="text-xs text-muted-foreground">
                {isBatch ? (
                  <>File: <span className="font-mono text-chart-1">{error.fileName}</span> • Row {error.rowNumber}</>
                ) : (
                  <>Transaction: <span className="font-mono text-primary">{error.transactionId}</span></>
                )}
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-input rounded-lg transition-colors">
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* Error Info */}
        <div className="px-4 py-3 bg-status-bad/5 border-b border-border">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-status-bad mt-0.5" />
            <div>
              <p className="text-sm font-medium text-foreground">{error.type}</p>
              <p className="text-xs text-muted-foreground">{error.message}</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <ScrollArea className="flex-1 p-4">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <RefreshCw className="w-8 h-8 text-primary animate-spin" />
              <p className="text-sm text-muted-foreground">AI is analyzing the error...</p>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Based on the error, here are the suggested corrections:
              </p>
              
              {suggestions.map((suggestion, idx) => (
                <div key={idx} className="bg-input/50 border border-border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium text-foreground">{suggestion.field}</Label>
                    <span className={`px-2 py-0.5 text-[10px] font-medium rounded ${confidenceColors[suggestion.confidence]}`}>
                      {suggestion.confidence} confidence
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <p className="text-[10px] text-muted-foreground mb-1">Original Value</p>
                      <div className="px-3 py-2 bg-status-bad/10 border border-status-bad/20 rounded text-sm font-mono text-status-bad">
                        {suggestion.originalValue}
                      </div>
                    </div>
                    <div>
                      <p className="text-[10px] text-muted-foreground mb-1">Corrected Value</p>
                      <Input
                        value={editedValues[suggestion.field] || suggestion.suggestedValue}
                        onChange={(e) => setEditedValues(prev => ({ ...prev, [suggestion.field]: e.target.value }))}
                        className="font-mono text-sm border-status-ok/20 focus:border-status-ok"
                      />
                    </div>
                  </div>
                  
                  <p className="text-xs text-muted-foreground bg-background/50 p-2 rounded">
                    💡 {suggestion.reason}
                  </p>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-4 border-t border-border bg-input/30">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleApply} 
            disabled={isLoading || isApplying}
            className="flex items-center gap-2"
          >
            {isApplying ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <CheckCircle className="w-4 h-4" />
            )}
            Apply & Retrigger
          </Button>
        </div>
      </div>
    </div>
  );
}
