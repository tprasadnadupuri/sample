import { useState } from "react";
import { X, Code, FormInput, Send, RefreshCw } from "lucide-react";
import { APIPayload, ErrorRecord } from "@/types/sandbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";

interface PayloadEditorModalProps {
  error: ErrorRecord;
  onClose: () => void;
  onRetrigger: (error: ErrorRecord, updatedPayload: APIPayload) => void;
}

export function PayloadEditorModal({ error, onClose, onRetrigger }: PayloadEditorModalProps) {
  const [payload, setPayload] = useState<APIPayload>(error.payload!);
  const [jsonText, setJsonText] = useState(JSON.stringify(error.payload, null, 2));
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [isRetriggering, setIsRetriggering] = useState(false);
  const [activeTab, setActiveTab] = useState<"form" | "json">("form");

  const handleJsonChange = (value: string) => {
    setJsonText(value);
    try {
      const parsed = JSON.parse(value);
      setPayload(parsed);
      setJsonError(null);
    } catch {
      setJsonError("Invalid JSON format");
    }
  };

  const handleFormChange = (path: string[], value: string | number | null) => {
    const newPayload = JSON.parse(JSON.stringify(payload));
    let current = newPayload;
    for (let i = 0; i < path.length - 1; i++) {
      current = current[path[i]];
    }
    current[path[path.length - 1]] = value;
    setPayload(newPayload);
    setJsonText(JSON.stringify(newPayload, null, 2));
  };

  const handleRetrigger = () => {
    setIsRetriggering(true);
    setTimeout(() => {
      onRetrigger(error, payload);
      setIsRetriggering(false);
    }, 1000);
  };

  const syncJsonToForm = () => {
    try {
      const parsed = JSON.parse(jsonText);
      setPayload(parsed);
      setJsonError(null);
    } catch {
      setJsonError("Cannot sync: Invalid JSON format");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div>
            <h2 className="text-lg font-bold text-foreground">Edit API Payload</h2>
            <p className="text-xs text-muted-foreground">
              Transaction ID: <span className="font-mono text-primary">{error.transactionId}</span>
            </p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-input rounded-lg transition-colors">
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "form" | "json")} className="flex-1 flex flex-col overflow-hidden">
          <div className="px-4 pt-3">
            <TabsList className="grid w-full grid-cols-2 max-w-xs">
              <TabsTrigger value="form" className="flex items-center gap-2">
                <FormInput className="w-4 h-4" />
                Form View
              </TabsTrigger>
              <TabsTrigger value="json" className="flex items-center gap-2">
                <Code className="w-4 h-4" />
                JSON View
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="form" className="flex-1 overflow-hidden m-0 p-4">
            <ScrollArea className="h-[50vh]">
              <div className="space-y-6 pr-4">
                {/* Consumer PII Section */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-foreground border-b border-border pb-2">Consumer PII</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">SSN</Label>
                      <Input
                        value={payload.consumer_pii.ssn}
                        onChange={(e) => handleFormChange(["consumer_pii", "ssn"], e.target.value)}
                        className="font-mono text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">DOB</Label>
                      <Input
                        value={payload.consumer_pii.dob}
                        onChange={(e) => handleFormChange(["consumer_pii", "dob"], e.target.value)}
                        placeholder="YYYY-MM-DD"
                        className="text-sm"
                      />
                    </div>
                  </div>
                  
                  {/* Name Fields */}
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">First Name</Label>
                      <Input
                        value={payload.consumer_pii.name.first_name}
                        onChange={(e) => handleFormChange(["consumer_pii", "name", "first_name"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Middle Name</Label>
                      <Input
                        value={payload.consumer_pii.name.middle_name}
                        onChange={(e) => handleFormChange(["consumer_pii", "name", "middle_name"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Surname</Label>
                      <Input
                        value={payload.consumer_pii.name.surname}
                        onChange={(e) => handleFormChange(["consumer_pii", "name", "surname"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                  </div>

                  {/* Address Fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">Address Line 1</Label>
                      <Input
                        value={payload.consumer_pii.address.line1}
                        onChange={(e) => handleFormChange(["consumer_pii", "address", "line1"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Address Line 2</Label>
                      <Input
                        value={payload.consumer_pii.address.line2}
                        onChange={(e) => handleFormChange(["consumer_pii", "address", "line2"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">City</Label>
                      <Input
                        value={payload.consumer_pii.address.city}
                        onChange={(e) => handleFormChange(["consumer_pii", "address", "city"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label className="text-xs text-muted-foreground">State</Label>
                        <Input
                          value={payload.consumer_pii.address.state}
                          onChange={(e) => handleFormChange(["consumer_pii", "address", "state"], e.target.value)}
                          className="text-sm"
                        />
                      </div>
                      <div>
                        <Label className="text-xs text-muted-foreground">ZIP</Label>
                        <Input
                          value={payload.consumer_pii.address.zip}
                          onChange={(e) => handleFormChange(["consumer_pii", "address", "zip"], e.target.value)}
                          className="text-sm"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Portfolios Section */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-foreground border-b border-border pb-2">Portfolios</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">Portfolio Numbers</Label>
                      <Input
                        value={payload.portfolios.portfolio_number.join(", ")}
                        onChange={(e) => handleFormChange(["portfolios", "portfolio_number"], e.target.value.split(",").map(n => parseInt(n.trim())).filter(n => !isNaN(n)) as unknown as number)}
                        placeholder="e.g., 1, 2, 3"
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Subcode</Label>
                      <Input
                        value={payload.portfolios.subcode}
                        onChange={(e) => handleFormChange(["portfolios", "subcode"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                  </div>
                </div>

                {/* ECS Customer Info Section */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-foreground border-b border-border pb-2">ECS Customer Information</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">ECS Subscription ID</Label>
                      <Input
                        value={payload.ecs_customer_supplied_information.ecs_subscription_Id}
                        onChange={(e) => handleFormChange(["ecs_customer_supplied_information", "ecs_subscription_Id"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Customer ID</Label>
                      <Input
                        value={payload.ecs_customer_supplied_information.customer_id}
                        onChange={(e) => handleFormChange(["ecs_customer_supplied_information", "customer_id"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Credit Limit Filter</Label>
                      <Input
                        value={payload.ecs_customer_supplied_information.credit_limit_filter}
                        onChange={(e) => handleFormChange(["ecs_customer_supplied_information", "credit_limit_filter"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">Credit Limit Value</Label>
                      <Input
                        value={payload.ecs_customer_supplied_information.credit_limit_value}
                        onChange={(e) => handleFormChange(["ecs_customer_supplied_information", "credit_limit_value"], e.target.value)}
                        className="text-sm"
                      />
                    </div>
                  </div>
                </div>

                {/* Permissible Purpose */}
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-foreground border-b border-border pb-2">Other</h3>
                  <div>
                    <Label className="text-xs text-muted-foreground">Permissible Purpose</Label>
                    <Input
                      value={payload.permissible_purpose}
                      onChange={(e) => handleFormChange(["permissible_purpose"], e.target.value)}
                      className="text-sm w-32"
                    />
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="json" className="flex-1 overflow-hidden m-0 p-4">
            <div className="h-[50vh] flex flex-col gap-3">
              <textarea
                value={jsonText}
                onChange={(e) => handleJsonChange(e.target.value)}
                className="flex-1 w-full p-4 bg-input border border-border rounded-lg font-mono text-sm text-foreground resize-none focus:outline-none focus:ring-2 focus:ring-primary/50"
                spellCheck={false}
              />
              {jsonError && (
                <p className="text-xs text-status-bad">{jsonError}</p>
              )}
              <Button variant="outline" size="sm" onClick={syncJsonToForm} className="self-start">
                Sync to Form View
              </Button>
            </div>
          </TabsContent>
        </Tabs>

        {/* Footer */}
        <div className="flex items-center justify-between p-4 border-t border-border bg-input/30">
          <p className="text-xs text-muted-foreground">
            Error: <span className="text-status-bad">{error.message}</span>
          </p>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              onClick={handleRetrigger} 
              disabled={isRetriggering || !!jsonError}
              className="flex items-center gap-2"
            >
              {isRetriggering ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              Retrigger API Call
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
