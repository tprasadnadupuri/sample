import { Zap, TrendingUp, AlertTriangle, Clock, RefreshCw, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface APIMetrics {
  totalTransactions: number;
  directApiCalls: number;
  batchReprocessed: number;
  successRate: number;
  errorRate: number;
  avgLatency: number;
}

interface APIMetricsCardsProps {
  metrics: APIMetrics;
  onTransactionClick?: () => void;
}

export function APIMetricsCards({ metrics, onTransactionClick }: APIMetricsCardsProps) {
  const navigate = useNavigate();

  const cards = [
    {
      label: "Total API Transactions",
      value: metrics.totalTransactions.toLocaleString(),
      subtitle: `${metrics.directApiCalls} direct + ${metrics.batchReprocessed} reprocessed`,
      icon: Zap,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
      clickable: metrics.totalTransactions > 0,
      onClick: onTransactionClick,
    },
    {
      label: "Direct API Calls",
      value: metrics.directApiCalls.toLocaleString(),
      subtitle: "Real-time enrollments",
      icon: CheckCircle,
      color: "text-status-ok",
      bgColor: "bg-status-ok/10",
      clickable: false,
    },
    {
      label: "Batch → API Reprocessed",
      value: metrics.batchReprocessed.toLocaleString(),
      subtitle: "Failed batch records recovered via API",
      icon: RefreshCw,
      color: "text-accent",
      bgColor: "bg-accent/10",
      clickable: false,
    },
    {
      label: "API Success Rate",
      value: `${metrics.successRate.toFixed(1)}%`,
      subtitle: "Last 15 minutes",
      icon: TrendingUp,
      color: "text-status-ok",
      bgColor: "bg-status-ok/10",
      clickable: true,
      onClick: () => navigate("/sandbox/success"),
    },
    {
      label: "API Error Rate",
      value: `${metrics.errorRate.toFixed(1)}%`,
      subtitle: "Validation + Timeout failures",
      icon: AlertTriangle,
      color: "text-status-bad",
      bgColor: "bg-status-bad/10",
      clickable: true,
      onClick: () => navigate("/sandbox/errors"),
    },
    {
      label: "API p95 Latency",
      value: `${metrics.avgLatency} ms`,
      subtitle: "SLA threshold: 1000ms",
      icon: Clock,
      color: metrics.avgLatency > 1000 ? "text-status-bad" : "text-status-warn",
      bgColor: metrics.avgLatency > 1000 ? "bg-status-bad/10" : "bg-status-warn/10",
      clickable: false,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
      {cards.map((card, i) => (
        <div
          key={i}
          onClick={card.clickable && card.onClick ? card.onClick : undefined}
          className={`bg-card border border-border rounded-xl p-4 animate-fade-in ${
            card.clickable ? "cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all" : ""
          }`}
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
              <p className={`text-2xl font-bold ${card.color}`}>
                {card.value}
              </p>
              <p className="text-[11px] text-muted-foreground mt-1">{card.subtitle}</p>
            </div>
            <div className={`${card.bgColor} p-2 rounded-lg`}>
              <card.icon className={`w-4 h-4 ${card.color}`} />
            </div>
          </div>
          {card.clickable && (
            <p className="text-[10px] text-primary mt-2">Click to view details →</p>
          )}
        </div>
      ))}
    </div>
  );
}
