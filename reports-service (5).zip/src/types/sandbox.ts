export interface LiveMetrics {
  consumers: number;
  successRate: number;
  errorRate: number;
  slaLatency: number;
}

export interface StatusFunnelData {
  received: number;
  validated: number;
  submitted: number;
  processed: number;
  delivered: number;
}

export interface APIPayload {
  consumer_pii: {
    ssn: string;
    dob: string;
    name: {
      second_surname: string | null;
      surname: string;
      first_name: string;
      middle_name: string;
      generation_code: string | null;
    };
    address: {
      line1: string;
      line2: string;
      city: string;
      state: string;
      zip: string;
    };
  };
  portfolios: {
    portfolio_number: number[];
    subcode: string;
  };
  ecs_customer_supplied_information: {
    ecs_subscription_Id: string;
    customer_id: string;
    credit_limit_filter: string;
    credit_limit_value: string;
    credit_utilization_filter: string;
    credit_utilization_value: string;
    credit_balance_filter: string;
    credit_balance_value: string;
    external_client_id: string;
    external_client_info: string;
  };
  experian_internal_id: {
    ecs_subscription_id: string;
    customer_id: string;
    borrower_flag: string;
    experian_consumer_id: string;
  };
  permissible_purpose: string;
}

export interface ErrorRecord {
  id: string;
  timestamp: string;
  type: string;
  message: string;
  source: string;
  status: "pending" | "retrying" | "resolved";
  originalIngestion: "BATCH" | "API";
  reprocessedViaApi?: boolean;
  // API-specific fields
  transactionId?: string;
  payload?: APIPayload;
  // Batch-specific fields
  fileName?: string;
  rowNumber?: number;
  fieldName?: string;
  originalValue?: string;
}

export interface SuccessRecord {
  id: string;
  timestamp: string;
  type: string;
  source: string;
  latency: number;
}

export interface AIInsight {
  message: string;
  confidence: "Low" | "Medium" | "High";
  signal: string;
  nextAction: string;
  scope: string;
}
