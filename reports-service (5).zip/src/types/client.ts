export interface ClientData {
  COMPANY: string;
  PORT: string;
  "PORTFOLIO NAME": string;
  POPULATION: number;
  "START DATE": string;
  "END DATE": string;
  TYPE: string;
  "RT START DATE": string;
  "RT END DATE": string;
  ACTIVE: "YES" | "NO" | "";
  "CLIENT TYPE": string;
  "LAST FULL FILE NAME": string;
  "LAST FULL FILE PROCESSED DATE": string;
  "LAST ADD/DEL FILE NAME": string;
  "LAST ADD/DEL FILE PROCESSED DATE": string;
  "INGESTION MODE": "BATCH" | "API" | "COMBO";
  "RUN TYPE": string;
}

export interface FilterState {
  search: string;
  active: "all" | "YES" | "NO";
  type: "all" | "D" | "R" | "B";
  clientType: "all" | "STS" | "I&D" | "ECS";
  ingestion: "all" | "BATCH" | "API" | "COMBO";
  period: "Day" | "Week" | "Month";
}

export interface KPIData {
  activeClients: number;
  totalPopulation: number;
  lastFullFile: string;
  lastAddDelFile: string;
  // API-specific metrics
  totalTransactions?: number;
  addDelCount?: number;
  isApiMode?: boolean;
  // Reprocessed batch errors via API
  reprocessedViaApi?: number;
}
