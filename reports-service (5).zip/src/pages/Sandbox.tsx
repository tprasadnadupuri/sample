import { SandboxDashboard } from "@/components/sandbox/SandboxDashboard";

const Sandbox = () => {
  return <SandboxDashboard />;
};

export default Sandbox;
