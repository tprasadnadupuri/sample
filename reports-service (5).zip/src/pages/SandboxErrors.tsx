import { useState } from "react";
import { ErrorDashboard } from "@/components/sandbox/ErrorDashboard";
import { IngestionModeTabs, IngestionMode } from "@/components/sandbox/IngestionModeTabs";
import { ThemeProvider } from "@/hooks/useTheme";
import { SandboxHeader } from "@/components/sandbox/SandboxHeader";
import { ArrowLeft } from "lucide-react";
import { useNavigate, useSearchParams } from "react-router-dom";

const SandboxErrors = () => {
  const [searchParams] = useSearchParams();
  const initialMode = (searchParams.get("mode") as IngestionMode) || "API";
  const [ingestionMode, setIngestionMode] = useState<IngestionMode>(initialMode);
  const navigate = useNavigate();

  return (
    <ThemeProvider>
      <div className="min-h-screen bg-background transition-colors duration-300">
        <SandboxHeader />
        <main className="max-w-[1400px] mx-auto px-5 py-6">
          {/* Back Button */}
          <button
            onClick={() => navigate("/sandbox")}
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm">Back to Sandbox</span>
          </button>

          {/* Ingestion Mode Tabs */}
          <IngestionModeTabs mode={ingestionMode} onModeChange={setIngestionMode} />

          {/* Error Dashboard with mode */}
          <ErrorDashboard ingestionMode={ingestionMode} />
        </main>
      </div>
    </ThemeProvider>
  );
};

export default SandboxErrors;
