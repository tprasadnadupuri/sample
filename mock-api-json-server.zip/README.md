# MCM Mock API (json-server)

## Run
```bash
npm install
npm run start
```

API will be available at:
- http://localhost:3001/demoCompanies
- http://localhost:3001/demoRoles
- http://localhost:3001/aiInsights
- http://localhost:3001/clients
- http://localhost:3001/errors
- http://localhost:3001/successes
- http://localhost:3001/waterfallData
