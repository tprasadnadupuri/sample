import { useState, useEffect, useCallback } from "react";
import { LiveMetrics, StatusFunnelData } from "@/types/sandbox";

function randomInRange(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomFloat(min: number, max: number, decimals: number = 1): number {
  const val = Math.random() * (max - min) + min;
  return parseFloat(val.toFixed(decimals));
}

export interface APISpecificMetrics {
  totalTransactions: number;
  directApiCalls: number;
  batchReprocessed: number;
  successRate: number;
  errorRate: number;
  avgLatency: number;
}

export interface BatchSpecificMetrics {
  totalFilesProcessed: number;
  fullFiles: number;
  addDelFiles: number;
  successRate: number;
  errorRate: number;
  avgProcessingTime: number;
  lastFullFileName: string;
  lastAddDelFileName: string;
}

export function useLiveMetrics() {
  const [metrics, setMetrics] = useState<LiveMetrics>({
    consumers: 331,
    successRate: 93,
    errorRate: 7,
    slaLatency: 914,
  });

  const [funnel, setFunnel] = useState<StatusFunnelData>({
    received: 657,
    validated: 613,
    submitted: 558,
    processed: 542,
    delivered: 535,
  });

  const [apiMetrics, setApiMetrics] = useState<APISpecificMetrics>({
    totalTransactions: 197,
    directApiCalls: 148,
    batchReprocessed: 49,
    successRate: 94.2,
    errorRate: 5.8,
    avgLatency: 842,
  });

  const [batchMetrics, setBatchMetrics] = useState<BatchSpecificMetrics>({
    totalFilesProcessed: 156,
    fullFiles: 89,
    addDelFiles: 67,
    successRate: 91.5,
    errorRate: 8.5,
    avgProcessingTime: 12,
    lastFullFileName: "CHASE_FULL_20250206_001.csv",
    lastAddDelFileName: "NAVY_ADDDEL_20250206_003.csv",
  });

  const [isLive, setIsLive] = useState(true);

  const resetDemo = useCallback(() => {
    setFunnel({
      received: 0,
      validated: 0,
      submitted: 0,
      processed: 0,
      delivered: 0,
    });
    setApiMetrics({
      totalTransactions: 0,
      directApiCalls: 0,
      batchReprocessed: 0,
      successRate: 100,
      errorRate: 0,
      avgLatency: 0,
    });
    setBatchMetrics({
      totalFilesProcessed: 0,
      fullFiles: 0,
      addDelFiles: 0,
      successRate: 100,
      errorRate: 0,
      avgProcessingTime: 0,
      lastFullFileName: "—",
      lastAddDelFileName: "—",
    });
  }, []);

  useEffect(() => {
    if (!isLive) return;

    const interval = setInterval(() => {
      // Update general metrics
      setMetrics((prev) => ({
        consumers: Math.max(100, prev.consumers + randomInRange(-20, 30)),
        successRate: Math.min(100, Math.max(85, prev.successRate + randomFloat(-2, 2))),
        errorRate: Math.min(15, Math.max(2, prev.errorRate + randomFloat(-1, 1))),
        slaLatency: Math.max(200, Math.min(2000, prev.slaLatency + randomInRange(-50, 80))),
      }));

      // Update funnel
      setFunnel((prev) => {
        const newReceived = prev.received + randomInRange(5, 20);
        const newValidated = Math.min(newReceived, prev.validated + randomInRange(3, 15));
        const newProcessed = Math.min(newValidated, prev.processed + randomInRange(2, 10));
        const newDelivered = Math.min(newProcessed, prev.delivered + randomInRange(1, 8));

        return {
          received: newReceived,
          validated: newValidated,
          submitted: prev.submitted, // deprecated but keeping for type compat
          processed: newProcessed,
          delivered: newDelivered,
        };
      });

      // Update API metrics
      setApiMetrics((prev) => {
        const newDirect = prev.directApiCalls + randomInRange(0, 5);
        const newReprocessed = prev.batchReprocessed + (Math.random() > 0.7 ? 1 : 0);
        return {
          totalTransactions: newDirect + newReprocessed,
          directApiCalls: newDirect,
          batchReprocessed: newReprocessed,
          successRate: Math.min(100, Math.max(88, prev.successRate + randomFloat(-1, 1))),
          errorRate: Math.min(12, Math.max(2, prev.errorRate + randomFloat(-0.5, 0.5))),
          avgLatency: Math.max(200, Math.min(1500, prev.avgLatency + randomInRange(-30, 50))),
        };
      });

      // Update Batch metrics (less frequently)
      if (Math.random() > 0.6) {
        setBatchMetrics((prev) => {
          const newFull = prev.fullFiles + (Math.random() > 0.8 ? 1 : 0);
          const newAddDel = prev.addDelFiles + (Math.random() > 0.6 ? 1 : 0);
          return {
            totalFilesProcessed: newFull + newAddDel,
            fullFiles: newFull,
            addDelFiles: newAddDel,
            successRate: Math.min(100, Math.max(85, prev.successRate + randomFloat(-1, 1))),
            errorRate: Math.min(15, Math.max(3, prev.errorRate + randomFloat(-0.5, 0.5))),
            avgProcessingTime: Math.max(5, Math.min(25, prev.avgProcessingTime + randomInRange(-2, 2))),
            lastFullFileName: prev.lastFullFileName,
            lastAddDelFileName: prev.lastAddDelFileName,
          };
        });
      }
    }, 2000);

    return () => clearInterval(interval);
  }, [isLive]);

  return {
    metrics,
    funnel,
    apiMetrics,
    batchMetrics,
    isLive,
    setIsLive,
    resetDemo,
  };
}
