import { createContext, useContext, useState, ReactNode, useCallback } from "react";
import { User, UserRole, AuthState } from "@/types/auth";

interface AuthContextType extends AuthState {
  login: (username: string, password: string, company: string, role: UserRole) => boolean;
  loginAsGuest: () => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
  });

  const login = useCallback((username: string, password: string, company: string, role: UserRole): boolean => {
    // Demo validation - password is "demo"
    if (password !== "demo") {
      return false;
    }

    const user: User = {
      id: crypto.randomUUID(),
      username,
      role,
      company,
      isGuest: false,
    };

    setAuthState({ user, isAuthenticated: true });
    return true;
  }, []);

  const loginAsGuest = useCallback(() => {
    const user: User = {
      id: crypto.randomUUID(),
      username: "guest",
      role: "OpsViewer",
      company: "Demo Tenant",
      isGuest: true,
    };

    setAuthState({ user, isAuthenticated: true });
  }, []);

  const logout = useCallback(() => {
    setAuthState({ user: null, isAuthenticated: false });
  }, []);

  return (
    <AuthContext.Provider value={{ ...authState, login, loginAsGuest, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
