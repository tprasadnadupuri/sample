export type UserRole = "OpsViewer" | "Admin" | "Analyst";

export interface User {
  id: string;
  username: string;
  role: UserRole;
  company: string;
  isGuest: boolean;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export const DEMO_COMPANIES = [
  "CBC/Fidelity Bank",
  "Mission Loans LLC",
  "JP Morgan Chase",
  "Navy Federal Credit Union",
  "Social Mortgage",
];

export const DEMO_ROLES: UserRole[] = ["OpsViewer", "Admin", "Analyst"];
