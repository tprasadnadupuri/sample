import { useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileBarChart, TrendingUp, Users, UserPlus, UserMinus, AlertTriangle, MapPin, Trash2, RefreshCw, Download } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

interface WaterfallMetric {
  label: string;
  isHeader?: boolean;
  isSubItem?: boolean;
  withPin?: number | string;
  withoutPin?: number | string;
  total?: number | string;
  threshold?: string;
  thresholdPercent?: string;
  current?: number | string;
  filePercent?: string;
  hasSeparator?: boolean;
}

const waterfallData: WaterfallMetric[] = [
  // Main Population Metrics
  { label: "OLD MONITORING POPULATION", withPin: 12345, withoutPin: "", total: "", threshold: "N/A", thresholdPercent: "", current: 12345, filePercent: "" },
  { label: "BEGINNING NSPP", withPin: 12345, withoutPin: "", total: "", threshold: "12", thresholdPercent: "", current: 12345, filePercent: "" },
  { label: "TOTAL INPUT RECORDS", withPin: 12345, withoutPin: "", total: "", threshold: "1", thresholdPercent: "", current: 12345, filePercent: "" },
  { label: "INPUT ADD RECORDS", withPin: 1234, withoutPin: "", total: "", threshold: "2", thresholdPercent: "", current: 12345, filePercent: "" },
  { label: "INPUT DELETE RECORDS", withPin: 123, withoutPin: "", total: "", threshold: "12", thresholdPercent: "", current: 123, filePercent: "" },
  
  // Total Rejects Section
  { label: "TOTAL REJECTS", isHeader: true, withPin: 1245, withoutPin: "", total: "", threshold: "12", thresholdPercent: "", current: 1345, filePercent: "" },
  { label: "Invalid Comp/PortID", isSubItem: true, withPin: 1, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 123, filePercent: "" },
  { label: "Invalid Update flags", isSubItem: true, withPin: 2, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 2, filePercent: "" },
  { label: "Invalid Account number", isSubItem: true, withPin: 12, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 12, filePercent: "" },
  { label: "Invalid Record Length", isSubItem: true, withPin: 5, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 2, filePercent: "" },
  { label: "Blank Name", isSubItem: true, withPin: 1, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 1, filePercent: "" },
  { label: "Blank Address", isSubItem: true, withPin: 1, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 1, filePercent: "" },
  { label: "Blank SIN", isSubItem: true, withPin: 2, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 2, filePercent: "" },
  { label: "Invalid SIN (Non-Numeric SIN)", isSubItem: true, withPin: 2, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 2, filePercent: "" },
  { label: "Blank Data Lines", isSubItem: true, withPin: 3, withoutPin: 3, total: 5, threshold: "", thresholdPercent: "", current: 4, filePercent: "" },
  { label: "Invalid SIN", isSubItem: true, withPin: 4, withoutPin: 4, total: 8, threshold: "", thresholdPercent: "", current: 10, filePercent: "" },
  { label: "Invalid SSN", isSubItem: true, withPin: 2, withoutPin: 2, total: 10, threshold: "", thresholdPercent: "", current: 10, filePercent: "", hasSeparator: true },
  
  // Pinned Records Section
  { label: "TOTAL PINNED RECORDS", isHeader: true, withPin: 1234, withoutPin: "", total: "", threshold: "12", thresholdPercent: "", current: 1234, filePercent: "" },
  { label: "EXACT ADDRESS", isSubItem: true, withPin: 123, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 123, filePercent: "123" },
  { label: "SIMILAR ADDRESS", isSubItem: true, withPin: 124, withoutPin: "", total: "", threshold: "12", thresholdPercent: "", current: 1234, filePercent: "" },
  { label: "CONFLICTING ADDRESS", isSubItem: true, withPin: 12, withoutPin: "", total: "", threshold: "34", thresholdPercent: "", current: 55, filePercent: "", hasSeparator: true },
  
  // Dropped Records Section
  { label: "DROPPED RECORDS with Reasons", isHeader: true, withPin: "", withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: "", filePercent: "" },
  { label: "NO-HIT (From Pinning Report)", isSubItem: true, withPin: 50, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 50, filePercent: "" },
  { label: "Name Parse Error (B21-42)", isSubItem: true, withPin: 20, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 20, filePercent: "" },
  { label: "Address Parse Error (B99)", isSubItem: true, withPin: 1, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 1, filePercent: "" },
  { label: "Unable to Find Consumer", isSubItem: true, withPin: 2, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 2, filePercent: "" },
  { label: "Other Dropped Records", isSubItem: true, withPin: 12, withoutPin: 1, total: 13, threshold: "", thresholdPercent: "", current: "", filePercent: "" },
  { label: "Duplicate Adds w/in Input File", isSubItem: true, withPin: 5, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 5, filePercent: "" },
  { label: "Duplicate Deletes w/in Input File", isSubItem: true, withPin: 4, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 4, filePercent: "" },
  { label: "UnMatched Deletes", isSubItem: true, withPin: 2, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 2, filePercent: "" },
  { label: "Address Mismatch Records", isSubItem: true, withPin: 1, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: 1, filePercent: "" },
  { label: "TOTAL DROPPED RECORDS", isHeader: true, withPin: 85, withoutPin: "", total: "", threshold: "", thresholdPercent: "", current: "", filePercent: "", hasSeparator: true },
  
  // Final Metrics
  { label: "NET ADDS", withPin: 12345, withoutPin: 123, total: 12468, threshold: "", thresholdPercent: "", current: "", filePercent: "" },
  { label: "NET DELETES", withPin: 123, withoutPin: 12, total: 135, threshold: "10", thresholdPercent: "", current: 5, filePercent: "" },
  { label: "TOTAL UPDATES", withPin: 12, withoutPin: 3, total: 15, threshold: "", thresholdPercent: "", current: "", filePercent: "" },
  { label: "TOTAL PIN CHANGES", withPin: 10, withoutPin: 2, total: 12, threshold: "", thresholdPercent: "", current: "", filePercent: "" },
  { label: "NET PIN REFRESH", withPin: 22, withoutPin: 5, total: 27, threshold: "", thresholdPercent: "", current: "", filePercent: "" },
  { label: "NEW MONITORING POPULATION", withPin: 25456, withoutPin: 234, total: 25678, threshold: "", thresholdPercent: "", current: "", filePercent: "" },
];

const COLORS = ["hsl(var(--primary))", "hsl(var(--muted-foreground))"];

const getRowIcon = (label: string) => {
  if (label.includes("POPULATION") || label.includes("NSPP")) return <Users className="w-4 h-4 text-primary" />;
  if (label.includes("ADD") || label.includes("ADDS")) return <UserPlus className="w-4 h-4 text-success" />;
  if (label.includes("DELETE") || label.includes("DELETES")) return <UserMinus className="w-4 h-4 text-destructive" />;
  if (label.includes("REJECT") || label.includes("Invalid") || label.includes("Blank") || label.includes("Error")) return <AlertTriangle className="w-4 h-4 text-warning" />;
  if (label.includes("PINNED") || label.includes("ADDRESS") || label.includes("PIN")) return <MapPin className="w-4 h-4 text-accent" />;
  if (label.includes("DROPPED") || label.includes("Duplicate") || label.includes("UnMatched") || label.includes("NO-HIT")) return <Trash2 className="w-4 h-4 text-muted-foreground" />;
  if (label.includes("UPDATE") || label.includes("REFRESH")) return <RefreshCw className="w-4 h-4 text-chart-1" />;
  return <TrendingUp className="w-4 h-4 text-chart-2" />;
};

type ReportPeriod = "daily" | "weekly" | "monthly";

export function WaterfallReports() {
  const [period, setPeriod] = useState<ReportPeriod>("daily");

  // Aggregate data for pie charts
  const mainMetrics = waterfallData.filter(d => !d.isSubItem && !d.isHeader && d.withPin && typeof d.withPin === 'number');
  const totalWithPin = mainMetrics.reduce((sum, d) => sum + (typeof d.withPin === 'number' ? d.withPin : 0), 0);
  const totalWithoutPin = mainMetrics.reduce((sum, d) => sum + (typeof d.withoutPin === 'number' ? d.withoutPin : 0), 0);

  const pieData = [
    { name: "w/ PIN", value: totalWithPin || 50000 },
    { name: "w/o PIN", value: totalWithoutPin || 400 },
  ];

  // Records distribution for second pie chart
  const addRecords = waterfallData.find(d => d.label === "NET ADDS");
  const deleteRecords = waterfallData.find(d => d.label === "NET DELETES");
  const recordsDistribution = [
    { name: "Net Adds", value: typeof addRecords?.total === 'number' ? addRecords.total : 12468, color: "hsl(var(--success))" },
    { name: "Net Deletes", value: typeof deleteRecords?.total === 'number' ? deleteRecords.total : 135, color: "hsl(var(--destructive))" },
    { name: "Updates", value: 15, color: "hsl(var(--accent))" },
  ];

  const formatValue = (val: number | string | undefined) => {
    if (val === undefined || val === "") return "";
    if (typeof val === "number") return val.toLocaleString();
    return val;
  };

  const handleDownloadPDF = () => {
    const doc = new jsPDF({ orientation: "landscape" });
    const periodLabel = period.charAt(0).toUpperCase() + period.slice(1);
    
    doc.setFontSize(16);
    doc.text(`Waterfall Report — ${periodLabel}`, 14, 18);
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 26);

    const tableRows = waterfallData.map(row => [
      row.isSubItem ? `    ${row.label}` : row.label,
      formatValue(row.withPin),
      formatValue(row.withoutPin),
      formatValue(row.total),
      row.threshold || "",
      formatValue(row.current),
    ]);

    autoTable(doc, {
      startY: 32,
      head: [["Metric", "w/ PIN", "w/o PIN", "Total", "Threshold%", "CurrentFile%"]],
      body: tableRows,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [59, 130, 246] },
    });

    doc.save(`waterfall-report-${period}-${new Date().toISOString().slice(0, 10)}.pdf`);
  };

  return (
    <div className="space-y-6">
      {/* Header with period filter and download */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <FileBarChart className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-foreground">Waterfall Reports</h2>
            <p className="text-xs text-muted-foreground">Population tracking and threshold analysis</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Period Filter */}
          <div className="flex items-center bg-secondary rounded-lg p-1">
            {(["daily", "weekly", "monthly"] as ReportPeriod[]).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  period === p
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </button>
            ))}
          </div>

          {/* Download PDF */}
          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:bg-primary/90 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Download PDF
          </button>
        </div>
      </div>

      {/* Pie Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">PIN Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {pieData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => value.toLocaleString()}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-6 mt-2 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span className="text-muted-foreground">w/ PIN: <strong className="text-foreground">{pieData[0].value.toLocaleString()}</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-muted-foreground" />
                <span className="text-muted-foreground">w/o PIN: <strong className="text-foreground">{pieData[1].value.toLocaleString()}</strong></span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Records Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={recordsDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={2}
                    dataKey="value"
                    label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                    labelLine={false}
                  >
                    {recordsDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number) => value.toLocaleString()}
                  />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Waterfall Table */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-medium">Waterfall Metrics Summary</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/30">
                  <TableHead className="font-semibold text-foreground min-w-[250px]">Metric</TableHead>
                  <TableHead className="text-right font-semibold text-foreground">w/ PIN</TableHead>
                  <TableHead className="text-right font-semibold text-foreground">w/o PIN</TableHead>
                  <TableHead className="text-right font-semibold text-foreground">Total</TableHead>
                  <TableHead className="text-right font-semibold text-foreground">Threshold%</TableHead>
                  <TableHead className="text-right font-semibold text-foreground">CurrentFile%</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {waterfallData.map((row, idx) => (
                  <TableRow 
                    key={idx} 
                    className={`
                      hover:bg-muted/20 transition-colors
                      ${row.isHeader ? "bg-muted/40 font-semibold" : ""}
                      ${row.hasSeparator ? "border-b-2 border-border" : ""}
                    `}
                  >
                    <TableCell className={row.isHeader ? "font-semibold" : ""}>
                      <div className={`flex items-center gap-2 ${row.isSubItem ? "pl-4" : ""}`}>
                        {!row.isSubItem && getRowIcon(row.label)}
                        <span className={`text-sm ${row.isSubItem ? "text-muted-foreground" : ""}`}>
                          {row.label}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{formatValue(row.withPin)}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatValue(row.withoutPin)}</TableCell>
                    <TableCell className="text-right font-semibold tabular-nums text-primary">{formatValue(row.total)}</TableCell>
                    <TableCell className="text-right tabular-nums">{row.threshold || ""}</TableCell>
                    <TableCell className="text-right tabular-nums">{formatValue(row.current)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border p-4">
          <div className="text-xs text-muted-foreground mb-1">Old Population</div>
          <div className="text-2xl font-bold text-foreground">12,345</div>
        </Card>
        <Card className="bg-card border-border p-4">
          <div className="text-xs text-muted-foreground mb-1">New Population</div>
          <div className="text-2xl font-bold text-primary">25,678</div>
        </Card>
        <Card className="bg-card border-border p-4">
          <div className="text-xs text-muted-foreground mb-1">Net Change</div>
          <div className="text-2xl font-bold text-success">+13,333</div>
        </Card>
        <Card className="bg-card border-border p-4">
          <div className="text-xs text-muted-foreground mb-1">Total Dropped</div>
          <div className="text-2xl font-bold text-destructive">85</div>
        </Card>
      </div>
    </div>
  );
}