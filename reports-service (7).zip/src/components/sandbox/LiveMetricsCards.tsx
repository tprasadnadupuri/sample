import { Users, TrendingUp, AlertTriangle, Clock } from "lucide-react";
import { LiveMetrics } from "@/types/sandbox";
import { useNavigate } from "react-router-dom";

interface LiveMetricsCardsProps {
  metrics: LiveMetrics;
}

export function LiveMetricsCards({ metrics }: LiveMetricsCardsProps) {
  const navigate = useNavigate();

  const cards = [
    {
      label: "Consumers (last 60s)",
      value: metrics.consumers.toString(),
      subtitle: "Incoming events/min, synthetic stream",
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
      clickable: false,
    },
    {
      label: "Success rate (15m)",
      value: `${metrics.successRate.toFixed(0)}%`,
      subtitle: "Processed + Delivered / Total",
      icon: TrendingUp,
      color: "text-status-ok",
      bgColor: "bg-status-ok/10",
      clickable: true,
      onClick: () => navigate("/sandbox/success"),
    },
    {
      label: "Error rate (15m)",
      value: `${metrics.errorRate.toFixed(0)}%`,
      subtitle: "Validation + Downstream + Unknown",
      icon: AlertTriangle,
      color: "text-status-bad",
      bgColor: "bg-status-bad/10",
      clickable: true,
      onClick: () => navigate("/sandbox/errors"),
    },
    {
      label: "SLA p95 (API)",
      value: `${metrics.slaLatency} ms`,
      subtitle: "Latency simulation (ms)",
      icon: Clock,
      color: "text-status-warn",
      bgColor: "bg-status-warn/10",
      clickable: false,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
      {cards.map((card, i) => (
        <div
          key={i}
          onClick={card.onClick}
          className={`bg-card border border-border rounded-xl p-4 animate-fade-in ${
            card.clickable ? "cursor-pointer hover:border-primary/50 hover:shadow-lg transition-all" : ""
          }`}
          style={{ animationDelay: `${i * 50}ms` }}
        >
          <div className="flex items-start justify-between">
            <div className="flex-1 min-w-0">
              <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
              <p className={`text-2xl font-bold ${card.color}`}>
                {card.value}
              </p>
              <p className="text-[11px] text-muted-foreground mt-1">{card.subtitle}</p>
            </div>
            <div className={`${card.bgColor} p-2 rounded-lg`}>
              <card.icon className={`w-4 h-4 ${card.color}`} />
            </div>
          </div>
          {card.clickable && (
            <p className="text-[10px] text-primary mt-2">Click to view details →</p>
          )}
        </div>
      ))}
    </div>
  );
}
