import { Zap, FileText, BarChart3, FileSpreadsheet } from "lucide-react";

export type IngestionMode = "API" | "BATCH" | "WATERFALL" | "CUSTOM";

interface IngestionModeTabsProps {
  mode: IngestionMode;
  onModeChange: (mode: IngestionMode) => void;
}

export function IngestionModeTabs({ mode, onModeChange }: IngestionModeTabsProps) {
  return (
    <div className="flex items-center gap-2 mb-6">
      <span className="text-sm font-medium text-muted-foreground mr-2">View:</span>
      <div className="flex items-center bg-secondary rounded-lg p-1">
        <button
          onClick={() => onModeChange("API")}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
            mode === "API"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Zap className="w-4 h-4" />
          API Ingestion
        </button>
        <button
          onClick={() => onModeChange("BATCH")}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
            mode === "BATCH"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <FileText className="w-4 h-4" />
          Batch Ingestion
        </button>
        <button
          onClick={() => onModeChange("WATERFALL")}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
            mode === "WATERFALL"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          Waterfall Reports
        </button>
        <button
          onClick={() => onModeChange("CUSTOM")}
          className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-all ${
            mode === "CUSTOM"
              ? "bg-primary text-primary-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          Custom Reports
        </button>
      </div>
    </div>
  );
}