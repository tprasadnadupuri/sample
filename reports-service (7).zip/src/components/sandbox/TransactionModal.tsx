import { useState } from "react";
import { X, ArrowUpRight, ArrowDownRight, Clock, RefreshCw, Filter } from "lucide-react";
import { Transaction, TransactionFilters, TransactionSummary } from "@/types/transaction";

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  summary: TransactionSummary;
  filters: TransactionFilters;
  onFilterChange: <K extends keyof TransactionFilters>(key: K, value: TransactionFilters[K]) => void;
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-muted text-muted-foreground",
  validated: "bg-chart-2/20 text-chart-2",
  submitted: "bg-chart-3/20 text-chart-3",
  processed: "bg-chart-4/20 text-chart-4",
  delivered: "bg-status-ok/20 text-status-ok",
  failed: "bg-status-bad/20 text-status-bad",
};

const SOURCE_COLORS: Record<string, string> = {
  API: "bg-chart-2/10 text-chart-2 border-chart-2/30",
  BATCH: "bg-chart-1/10 text-chart-1 border-chart-1/30",
  BATCH_REPROCESSED: "bg-accent/10 text-accent border-accent/30",
};

export function TransactionModal({
  isOpen,
  onClose,
  transactions,
  summary,
  filters,
  onFilterChange,
}: TransactionModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-background/80 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className="relative bg-card border border-border rounded-2xl shadow-2xl w-full max-w-5xl max-h-[85vh] overflow-hidden animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border">
          <div>
            <h2 className="text-lg font-bold text-foreground">Transaction Details</h2>
            <p className="text-sm text-muted-foreground">
              {transactions.length} of {summary.total} transactions shown
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-secondary rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-3 px-6 py-4 border-b border-border bg-input/30">
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">By Source</p>
            <div className="flex justify-center gap-2 text-xs">
              <span className="px-2 py-0.5 bg-chart-2/10 text-chart-2 rounded">API: {summary.bySource.api}</span>
              <span className="px-2 py-0.5 bg-chart-1/10 text-chart-1 rounded">Batch: {summary.bySource.batch}</span>
              <span className="px-2 py-0.5 bg-accent/10 text-accent rounded">Reproc: {summary.bySource.batchReprocessed}</span>
            </div>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">By Action</p>
            <div className="flex justify-center gap-2 text-xs">
              <span className="px-2 py-0.5 bg-status-ok/10 text-status-ok rounded flex items-center gap-1">
                <ArrowUpRight className="w-3 h-3" /> Enroll: {summary.byAction.add}
              </span>
              <span className="px-2 py-0.5 bg-status-warn/10 text-status-warn rounded flex items-center gap-1">
                <ArrowDownRight className="w-3 h-3" /> De-enroll: {summary.byAction.delete}
              </span>
            </div>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Status Distribution</p>
            <div className="flex justify-center gap-1 text-[10px]">
              {Object.entries(summary.byStatus).map(([status, count]) => (
                <span key={status} className={`px-1.5 py-0.5 rounded ${STATUS_COLORS[status]}`}>
                  {count}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 px-6 py-3 border-b border-border">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <select
            value={filters.source}
            onChange={(e) => onFilterChange("source", e.target.value as any)}
            className="px-3 py-1.5 bg-input border border-border rounded-lg text-xs"
          >
            <option value="all">All Sources</option>
            <option value="API">API Only</option>
            <option value="BATCH_REPROCESSED">Batch → API Only</option>
          </select>
          <select
            value={filters.action}
            onChange={(e) => onFilterChange("action", e.target.value as any)}
            className="px-3 py-1.5 bg-input border border-border rounded-lg text-xs"
          >
            <option value="all">All Actions</option>
            <option value="add">Enroll (Add)</option>
            <option value="delete">De-enroll (Delete)</option>
          </select>
          <select
            value={filters.status}
            onChange={(e) => onFilterChange("status", e.target.value as any)}
            className="px-3 py-1.5 bg-input border border-border rounded-lg text-xs"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="validated">Validated</option>
            <option value="submitted">Submitted</option>
            <option value="processed">Processed</option>
            <option value="delivered">Delivered</option>
            <option value="failed">Failed</option>
          </select>
        </div>

        {/* Transaction Table */}
        <div className="overflow-auto max-h-[50vh]">
          <table className="w-full border-collapse text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="bg-input">
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Transaction ID</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Source</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Action</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Client</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Portfolio</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-muted-foreground">Population</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-muted-foreground">Latency</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground">Time</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((txn) => (
                <tr 
                  key={txn.id}
                  className="border-b border-border/50 hover:bg-input/50 transition-colors"
                >
                  <td className="px-4 py-3">
                    <span className="font-mono text-xs font-semibold text-foreground">{txn.id}</span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-col gap-1">
                      <span className={`px-2 py-0.5 text-[10px] rounded border ${SOURCE_COLORS[txn.source]}`}>
                        {txn.source === "BATCH_REPROCESSED" ? "BATCH→API" : txn.source}
                      </span>
                      {txn.originalBatchId && (
                        <span className="text-[9px] text-muted-foreground flex items-center gap-1">
                          <RefreshCw className="w-2.5 h-2.5" />
                          {txn.originalBatchId}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`flex items-center gap-1 text-xs ${
                      txn.action === "add" ? "text-status-ok" : "text-status-warn"
                    }`}>
                      {txn.action === "add" ? (
                        <><ArrowUpRight className="w-3 h-3" /> Enroll</>
                      ) : (
                        <><ArrowDownRight className="w-3 h-3" /> De-enroll</>
                      )}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 text-[10px] rounded capitalize ${STATUS_COLORS[txn.status]}`}>
                      {txn.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-foreground">{txn.clientName}</td>
                  <td className="px-4 py-3 text-muted-foreground font-mono text-xs">{txn.portfolioId}</td>
                  <td className="px-4 py-3 text-right text-foreground">{txn.population.toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">
                    <span className={`${
                      txn.latency < 500 ? "text-status-ok" : 
                      txn.latency < 1000 ? "text-status-warn" : "text-status-bad"
                    }`}>
                      {txn.latency}ms
                    </span>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground text-xs">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(txn.timestamp).toLocaleTimeString()}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
