import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Activity, Zap, BarChart3, Brain, Users } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { DEMO_COMPANIES, DEMO_ROLES, UserRole } from "@/types/auth";

export function LoginPage() {
  const navigate = useNavigate();
  const { login, loginAsGuest } = useAuth();
  
  const [company, setCompany] = useState(DEMO_COMPANIES[0]);
  const [username, setUsername] = useState("client.admin");
  const [role, setRole] = useState<UserRole>("OpsViewer");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!username.trim()) {
      setError("Username is required");
      return;
    }
    
    const success = login(username, password, company, role);
    if (success) {
      navigate("/dashboard");
    } else {
      setError("Invalid password. Use 'demo' for this demo.");
    }
  };

  const handleGuestLogin = () => {
    loginAsGuest();
    navigate("/sandbox");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-card border border-border rounded-2xl p-8 shadow-xl">
          {/* Header */}
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground">Sign in to Sandbox</h1>
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground mb-6">
            This is a <span className="text-foreground font-medium">demo-only</span> portal to showcase monitoring, live status, and AI-style insights before enrollment. No real customer PII is used.
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Company Select */}
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1.5">
                Company / Tenant
              </label>
              <select
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
              >
                {DEMO_COMPANIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Username & Role Row */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1.5">
                  Username
                </label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                  placeholder="client.admin"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-muted-foreground mb-1.5">
                  Role
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                >
                  {DEMO_ROLES.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-muted-foreground mb-1.5">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 bg-input border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all"
                placeholder="••••"
              />
            </div>

            {error && (
              <p className="text-sm text-status-bad">{error}</p>
            )}

            {/* Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                className="px-5 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium text-sm hover:bg-primary/90 transition-colors"
              >
                Enter Sandbox
              </button>
              <button
                type="button"
                onClick={handleGuestLogin}
                className="px-5 py-2.5 bg-transparent text-foreground rounded-lg font-medium text-sm hover:bg-secondary transition-colors"
              >
                Continue as Guest
              </button>
              <span className="text-xs text-muted-foreground">
                Tip: use password <code className="text-primary">demo</code>
              </span>
            </div>
          </form>

          {/* What you'll see */}
          <div className="mt-8 pt-6 border-t border-border">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-1">
                  What you'll see inside
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  <span className="inline-flex items-center gap-1"><BarChart3 className="w-3 h-3" /> Live intake stream</span>
                  {" • "}
                  <span className="inline-flex items-center gap-1">Status funnel</span>
                  {" • "}
                  <span className="inline-flex items-center gap-1">SLA tiles</span>
                  {" • "}
                  <span className="inline-flex items-center gap-1"><Brain className="w-3 h-3" /> AI-style insights</span>
                  {" • "}
                  <span className="inline-flex items-center gap-1"><Users className="w-3 h-3" /> Client-ready UX</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
